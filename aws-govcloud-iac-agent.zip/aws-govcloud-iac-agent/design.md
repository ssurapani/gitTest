# Design: GovCloud IaC Agent Application

Status: `proposed`. This document lays out code and runtime for the agent application. No component described here has been built, validated, approved, or deployed.

## 1. Goals

Build a Python application that runs the guardrailed IaC agent defined in this repository:

| Component | Purpose | Runtime |
|---|---|---|
| Streamlit frontend | Test UI for entering infrastructure requests and viewing generated solutions | ECS container |
| FastAPI backend | Versioned agent API. Its first consumer is the Streamlit UI. Later consumers are other agentic systems such as Cloud Help | ECS container |
| Agent core library | Bedrock adapter, orchestration, prompt/skill/policy loading, deterministic checks | Imported by the backend only |
| Agent content | `AGENTS.md` and `agent/` (`config/`, `skills/`, `policies/`, `knowledge/`, `templates/`, `workflows/`), which already exist | Packaged into the backend image as read-only data |
| Hosting IaC | `iac/`: Terraform root module that composes Codebank IaC patterns to host both services | GitLab pipeline via the approved `tf` wrapper and deploy template |
| Dockerfiles | One image per service, used for local testing and as the basis for ECS images | Local Docker / CI |
| GitLab CI/CD | Lint, test, guardrail evaluation, image build, scan, publish | GitLab runners |

Non-goals for this phase:
- The agent does not provision AWS resources, run `terraform apply`/`destroy`, run deployment pipelines, or merge changes (see `agent/config/agent.yaml`).
- The hosting Terraform in `iac/` doesn't define its own versions of resources that Codebank patterns cover. It follows the reuse-first order in `AGENTS.md` §5. Section 9 lists the requirements it has to meet, and `iac/pattern-references.yaml` tracks which pattern backs each component.

## 2. Design principles

1. **The UI is a client.** Streamlit calls only the public FastAPI contract. Cloud Help will use the same contract, so the UI cannot depend on anything Cloud Help can't use.
2. **The core doesn't depend on any framework.** `agent_core` has no FastAPI or Streamlit imports. It can be tested on its own and reused behind other transports later, such as a queue worker or an MCP/A2A adapter.
3. **Guardrail content is data.** Prompts, skills, and policies are loaded from the existing repo files at startup. Each response records a hash of that content so results can be traced to an exact content version.
4. **The model is not the only enforcement point.** Prohibited-resource and pipeline-integrity checks run deterministically on generated artifacts, as `docs/architecture.md` requires. They add to Checkov and the GitLab pipelines; they don't replace them.
5. **Validation status is honest.** Every check status comes from actual execution. If a check didn't run, its status is `not_run`. This matches `agent/templates/solution-record.yaml`.
6. **Unknowns are explicit.** Retrieval connectors that aren't configured return `unknown` and never synthesize facts.

## 3. Repository layout

Each top-level folder has one job:

| Folder | Holds | Consumed by |
|---|---|---|
| `agent/` | Agent runtime content: config, skills, policies, knowledge, templates, workflows | API image (read-only), CI eval |
| `src/agent_core/` | Reusable agent core library | API service |
| `services/` | Deployable applications (api, ui) and their Dockerfiles | Docker / ECS |
| `iac/` | Terraform hosting the services, composed from Codebank patterns | GitLab IaC pipeline |
| `tests/` | Unit, contract, guardrail, and eval tests | CI |
| `docs/` | Architecture, operating model, threat model, onboarding | People |
| `scripts/` | Repository checks | CI, local |

`AGENTS.md` stays at the root because developer tooling reads it from there. It is also copied into the API image with `agent/`.

```text
aws-govcloud-iac-agent/
├── AGENTS.md                         # existing: global system instructions
├── design.md                         # this document
├── pyproject.toml                    # updated: package + optional extras
├── .gitlab-ci.yml                    # new
├── compose.yaml                      # new: local two-container testing
├── .dockerignore                     # new
├── .env.example                      # new: documented settings, no secrets
│
├── agent/                            # existing: runtime agent content (read-only)
│   ├── config/  policies/  knowledge/
│   └── skills/  templates/  workflows/
├── iac/                              # Terraform: Codebank pattern composition (see §9)
│   ├── versions.tf  providers.tf  variables.tf  data.tf  iam.tf  locals.tf
│   ├── main.tf                       # module calls to Codebank patterns
│   ├── outputs.tf
│   ├── pattern-references.yaml       # component -> Codebank project/path/revision
│   └── environments/{dev,test,prod}/ # terraform.tfvars + backend.hcl
├── docs/                             # existing: architecture, threat model, etc.
├── scripts/validate_repository.py    # existing: structure + prohibited-resource scan of iac/
│
├── src/
│   └── agent_core/                   # reusable AI agent core (no web framework)
│       ├── __init__.py
│       ├── settings.py               # pydantic-settings: env-driven config
│       ├── models/                   # pydantic domain models
│       │   ├── request.py            # InfrastructureRequest (mirrors requirements-record.yaml)
│       │   ├── solution.py           # SolutionRecord (mirrors solution-record.yaml)
│       │   └── status.py             # status enums from agent/config/agent.yaml
│       ├── content/                  # loading guardrail content
│       │   ├── loader.py             # reads AGENTS.md, skills, YAML config/policies
│       │   ├── registry.py           # skill registry: stage -> SKILL.md
│       │   └── fingerprint.py        # content hash/version for provenance
│       ├── llm/                      # model access
│       │   ├── base.py               # LLMClient protocol
│       │   ├── bedrock.py            # Bedrock Runtime adapter (boto3, Converse API)
│       │   └── fake.py               # deterministic fake for tests/local UI work
│       ├── factory.py                # build_agent(settings): content, LLM, catalog, pipeline
│       ├── retrieval/                # source-of-truth connectors (interfaces first)
│       │   ├── base.py               # Source protocol + LookupResult
│       │   ├── catalog.py            # knowledge/ catalog reader (verified entries only)
│       │   └── remote.py             # Confluence/GitLab sources (not_configured until phase 3)
│       ├── orchestration/
│       │   ├── pipeline.py           # stage runner implementing solution-decision-workflow
│       │   ├── stages.py             # one class per workflow stage
│       │   ├── prompts.py            # system blocks, untrusted-content tags, JSON extraction
│       │   └── session.py            # conversation/session state abstraction
│       ├── guardrails/               # deterministic checks
│       │   ├── scope.py              # prohibited-intent detection before any model call
│       │   ├── hcl.py                # comment stripping and block structure for HCL
│       │   ├── terraform_scan.py     # prohibited resource types in generated HCL
│       │   ├── pipeline_scan.py      # removed stages, Checkov skips, suppressions
│       │   └── secrets.py            # secret-pattern detection / log redaction
│       └── observability/
│           ├── logging.py            # structured JSON logs, redaction
│           └── tracing.py            # correlation IDs
│
├── services/
│   ├── api/                          # FastAPI backend
│   │   ├── Dockerfile
│   │   └── agent_api/                # unique package name (avoids clashing with the UI)
│   │       ├── main.py               # create_app() factory, middleware, router mounting
│   │       ├── settings.py           # auth mode, limits, docs toggle
│   │       ├── deps.py               # agent access, ownership checks, turn runner
│   │       ├── auth.py               # static token (local) / OIDC JWT validation
│   │       ├── errors.py             # problem+json error model
│   │       ├── limits.py             # per-caller rate limit, per-session turn lock
│   │       ├── schemas.py            # the v1 request/response contract
│   │       └── routers/
│   │           ├── health.py         # /healthz, /readyz
│   │           └── v1/
│   │               ├── agent.py      # /v1/agent/* (capabilities, invoke)
│   │               ├── sessions.py   # /v1/sessions/* (multi-turn)
│   │               └── solutions.py  # /v1/solutions/* (records, artifacts)
│   └── ui/                           # Streamlit frontend
│       ├── Dockerfile
│       ├── .streamlit/config.toml    # headless, no telemetry, XSRF on
│       └── agent_ui/
│           ├── Home.py               # request entry + conversation
│           ├── pages/
│           │   ├── 1_Solution.py     # solution record, artifacts, validation table
│           │   └── 2_About.py        # content version, model, environment
│           └── api_client.py         # typed httpx client for /v1 contract
│
└── tests/
    ├── README.md                     # existing
    ├── conftest.py                   # shared fixtures, test-only service catalog
    ├── unit/                         # agent_core unit tests (fake LLM)
    ├── api/                          # FastAPI contract tests (TestClient)
    ├── guardrails/                   # terraform/pipeline scan fixtures
    └── eval/
        ├── guardrail-scenarios.yaml  # existing
        └── run_scenarios.py          # runs guardrail-scenarios.yaml against the pipeline
```

### Packaging

There is a single `pyproject.toml` with optional dependency groups, so each image installs only what it needs:

| Extra | Contents | Used by |
|---|---|---|
| (base) | `pydantic`, `pydantic-settings`, `pyyaml`, `boto3`, `python-hcl2` (proposed, pending dependency approval) | `agent_core` |
| `api` | `fastapi`, `uvicorn`, `pyjwt[crypto]` | API image |
| `ui` | `streamlit`, `httpx` | UI image. Does not need `boto3`; see the note below |
| `dev` | `pytest`, `ruff`, `mypy`, `httpx` | CI, local |

The UI image installs only `services/ui/requirements.txt` (Streamlit, httpx, pydantic-settings), which mirrors the `ui` extra. It doesn't install the `agent_core` package, so it has no AWS SDK and no Bedrock permissions. All dependencies must come from the organization's approved package mirror, which is not yet identified.

## 4. Agent core

### 4.1 Content loading (`agent_core.content`)

At startup the loader reads the configured content root (`AGENT_CONTENT_DIR`, default `/app/agent-content`). In the repository this root is `agent/`, with `AGENTS.md` copied beside it. Paths below are relative to `agent/`:

| Source | Loaded as | Used for |
|---|---|---|
| `AGENTS.md` | System prompt (always included) | Identity, scope, restrictions |
| `skills/*/SKILL.md` | Skill text, keyed by directory name | Injected per orchestration stage |
| `config/agent.yaml` | `AgentPolicy` model | Execution flags, status vocabulary |
| `config/landing-zone-guardrails.yaml` | `GuardrailPolicy` model | Deterministic checks + prompt context |
| `config/source-of-truth.yaml` | `SourceConfig` model | Connector configuration |
| `policies/*.yaml` | `PolicyChecklist`, `ProhibitedTypes` | Deterministic scans |
| `knowledge/*.yaml` | Catalog entries | Catalog retrieval (example data is flagged as such) |
| `templates/*.yaml` | Output schemas | Shape of `RequirementsRecord` / `SolutionRecord` |

Rules:
- Content is read-only. It is loaded once and validated with pydantic. If any required file is missing or malformed, the service fails to start (`/readyz` stays unhealthy).
- `fingerprint.py` computes a SHA-256 over the loaded files. The fingerprint is returned in every API response and written to logs as `content_version`.
- Safety-critical flags in `agent/config/agent.yaml` (`terraform_apply_allowed`, `merge_allowed`, etc.) are asserted at startup. If any flag is `true`, the service refuses to start, because this application has no authorized workflow for those actions.

### 4.2 LLM adapter (`agent_core.llm`)

```python
class LLMClient(Protocol):
    def converse(
        self,
        system: list[str],
        messages: list[Message],
        *,
        tools: list[ToolSpec] | None = None,
        max_tokens: int,
        temperature: float,
    ) -> LLMResponse: ...
```

- `BedrockClient` uses `boto3` `bedrock-runtime` with the Converse API. The Region, model ID or inference profile, and endpoint URL all come from settings. Nothing is hardcoded.
- Credentials come from the standard AWS credential chain: an ECS task role in AWS, or a developer's own session locally. The code never reads or stores access keys.
- `BEDROCK_ENDPOINT_URL` is optional so traffic can go through a VPC interface endpoint when one is available.
- Retries use botocore adaptive retry. Timeouts and the token budget are configurable.
- `FakeLLMClient` returns scripted responses keyed by stage. It runs unit tests, CI, and UI development without Bedrock access.
- **Unknown:** which Bedrock models and inference profiles are enabled in the approved GovCloud Region(s). This must be confirmed through Service Enablement before choosing a default (see §11).

### 4.3 Orchestration (`agent_core.orchestration`)

The pipeline is an explicit stage runner. Each stage follows `agent/workflows/solution-decision-workflow.md` and loads the matching skill:

| # | Stage | Skill(s) loaded | Deterministic work | Can block? |
|---|---|---|---|---|
| 1 | Scope check | — | Keyword/intent pre-filter | Yes, out of scope |
| 2 | Requirements | `requirements-discovery` | Fill `RequirementsRecord` | Yes, questions returned to caller |
| 3 | Service eligibility | `service-enablement` | Connector lookup | Yes, `unknown`/disabled |
| 4 | Landing Zone check | `landing-zone-guardrails` | Resource/account matrix vs. guardrails | Yes, prohibited |
| 5 | Pattern discovery | `codebank-discovery` | Connector lookup with evidence | No (gap is recorded) |
| 6 | Decide path | `iac-composition`, `pattern-gap-analysis` | Reuse / compose / candidate / blocked | Yes, blocked |
| 7 | Generate | `terraform-authoring`, `gitlab-cicd` | — | — |
| 8 | Validate | `compliance-validation` | `terraform_scan`, `pipeline_scan`, `secrets` | Records failures |
| 9 | Package | `gitlab-delivery` | Assemble `SolutionRecord` | Delivery is disabled in this phase |

Behavior:
- **Multi-turn.** If stage 2 finds material unknowns, the pipeline returns `status: needs_input` with questions. The caller answers through the same session.
- **Stage outputs are typed.** Each stage returns a pydantic model rather than free text. The final response is a `SolutionRecord` whose validation fields start as `not_run`.
- **Untrusted input.** User text and retrieved content are placed in clearly delimited user or tool message blocks, never in the system prompt (AGENTS.md §10).
- **Validation in this phase.** Only the in-process deterministic scans run. `terraform_validate`, `checkov`, and `pipeline_integrity` stay `not_run`, with a note that they run in the authoritative GitLab pipeline.
- **Session state.** It sits behind a `SessionStore` protocol. The first implementation is in-memory and single-task, for testing. The durable store is an open decision (§11).

### 4.4 Retrieval connectors (`agent_core.retrieval`)

Each connector implements `lookup(query) -> list[Evidence]`. `Evidence` holds the source system, URL or path, revision, retrieval time, and authority. If a connector has no configuration (`REPLACE_WITH_*` is still present in `agent/config/source-of-truth.yaml`), it returns `status: not_configured`, and the pipeline reports the affected facts as `unknown`. Phase 1 ships only the local catalog reader. Confluence and GitLab connectors come later, with read-only, project-scoped tokens injected at runtime from a secret store (§8).

### 4.5 Deterministic guardrails (`agent_core.guardrails`)

- `terraform_scan`: parses generated HCL and flags any resource type in `agent/policies/prohibited-resource-types.yaml`. It also flags module sources that aren't on the approved list, `local-exec`, `null_resource`, `external` data sources, and ingress open to `0.0.0.0/0` or `::/0`.
- `pipeline_scan`: flags removed `include:` templates, `allow_failure: true` on compliance jobs, Checkov `--skip-check` or soft-fail, and inline `#checkov:skip` suppressions.
- `secrets`: flags secret patterns in generated artifacts and redacts them from logs.

These scans are a pre-check only. Results appear under `validation.architecture_policy` with evidence. They never mark a solution `validated`.

## 5. FastAPI backend

### 5.1 API contract (v1)

All routes are under `/v1`. Breaking changes require `/v2`. The OpenAPI document at `/v1/openapi.json` is the integration contract for Cloud Help.

| Method | Path | Purpose |
|---|---|---|
| GET | `/healthz` | Liveness, with no dependencies |
| GET | `/readyz` | Content loaded, LLM client configured |
| GET | `/v1/agent/capabilities` | Agent name, version, `content_version`, supported stages, status vocabulary, and scope statement. Lets an orchestrating agent discover what this agent does |
| POST | `/v1/sessions` | Start a session with an initial infrastructure request |
| POST | `/v1/sessions/{session_id}/messages` | Continue a session (answers, clarifications) |
| GET | `/v1/sessions/{session_id}` | Session transcript and current state |
| GET | `/v1/solutions/{solution_id}` | `SolutionRecord` (JSON) |
| GET | `/v1/solutions/{solution_id}/artifacts` | Generated candidate files (paths + contents) |
| POST | `/v1/agent/invoke` | Single-shot, stateless call for agent-to-agent use. Returns either `needs_input` or a result |

Response envelope (all v1 responses):

```json
{
  "request_id": "uuid",
  "session_id": "uuid | null",
  "status": "needs_input | proposed | validation_pending | blocked | out_of_scope",
  "agent": { "name": "aws-govcloud-iac-agent", "version": "0.2.0", "content_version": "sha256:..." },
  "messages": [ { "role": "assistant", "content": "..." } ],
  "questions": [ { "id": "q1", "text": "...", "field": "landing_zone.accounts" } ],
  "solution": { "...": "SolutionRecord or null" },
  "blockers": [ { "code": "LZ-005", "detail": "..." } ]
}
```

`status` uses only values from `agent/config/agent.yaml` plus three API-level values: `needs_input`, `out_of_scope`, and `blocked`. This API never returns `validated`, `approved`, or `deployed`, because it cannot verify any of them.

### 5.2 Cross-cutting concerns

- **Authentication.** Every `/v1` route requires an authenticated caller through a pluggable `auth.py`:
  - Local development: a static token from the environment, used only when `APP_ENV=local`.
  - AWS: OIDC/JWT validation against the organization's identity provider. The UI and Cloud Help each get their own client identity.
  - Which identity provider and claims to use is an open question (§11).
- **Authorization.** Caller identity and permitted actions are logged per request. Later, write-capable actions such as creating merge requests would need their own scope.
- **Ownership.** A session belongs to the caller that created it: the token subject, plus `X-On-Behalf-Of` when a trusted client such as the UI names the end user. The service doesn't verify that header; it only scopes ownership and audit records. Other callers get `404` for the session and its solutions. Sessions created through `/v1/agent/invoke` have a separate owner, so their solutions can be read but the conversation can't be continued.
- **Concurrency.** A second message for a session that is still running returns `409`.
- **Correlation.** The API accepts `X-Request-ID` or generates one. It also accepts `X-Correlation-ID` from Cloud Help and propagates it to logs and Bedrock request metadata.
- **Errors.** Errors use RFC 7807 `application/problem+json`. Internal exceptions or Bedrock errors are never echoed verbatim.
- **Limits.** The API sets a request size limit, a per-caller rate limit, and a total stage timeout. Long runs are synchronous in phase 1. An async job model (`202` + polling) is reserved under `/v1/jobs` for later.
- **Server.** `uvicorn` runs behind the load balancer with `--proxy-headers` restricted to known proxy addresses.

### 5.3 Cloud Help integration path

1. Phase 1: Cloud Help calls `/v1/agent/invoke` or `/v1/sessions` over HTTPS with its own client identity.
2. Phase 2: if Cloud Help adopts an agent-to-agent protocol such as MCP or A2A, add a thin adapter (for example `services/api/agent_api/routers/a2a.py` or a separate service) that maps that protocol onto the same `agent_core` pipeline. The v1 REST contract stays.
3. Contract tests in `tests/api/` pin the v1 schema so changes that break Cloud Help fail in CI.

## 6. Streamlit frontend

Scope: an internal test harness, not a production portal.

- **Home.** A chat-style request entry. It shows the agent's questions as form fields when `questions` is present, keeps `session_id` in `st.session_state`, and shows `status` prominently.
- **Solution page.** Shows these parts of the `SolutionRecord`:
  - Requirement summary, and confirmed / assumed / unknown / prohibited items.
  - Selected patterns with provenance.
  - Generated files in code viewers, downloadable as a zip.
  - The validation table, showing `not_run` explicitly.
  - Blockers and next steps.
- **About page.** Shows API version, `content_version`, model ID, and environment, read from `/v1/agent/capabilities`.
- **Banner.** Every generated artifact is shown with a persistent "Candidate, not approved" banner.
- **API calls.** All calls go through `api_client.py` using `API_BASE_URL`. The UI depends only on the public `/v1` HTTP contract, not on `agent_core`.
- **UI identity.** Locally, the UI uses the shared static token. Deployed, it uses its own client identity through the OAuth 2.0 client credentials grant (`UI_AUTH_MODE=client_credentials`; the token endpoint and client registration are still to be confirmed).
- **End-user identity.** The UI sends the signed-in user as `X-On-Behalf-Of`. Outside local, the user comes only from a header set by the trusted sign-in proxy in front of the UI (`UI_USER_HEADER`). If that header is missing, access is denied. Users can't enter their own identity. The API rejects malformed `X-On-Behalf-Of` values with `400` rather than dropping them.
- **Rendering.** Agent, model, and user text is shown with `st.text` or `st.code`, never as markdown, so model output can't inject links or images for the browser to fetch. Widget labels use fixed text.
- **Streamlit config.** `server.headless=true`, `browser.gatherUsageStats=false`, XSRF protection on, file watcher and run-on-save off, and error details hidden. `server.enableCORS` stays `true`, because Streamlit requires it when XSRF protection is on.
- **No AWS access.** The UI has no AWS credentials and needs no IAM permissions beyond pulling its image and writing logs.

## 7. Containers

### 7.1 Dockerfiles

Both images follow the same pattern:
- Multi-stage build, with the base image passed in as `ARG BASE_IMAGE`. The organization's approved hardened Python base image must be supplied, and that image is not yet identified. Upstream `python:3.12-slim` is allowed only for local testing.
- Dependencies are installed into a virtual environment in the build stage. The runtime stage copies only that venv and the app code.
- The container runs as a non-root user (UID 10001). The root filesystem is read-only where supported, with a writable `/tmp` only.
- No secrets in build arguments or image layers. `.dockerignore` excludes `.env*`, `.git`, tests, and caches.
- A `HEALTHCHECK` hits `/healthz` (API) or `/_stcore/health` (Streamlit).

| Image | Copies | Entrypoint | Port |
|---|---|---|---|
| `iac-agent-api` | `agent_core` (installed into the venv), `services/api/agent_api`, `AGENTS.md`, and the contents of `agent/` into `/app/agent-content` | `uvicorn --factory agent_api.main:create_app --host 0.0.0.0 --port 8000 --proxy-headers --no-access-log` | 8000 |
| `iac-agent-ui` | `services/ui/agent_ui`, `.streamlit/config.toml`, shared models | `streamlit run agent_ui/Home.py --server.port 8501` | 8501 |

Agent content is baked into the API image, so each image tag maps to exactly one `content_version`. Content changes therefore go through the same CI and review path as code.

### 7.2 Local testing (`compose.yaml`)

- `api`: `LLM_PROVIDER=fake` by default. Setting `LLM_PROVIDER=bedrock` uses the developer's own AWS profile, mounted read-only from `~/.aws`. Credentials are never copied into the image.
- `ui`: `API_BASE_URL=http://api:8000`. It starts after the API reports healthy.
- Both bind to `127.0.0.1` only, run as UID 10001, and use read-only root filesystems with a `/tmp` tmpfs.
- `API_STATIC_TOKEN` is required. Compose reads it from `.env` and passes it to both services. Other settings come from `.env` when the file exists.

```text
cp .env.example .env                 # set API_STATIC_TOKEN (16+ characters)
docker compose up --build            # fake LLM, no AWS access needed
# Real Bedrock (authorized users only): set LLM_PROVIDER=bedrock, BEDROCK_REGION, and
# BEDROCK_MODEL_ID in .env, and uncomment the AWS profile mount in compose.yaml.
```

### 7.3 Settings (`.env.example`)

| Variable | Service | Notes |
|---|---|---|
| `APP_ENV` | both | `local`, `dev`, `test`, `prod` |
| `LOG_LEVEL` | both | |
| `AGENT_CONTENT_DIR` | api | Default `/app/agent-content` |
| `LLM_PROVIDER` | api | `fake` or `bedrock` |
| `BEDROCK_REGION` | api | Approved GovCloud Region. Value to be confirmed |
| `BEDROCK_MODEL_ID` | api | Model or inference profile ID. Value to be confirmed |
| `BEDROCK_ENDPOINT_URL` | api | Optional VPC endpoint URL |
| `LLM_MAX_TOKENS`, `LLM_TEMPERATURE`, `LLM_TIMEOUT_S` | api | |
| `AUTH_MODE` | api | `static_token` (local only) or `oidc` |
| `OIDC_ISSUER`, `OIDC_AUDIENCE` | api | To be confirmed |
| `API_BASE_URL` | ui | |

Secrets are never put in `.env.example`, compose files, task definitions as plaintext, or CI variables printed to logs.

## 8. GitLab CI/CD (`.gitlab-ci.yml`)

The pipeline should be built on the organization's approved GitLab templates through `include:`. Every project and template path below is a placeholder until it is confirmed.

| Stage | Jobs | Notes |
|---|---|---|
| `validate` | `repo-structure` (`scripts/validate_repository.py`), `ruff`, `mypy` | |
| `test` | `pytest-unit`, `pytest-api` (contract), `guardrail-scan-fixtures` | Fake LLM only. No AWS credentials in CI |
| `eval` | `guardrail-scenarios` (`tests/eval/run_scenarios.py`) | Fake LLM on every MR. A real-model eval job is manual or scheduled, runs only in an authorized environment, and its results are stored as artifacts |
| `build` | `build-api-image`, `build-ui-image` | Build with the approved builder (e.g. Kaniko or BuildKit, per template). Tag with commit SHA |
| `scan` | Container scanning, dependency scanning, SAST, secret detection | Use the approved security templates. Jobs must not use `allow_failure` |
| `publish` | Push images to ECR | Only on protected branches/tags. Runner uses OIDC to assume a push-only role. No long-lived keys |
| `iac-validate` | `terraform fmt -check`, `init -backend=false`, `validate` on `iac/`; prohibited-resource scan (`scripts/validate_repository.py`); Checkov via the approved compliance template | Runs on every MR that touches `iac/`. No AWS credentials |
| `iac-plan` / `deploy` | — | **Not defined here.** Plan and apply use the approved `tf` wrapper and deployment template, with their environment mapping and manual approval gates |

Rules:
- Nothing in this file may disable or soften required security or compliance jobs (`agent/policies/policy-checklist.yaml` CICD-001).
- No jobs run `terraform apply` or deploy to ECS from this pipeline unless the approved deployment template supplies that job and its approvals.
- MR pipelines publish nothing.

## 9. AWS hosting requirements

This section lists the requirements for the hosting IaC in `iac/`. That folder is a root module that calls Codebank patterns. It currently contains:
- Guardrail validations: GovCloud partition, pinned account, delivered-subnet checks, no public CIDRs, immutable image tags.
- Lookups of the existing network.
- The Bedrock least-privilege policy.
- Commented-out module templates for each component.

Each template stays commented out until `iac/pattern-references.yaml` records a verified Codebank project, path, approved revision, and documented interface for that component (see `iac/README.md`). Every item below is `proposed` or `unknown`.

| Concern | Requirement | Status |
|---|---|---|
| Compute | ECS (Fargate preferred) services for `api` and `ui` in application-owned account(s) | ECS enablement and pattern: unknown |
| Network | Use the delivered VPC and private subnets. **No new VPCs, subnets, or Transit Gateways** | VPC/subnet references: unknown |
| Ingress | An **internal** load balancer only, reachable through the delivered corporate network path. **No public ingress and no CloudFront** (Landing Zone restrictions) | Internal ALB pattern: unknown |
| UI → API | The UI reaches the API through an internal ALB listener rule or ECS Service Connect. The API is not exposed to end users directly | Design decision pending |
| TLS | TLS at the load balancer with a certificate from the approved private CA or ACM process | Unknown |
| Bedrock access | Prefer a Bedrock Runtime VPC interface endpoint. NAT Gateway access is requestable only and is not assumed | Endpoint availability: unknown |
| Images | ECR repositories with scan-on-push and immutable tags | ECR pattern: unknown |
| IAM | API task role allows `bedrock:InvokeModel` / `Converse` on the specific approved model ARN(s) only. UI task role has no AWS data permissions. **No IAM users** | Proposed |
| Secrets | GitLab read tokens and OIDC client secrets come from Secrets Manager or SSM SecureString through the ECS `secrets` integration | Service enablement: unknown |
| Logging | CloudWatch Logs with the org's retention and KMS requirements. Prompts and outputs are logged only per the approved data-handling policy | Policy: unknown |
| Environments | Separate dev / test / prod configuration, mapped to confirmed accounts | Account IDs: unknown |

## 10. Testing strategy

| Layer | What | Where |
|---|---|---|
| Unit | Content loader, fingerprint, stage logic, connectors' `not_configured` path, guardrail scanners | `tests/unit/`, `tests/guardrails/` |
| Contract | v1 request/response schemas, status vocabulary, error format, auth required | `tests/api/` |
| Guardrail eval | `tests/eval/guardrail-scenarios.yaml` against the pipeline. Asserts required and forbidden behaviors | `tests/eval/` |
| UI smoke | Streamlit app starts, renders a fake `SolutionRecord`, shows `not_run` | `tests/ui/` (optional, `streamlit.testing`) |

Passing prompt or eval tests is not proof of security (`tests/README.md`). Hard restrictions are enforced by deterministic checks, IAM, and the pipeline.

## 11. Open questions

1. Which Bedrock models or inference profiles are enabled for the approved GovCloud Region(s) and accounts? Is a Bedrock VPC endpoint available?
2. Which identity provider and token claims should authenticate the UI's users and Cloud Help's service identity?
3. What is Cloud Help's integration mechanism: REST, MCP, A2A, or something else? What are its timeout and streaming expectations?
4. Which approved base image, package mirror, image builder, and GitLab CI templates (security scanning, ECR publish, ECS deploy) should be used?
5. Are there approved Codebank patterns for ECS Fargate, internal ALB, ECR, and Secrets Manager?
6. Which store should hold durable session/solution state, and what are the data-retention and data-classification rules for prompts and generated artifacts?
7. Which target accounts, environments, and existing VPC/subnet references should hosting use?
8. Who owns this application and approves its content changes, versus the guardrail content owners in `docs/operating-model.md`?

## 12. Implementation phases

| Phase | Deliverables | Exit criteria |
|---|---|---|
| 1. Skeleton | `agent_core` with content loader, fake LLM, stage runner, deterministic scans. FastAPI v1 health, capabilities, and sessions routes. Streamlit Home/Solution pages. Dockerfiles, compose, CI `validate`/`test`/`eval`/`build` | `docker compose up` works with the fake LLM. Guardrail scenarios run in CI |
| 2. Bedrock | `BedrockClient` and the settings it needs, tested against confirmed models in an authorized environment | Open question 1 resolved. Real-model eval results recorded |
| 3. Retrieval | Read-only catalog, Confluence, and GitLab connectors with evidence | Source placeholders replaced. Provenance appears in `SolutionRecord` |
| 4. Hosting | ECS hosting IaC via Codebank patterns, `scan`/`publish` CI stages, approved deploy template | Internal-only access verified. Required approvals complete |
| 5. Cloud Help | Production auth, contract versioning, an optional protocol adapter | Cloud Help contract tests pass. Integration agreed with the Cloud Help owners |
