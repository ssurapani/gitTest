#!/usr/bin/env python3
"""Basic repository sanity checks; this is not a Terraform or policy validator."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
AGENT = "agent"
REQUIRED = [
    "AGENTS.md",
    "README.md",
    "design.md",
    f"{AGENT}/config/agent.yaml",
    f"{AGENT}/config/landing-zone-guardrails.yaml",
    f"{AGENT}/config/source-of-truth.yaml",
    f"{AGENT}/policies/prohibited-resource-types.yaml",
    f"{AGENT}/workflows/solution-decision-workflow.md",
    f"{AGENT}/skills/requirements-discovery/SKILL.md",
    f"{AGENT}/skills/landing-zone-guardrails/SKILL.md",
    f"{AGENT}/skills/service-enablement/SKILL.md",
    f"{AGENT}/skills/codebank-discovery/SKILL.md",
    f"{AGENT}/skills/iac-composition/SKILL.md",
    f"{AGENT}/skills/terraform-authoring/SKILL.md",
    f"{AGENT}/skills/gitlab-cicd/SKILL.md",
    f"{AGENT}/skills/compliance-validation/SKILL.md",
    f"{AGENT}/skills/gitlab-delivery/SKILL.md",
    f"{AGENT}/skills/pattern-gap-analysis/SKILL.md",
    "iac/pattern-references.yaml",
    "tests/eval/guardrail-scenarios.yaml",
]


def prohibited_resource_types() -> list[str]:
    """Read the prohibited list without a YAML dependency (simple block-list format only)."""
    path = ROOT / AGENT / "policies" / "prohibited-resource-types.yaml"
    types, in_list = [], False
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.startswith("prohibited_terraform_resource_types:"):
            in_list = True
        elif in_list and line.startswith("  - "):
            types.append(line[4:].strip())
        elif in_list and line.strip():
            break
    return types


def scan_iac(types: list[str]) -> list[str]:
    """Flag uncommented resource declarations of prohibited types in iac/*.tf files.

    Does not inspect resources created inside modules; plan-level checks are still required.
    """
    pattern = re.compile(r'^\s*resource\s+"(' + "|".join(map(re.escape, types)) + r')"')
    findings = []
    for path in sorted((ROOT / "iac").rglob("*.tf")):
        if ".terraform" in path.parts:
            continue
        for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
            if pattern.match(line):
                findings.append(f"{path.relative_to(ROOT)}:{number}: {line.strip()}")
    return findings


missing = [path for path in REQUIRED if not (ROOT / path).is_file()]
if missing:
    print("Missing required repository files:")
    for item in missing:
        print(f" - {item}")
    sys.exit(1)

findings = scan_iac(prohibited_resource_types())
if findings:
    print("Prohibited resource types declared in iac/:")
    for item in findings:
        print(f" - {item}")
    sys.exit(1)

placeholders = []
for path in (ROOT / AGENT / "config").glob("*.yaml"):
    content = path.read_text(encoding="utf-8")
    if "REPLACE_WITH_" in content:
        placeholders.append(str(path.relative_to(ROOT)))

print(f"Repository structure check passed: {len(REQUIRED)} required files found.")
print("Prohibited resource scan of iac/*.tf passed (root module only; modules not inspected).")
if placeholders:
    print("Configuration still contains placeholders; replace before integration:")
    for item in placeholders:
        print(f" - {item}")
print("Note: this script does not validate YAML syntax or enforce cloud security policy.")
