# Operating Model

## Roles

- Application user: describes requirements and confirms proposed design.
- IaC agent: retrieves knowledge, proposes architecture, generates candidate code, and reports evidence.
- CAS IaC/Codebank maintainers: review and approve reusable patterns and examples.
- Cloud Foundation/Landing Zone owner: owns account, network, and platform restrictions.
- Compliance owner: owns Checkov rules and authoritative compliance workflow.
- GitLab pipeline: performs required validation and deployment stages.
- Authorized reviewer/deployer: approves and executes changes according to existing controls.

## Artifact lifecycle

`requested -> requirements_confirmed -> design_proposed -> code_generated -> validation_pending -> validated_or_failed -> review_pending -> approved -> deployed`

Only advance a state when the responsible system confirms it. A generated file is not approved merely because it looks correct.

## Exceptions

Exceptions must follow the organization's existing governance process. The agent can prepare an exception request but cannot authorize one.
