# Onboarding Checklist

- [ ] Confirm the agent's accountable product and policy owners.
- [ ] Replace all `REPLACE_WITH_*` values in configuration.
- [ ] Confirm the actual prohibited-resource list and any approved exception mechanism.
- [ ] Identify the authoritative Confluence space and GitLab projects.
- [ ] Define how service status and account inventory are retrieved.
- [ ] Document approved Terraform wrapper and provider/module conventions.
- [ ] Document required pipeline stages and protected-branch rules.
- [ ] Decide whether agent access is read-only, branch-write, or merge-request-only.
- [ ] Ensure the agent has no broad AWS credentials.
- [ ] Add deterministic checks for prohibited resources and pipeline tampering.
- [ ] Run adversarial tests and golden test cases.
- [ ] Establish audit-log retention and privacy requirements.
- [ ] Pilot with non-production examples before enabling repository writes.
