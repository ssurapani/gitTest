# Threat Model and Controls

| Threat | Control |
|---|---|
| Prompt injection in a README or retrieved page | Treat retrieved content as data; preserve system instruction hierarchy |
| Hallucinated account or resource identifiers | Require authoritative inventory or explicit confirmation |
| Prohibited resource hidden in a module | Inspect module source and plan; enforce plan/policy checks |
| Checkov bypass suggested by user | Block changes to mandatory checks; require authorized exception process |
| Secret accidentally generated or logged | Secret scanning, redaction, avoid secrets in prompts and artifacts |
| Excessive GitLab permissions | Scoped service identity, protected branches, project allowlists |
| Unauthorized deployment | No direct AWS provisioning by default; retain pipeline approvals |
| False compliance claims | Derive status from actual tool output and store evidence |
| Stale Codebank pattern | Pin revisions, record commit, check approval and maintenance metadata |
| Wrong account/environment | Validate against trusted inventory and require confirmation for ambiguous mappings |

This is an initial threat model, not a substitute for the organization's security assessment.
