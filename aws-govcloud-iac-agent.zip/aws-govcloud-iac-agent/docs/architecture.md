# Reference Architecture

## Logical flow

1. User submits an infrastructure need.
2. Requirements skill gathers only material missing details.
3. Retrieval layer consults approved service, Codebank, standards, pipeline, and account sources.
4. Decision workflow selects reuse, composition, new candidate pattern, or blocked/escalation.
5. Generator produces Terraform, environment configuration, tests, docs, and pipeline configuration.
6. Deterministic validation checks architecture constraints and code quality.
7. Existing Checkov and GitLab pipelines provide authoritative validation.
8. An authorized GitLab workflow creates a branch/merge request.
9. Human reviewers approve changes; deployment remains within established authorized pipelines.

## Design principles

- One orchestrating agent first; specialized skills are task modules, not necessarily separate agents.
- Retrieval and code generation are separate steps.
- Policy checks must be deterministic wherever practical.
- The agent should not hold broad AWS credentials.
- Source provenance and actual validation results are required.
- Do not make the model the sole enforcement point for prohibited resources.
