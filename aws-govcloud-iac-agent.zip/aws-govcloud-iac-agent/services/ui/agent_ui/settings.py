"""UI settings. UI-specific variables use the UI_ prefix so they can share a .env with the API."""
from typing import Literal

from pydantic import Field, SecretStr, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class UiSettings(BaseSettings):
    model_config = SettingsConfigDict(env_file=None, extra="ignore")

    app_env: Literal["local", "dev", "test", "prod"] = "local"
    api_base_url: str = "http://127.0.0.1:8000"
    # Longer than the API's per-turn timeout so the API reports timeouts, not the client.
    api_timeout_s: float = Field(default=330, gt=0)

    ui_auth_mode: Literal["static_token", "client_credentials"] = "static_token"
    # Local development only; the same value as the API's API_STATIC_TOKEN.
    api_static_token: SecretStr | None = None
    # OAuth 2.0 client credentials for the UI's own identity. Confirm with the identity team.
    ui_oidc_token_url: str | None = None
    ui_oidc_client_id: str | None = None
    ui_oidc_client_secret: SecretStr | None = None
    ui_oidc_scope: str | None = None

    # Header carrying the signed-in user, set by the trusted sign-in proxy in front of the UI.
    # Required outside local; the UI never lets users type their own identity.
    ui_user_header: str | None = None
    ui_local_user: str = "local-user"

    @model_validator(mode="after")
    def _check(self) -> "UiSettings":
        if not self.api_base_url.startswith(("http://", "https://")):
            raise ValueError("API_BASE_URL must be an http(s) URL")
        if self.ui_auth_mode == "static_token":
            if self.app_env != "local":
                raise ValueError("UI_AUTH_MODE=static_token is only allowed when APP_ENV=local")
            if not self.api_static_token:
                raise ValueError("API_STATIC_TOKEN must be set for UI_AUTH_MODE=static_token")
        elif not (self.ui_oidc_token_url and self.ui_oidc_client_id and self.ui_oidc_client_secret):
            raise ValueError("UI_AUTH_MODE=client_credentials requires UI_OIDC_TOKEN_URL, "
                             "UI_OIDC_CLIENT_ID, and UI_OIDC_CLIENT_SECRET")
        if self.app_env != "local" and not self.ui_user_header:
            raise ValueError("UI_USER_HEADER is required outside APP_ENV=local")
        return self
