"""Streamlit test harness for the agent API. It is a client of the public /v1 contract only."""
