"""Request entry and conversation with the agent."""
import streamlit as st

from agent_ui.api_client import ApiError
from agent_ui.common import current_user, get_client, plain, show_error, status_badge

st.set_page_config(page_title="IaC Agent", layout="wide")
client = get_client()
user = current_user()
state = st.session_state
for key, default in (("session_id", None), ("turns", []), ("last", None), ("error", None),
                     ("solution_id", None)):
    state.setdefault(key, default)

st.title("GovCloud IaC Agent")
st.caption("Test harness for the agent API. Generated output is a candidate for review; "
           "it is never approved or deployed from here.")

with st.sidebar:
    plain(f"Signed in as: {user}")
    if state.session_id:
        plain(f"Session: {state.session_id}")
    if st.button("New session"):
        for key in ("session_id", "turns", "last", "error", "solution_id"):
            del state[key]
        st.rerun()


def submit(message: str) -> None:
    try:
        with st.spinner("The agent is working..."):
            if state.session_id:
                response = client.send_message(state.session_id, message, user=user)
            else:
                response = client.create_session(message, user=user)
    except ApiError as error:
        state.error = error
        return
    state.error = None
    state.session_id = response["session_id"]
    state.turns = state.turns + [{"role": "user", "content": message}] + response["messages"]
    state.last = response
    if response.get("solution"):
        state.solution_id = response["solution"]["id"]


if state.error:
    show_error(state.error)

for turn in state.turns:
    with st.chat_message(turn["role"]):
        plain(turn["content"])

last = state.last
if last:
    status_badge(last["status"])
    if last["questions"]:
        with st.form("answers", clear_on_submit=True):
            st.subheader("Questions from the agent")
            answers = []
            for index, question in enumerate(last["questions"], start=1):
                plain(f"{index}. {question['text']}")
                answers.append((question, st.text_input(f"Answer {index}", key=f"answer_{question['id']}")))
            if st.form_submit_button("Send answers"):
                lines = [f"{q['text']} {a.strip()}" for q, a in answers if a.strip()]
                if lines:
                    submit("\n".join(lines))
                    st.rerun()
    if last.get("solution"):
        st.page_link("pages/1_Solution.py", label="Open the solution record")

prompt = st.chat_input("Describe the infrastructure you need")
if prompt:
    submit(prompt)
    st.rerun()
