"""Shared page helpers.

Agent, model, and user text is rendered with st.text or st.code, never as markdown, so content
from the model cannot inject links or images that the browser would fetch.
"""
import io
import zipfile
from pathlib import PurePosixPath

import streamlit as st

from agent_ui.api_client import ApiClient, ApiError, build_client
from agent_ui.settings import UiSettings

CANDIDATE_BANNER = ("Candidate output: not approved, not validated by Checkov or the GitLab "
                    "pipeline, and not deployed.")
_STATUS = {
    "needs_input": ("Needs input", "orange"),
    "proposed": ("Proposed", "blue"),
    "validation_pending": ("Validation pending", "blue"),
    "blocked": ("Blocked", "red"),
    "out_of_scope": ("Out of scope", "gray"),
}
_LANGUAGES = {".tf": "hcl", ".tfvars": "hcl", ".hcl": "hcl", ".yml": "yaml", ".yaml": "yaml",
              ".json": "json", ".md": "markdown", ".py": "python", ".sh": "bash"}


@st.cache_resource
def get_settings() -> UiSettings:
    return UiSettings()


@st.cache_resource
def get_client() -> ApiClient:
    return build_client(get_settings())


def current_user() -> str:
    settings = get_settings()
    if settings.ui_user_header:
        user = st.context.headers.get(settings.ui_user_header)
        if not user:
            st.error("Your identity was not provided by the sign-in proxy. Access is denied.")
            st.stop()
        return user
    return settings.ui_local_user


def status_badge(status: str | None) -> None:
    label, color = _STATUS.get(status or "", ("Unknown", "gray"))
    st.markdown(f"Status: :{color}[**{label}**]")  # label comes from the fixed table above


def plain(text: str) -> None:
    st.text(text)


def show_error(error: ApiError) -> None:
    st.error("The agent API returned an error.")
    parts = [f"{error.status} {error.title}" if error.status else error.title]
    if error.detail:
        parts.append(error.detail)
    if error.request_id:
        parts.append(f"Request ID: {error.request_id}")
    plain("\n".join(parts))


def language_for(path: str) -> str | None:
    return _LANGUAGES.get(PurePosixPath(path).suffix)


def artifacts_zip(artifacts: list[dict], notice: str = CANDIDATE_BANNER) -> bytes:
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("CANDIDATE-NOT-APPROVED.txt", notice + "\n")
        for artifact in artifacts:
            path = PurePosixPath(artifact["path"])
            if path.is_absolute() or ".." in path.parts:
                continue  # the API validates paths; skip anything unexpected
            archive.writestr(str(path), artifact["content"])
    return buffer.getvalue()
