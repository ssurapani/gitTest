"""HTTP client for the agent API /v1 contract. Returns plain JSON dicts."""
import threading
import time
import uuid
from typing import Any, Protocol

import httpx

from agent_ui.settings import UiSettings


class ApiError(Exception):
    def __init__(self, status: int, title: str, detail: str | None = None,
                 request_id: str | None = None):
        super().__init__(f"{status} {title}")
        self.status = status
        self.title = title
        self.detail = detail
        self.request_id = request_id


class TokenProvider(Protocol):
    def token(self) -> str: ...


class StaticTokenProvider:
    def __init__(self, token: str):
        self._token = token

    def token(self) -> str:
        return self._token


class ClientCredentialsTokenProvider:
    """OAuth 2.0 client credentials grant with in-memory caching until shortly before expiry."""

    def __init__(self, *, token_url: str, client_id: str, client_secret: str,
                 scope: str | None = None, http: httpx.Client | None = None,
                 clock=time.monotonic):
        self._url = token_url
        self._form = {"grant_type": "client_credentials", "client_id": client_id,
                      "client_secret": client_secret, **({"scope": scope} if scope else {})}
        self._http = http or httpx.Client(timeout=10)
        self._clock = clock
        self._lock = threading.Lock()
        self._cached: tuple[str, float] | None = None

    def token(self) -> str:
        with self._lock:
            if self._cached and self._clock() < self._cached[1]:
                return self._cached[0]
            try:
                response = self._http.post(self._url, data=self._form)
                response.raise_for_status()
                body = response.json()
                token = body["access_token"]
            except (httpx.HTTPError, ValueError, KeyError) as exc:
                raise ApiError(0, "Could not obtain an API token", type(exc).__name__) from exc
            lifetime = float(body.get("expires_in", 300))
            self._cached = (token, self._clock() + max(lifetime - 60, 0))
            return token


class ApiClient:
    def __init__(self, base_url: str, tokens: TokenProvider, *, timeout: float = 330,
                 http: httpx.Client | None = None):
        self._http = http or httpx.Client(base_url=base_url, timeout=timeout, follow_redirects=False)
        self._tokens = tokens

    def _request(self, method: str, path: str, *, user: str | None,
                 json: dict[str, Any] | None = None) -> dict[str, Any]:
        headers = {"Authorization": f"Bearer {self._tokens.token()}",
                   "X-Request-ID": str(uuid.uuid4())}
        if user:
            headers["X-On-Behalf-Of"] = user
        try:
            response = self._http.request(method, path, json=json, headers=headers)
        except httpx.HTTPError as exc:
            raise ApiError(0, "API unreachable", type(exc).__name__, headers["X-Request-ID"]) from exc
        if response.status_code >= 400:
            try:
                problem = response.json()
            except ValueError:
                problem = {}
            raise ApiError(response.status_code, problem.get("title") or response.reason_phrase,
                           problem.get("detail"),
                           problem.get("instance") or response.headers.get("x-request-id"))
        return response.json()

    def capabilities(self, *, user: str | None = None) -> dict[str, Any]:
        return self._request("GET", "/v1/agent/capabilities", user=user)

    def create_session(self, message: str, *, user: str) -> dict[str, Any]:
        return self._request("POST", "/v1/sessions", user=user, json={"message": message})

    def send_message(self, session_id: str, message: str, *, user: str) -> dict[str, Any]:
        return self._request("POST", f"/v1/sessions/{session_id}/messages", user=user,
                             json={"message": message})

    def get_session(self, session_id: str, *, user: str) -> dict[str, Any]:
        return self._request("GET", f"/v1/sessions/{session_id}", user=user)

    def get_solution(self, solution_id: str, *, user: str) -> dict[str, Any]:
        return self._request("GET", f"/v1/solutions/{solution_id}", user=user)


def build_client(settings: UiSettings) -> ApiClient:
    tokens: TokenProvider
    if settings.ui_auth_mode == "static_token":
        assert settings.api_static_token is not None
        tokens = StaticTokenProvider(settings.api_static_token.get_secret_value())
    else:
        assert settings.ui_oidc_client_secret is not None
        tokens = ClientCredentialsTokenProvider(
            token_url=settings.ui_oidc_token_url or "",
            client_id=settings.ui_oidc_client_id or "",
            client_secret=settings.ui_oidc_client_secret.get_secret_value(),
            scope=settings.ui_oidc_scope,
        )
    return ApiClient(settings.api_base_url, tokens, timeout=settings.api_timeout_s)
