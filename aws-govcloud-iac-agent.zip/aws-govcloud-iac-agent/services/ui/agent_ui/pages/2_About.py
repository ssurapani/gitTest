"""Agent capabilities, content version, model, and environment."""
import streamlit as st

from agent_ui.api_client import ApiError
from agent_ui.common import current_user, get_client, get_settings, plain, show_error

st.set_page_config(page_title="About | IaC Agent", layout="wide")
client = get_client()
user = current_user()
settings = get_settings()

st.title("About this agent")
plain(f"UI environment: {settings.app_env}\nAPI: {settings.api_base_url}\nSigned in as: {user}")

try:
    capabilities = client.capabilities(user=user)
except ApiError as error:
    show_error(error)
    st.stop()

plain(capabilities["scope"])
st.json(capabilities)
