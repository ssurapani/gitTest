"""Solution record: requirements, patterns, validation, artifacts, blockers, next steps."""
import streamlit as st

from agent_ui.api_client import ApiError
from agent_ui.common import (
    CANDIDATE_BANNER,
    artifacts_zip,
    current_user,
    get_client,
    language_for,
    plain,
    show_error,
    status_badge,
)

VALIDATION_CHECKS = ("requirements", "architecture_policy", "terraform_validate", "naming_tagging",
                     "checkov", "pipeline_integrity")

st.set_page_config(page_title="Solution | IaC Agent", layout="wide")
client = get_client()
user = current_user()

st.title("Solution record")
solution_id = st.query_params.get("solution_id") or st.session_state.get("solution_id")
if not solution_id:
    st.info("No solution yet. Start a request on the Home page.")
    st.stop()

try:
    response = client.get_solution(solution_id, user=user)
except ApiError as error:
    show_error(error)
    st.stop()

solution = response["solution"]
st.warning(CANDIDATE_BANNER)
status_badge(response["status"])
plain(f"Solution: {solution['id']}\nDecision: {solution['decision'] or '-'}\n"
      f"Content version: {solution['content_version']}\nModel: {solution['model_id']}")

requirements_tab, patterns_tab, validation_tab, artifacts_tab, blockers_tab = st.tabs(
    ["Requirements", "Patterns and evidence", "Validation", "Artifacts", "Blockers and next steps"])

with requirements_tab:
    requirements = solution.get("requirements")
    if not requirements:
        plain("No requirements were recorded (the request was blocked before extraction).")
    else:
        plain(requirements["summary"] or "(no summary)")
        plain("Services: " + (", ".join(requirements["services"]) or "-"))
        plain("Regions: " + (", ".join(requirements["regions"]) or "-"))
        if requirements["accounts"]:
            st.dataframe(requirements["accounts"], use_container_width=True)
        log = requirements["decision_log"]
        columns = st.columns(5)
        for column, (key, title) in zip(columns, (
                ("confirmed_facts", "Confirmed"), ("proposed_decisions", "Proposed"),
                ("assumptions", "Assumptions"), ("unknowns", "Unknown"),
                ("prohibited_requirements", "Prohibited"))):
            with column:
                st.subheader(title)
                plain("\n".join(f"- {item}" for item in log[key]) or "-")

with patterns_tab:
    st.subheader("Selected Codebank patterns")
    if solution["selected_patterns"]:
        st.dataframe(solution["selected_patterns"], use_container_width=True)
    else:
        plain("None selected.")
    st.subheader("Service enablement evidence")
    if solution["service_enablement_evidence"]:
        st.dataframe(solution["service_enablement_evidence"], use_container_width=True)
    else:
        plain("No verified evidence.")

with validation_tab:
    validation = solution["validation"]
    st.dataframe([{"check": check, "status": validation[check]} for check in VALIDATION_CHECKS],
                 use_container_width=True, hide_index=True)
    plain("not_run means the check has not executed. Checkov, terraform validate, and the "
          "GitLab pipeline run outside this tool.")
    if validation["findings"]:
        st.subheader("Findings")
        st.dataframe(validation["findings"], use_container_width=True, hide_index=True)
    if validation["evidence"]:
        st.subheader("Evidence")
        plain("\n".join(validation["evidence"]))

with artifacts_tab:
    artifacts = solution["artifacts"]
    if not artifacts:
        plain("No artifacts were generated.")
    else:
        st.download_button("Download candidate files (.zip)", artifacts_zip(artifacts),
                           file_name=f"candidate-{solution['id'][:8]}.zip",
                           mime="application/zip")
        for artifact in artifacts:
            plain(artifact["path"])
            st.code(artifact["content"], language=language_for(artifact["path"]))

with blockers_tab:
    st.subheader("Blockers")
    if solution["blockers"]:
        for blocker in solution["blockers"]:
            plain(f"[{blocker['code']}] {blocker['detail']}"
                  + (f"\nNext: {blocker['remediation']}" if blocker.get("remediation") else ""))
    else:
        plain("None.")
    st.subheader("Required approvals")
    plain("\n".join(f"- {a}" for a in solution["approvals_required"]) or "-")
    st.subheader("Next steps")
    plain("\n".join(f"- {s}" for s in solution["next_steps"]) or "-")
