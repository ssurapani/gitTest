"""The v1 contract. Changes here that break existing fields require /v2."""
from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from agent_core.models import (
    Artifact,
    Blocker,
    Question,
    RequirementsRecord,
    ResponseStatus,
    SolutionRecord,
    SolutionStatus,
)

API_VERSION = "v1"
CANDIDATE_NOTICE = ("Candidate artifacts: not approved, not validated by Checkov or the GitLab "
                    "pipeline, and not deployed.")


class MessageRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    message: str = Field(min_length=1, max_length=20000)


class AgentInfo(BaseModel):
    name: str
    version: str
    content_version: str
    model_id: str


class ChatMessage(BaseModel):
    role: Literal["user", "assistant"]
    content: str
    at: datetime | None = None


class AgentResponse(BaseModel):
    request_id: str
    session_id: str | None
    status: ResponseStatus
    agent: AgentInfo
    messages: list[ChatMessage] = Field(default_factory=list)
    questions: list[Question] = Field(default_factory=list)
    solution: SolutionRecord | None = None
    blockers: list[Blocker] = Field(default_factory=list)


class SessionView(BaseModel):
    request_id: str
    session_id: str
    status: ResponseStatus | None
    agent: AgentInfo
    created_at: datetime
    updated_at: datetime
    turns: list[ChatMessage]
    requirements: RequirementsRecord | None
    solution_ids: list[str]


class ArtifactsResponse(BaseModel):
    request_id: str
    solution_id: str
    status: SolutionStatus
    notice: str = CANDIDATE_NOTICE
    artifacts: list[Artifact]


class Capabilities(BaseModel):
    request_id: str
    api_version: str = API_VERSION
    name: str
    version: str
    content_version: str
    purpose: str
    execution_mode: str
    scope: str
    model_id: str
    stages: list[str]
    statuses: list[str]
    catalog_entries: int
