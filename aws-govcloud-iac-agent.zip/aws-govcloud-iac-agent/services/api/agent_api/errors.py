"""RFC 7807 problem responses. Internal and Bedrock error details are never echoed."""
import logging

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

from agent_core.observability import current_request_id
from agent_core.orchestration import InvalidRequest, SessionNotFound

log = logging.getLogger(__name__)
PROBLEM_JSON = "application/problem+json"


class AuthError(Exception):
    pass


class RateLimited(Exception):
    def __init__(self, retry_after_s: int):
        super().__init__("Rate limit exceeded")
        self.retry_after_s = retry_after_s


class SessionBusy(Exception):
    pass


class TurnTimeout(Exception):
    pass


def problem(status: int, title: str, detail: str | None = None, *,
            headers: dict[str, str] | None = None, **extra) -> JSONResponse:
    body = {"type": "about:blank", "title": title, "status": status, "detail": detail,
            "instance": current_request_id(), **extra}
    return JSONResponse(body, status_code=status, media_type=PROBLEM_JSON, headers=headers)


def install_error_handlers(app: FastAPI) -> None:
    @app.exception_handler(AuthError)
    async def _auth(request: Request, exc: AuthError):
        return problem(401, "Unauthorized", str(exc), headers={"WWW-Authenticate": "Bearer"})

    @app.exception_handler(RateLimited)
    async def _rate(request: Request, exc: RateLimited):
        return problem(429, "Too Many Requests", "Rate limit exceeded",
                       headers={"Retry-After": str(exc.retry_after_s)})

    @app.exception_handler(SessionNotFound)
    async def _not_found(request: Request, exc: SessionNotFound):
        return problem(404, "Not Found", "Session or solution not found")

    @app.exception_handler(SessionBusy)
    async def _busy(request: Request, exc: SessionBusy):
        return problem(409, "Conflict", "Another message for this session is still being processed")

    @app.exception_handler(TurnTimeout)
    async def _timeout(request: Request, exc: TurnTimeout):
        return problem(504, "Gateway Timeout", "The agent did not finish in time; retry later")

    @app.exception_handler(InvalidRequest)
    async def _invalid(request: Request, exc: InvalidRequest):
        return problem(422, "Unprocessable Content", str(exc))

    @app.exception_handler(RequestValidationError)
    async def _validation(request: Request, exc: RequestValidationError):
        # Report locations and messages only; never echo submitted input.
        errors = [{"loc": list(e.get("loc", ())), "msg": e.get("msg", "")} for e in exc.errors()]
        return problem(422, "Unprocessable Content", "Request validation failed", errors=errors)

    @app.exception_handler(StarletteHTTPException)
    async def _http(request: Request, exc: StarletteHTTPException):
        detail = exc.detail if exc.status_code < 500 else None
        return problem(exc.status_code, _TITLES.get(exc.status_code, "Error"), detail,
                       headers=getattr(exc, "headers", None))


_TITLES = {400: "Bad Request", 404: "Not Found", 405: "Method Not Allowed"}
