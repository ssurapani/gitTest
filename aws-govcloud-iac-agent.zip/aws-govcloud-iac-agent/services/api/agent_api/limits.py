"""Process-local limits. With more than one task, move these to a shared store."""
import math
import threading
import time
from collections import defaultdict, deque
from collections.abc import Callable, Iterator
from contextlib import contextmanager

from agent_api.errors import RateLimited, SessionBusy


class RateLimiter:
    """Sliding one-minute window per caller."""

    def __init__(self, per_minute: int, clock: Callable[[], float] = time.monotonic):
        self._limit = per_minute
        self._clock = clock
        self._hits: dict[str, deque[float]] = defaultdict(deque)
        self._lock = threading.Lock()

    def check(self, key: str) -> None:
        now = self._clock()
        with self._lock:
            hits = self._hits[key]
            while hits and now - hits[0] >= 60:
                hits.popleft()
            if len(hits) >= self._limit:
                raise RateLimited(max(1, math.ceil(60 - (now - hits[0]))))
            hits.append(now)


class SessionLocks:
    """Rejects concurrent turns on the same session instead of interleaving them."""

    def __init__(self):
        self._busy: set[str] = set()
        self._lock = threading.Lock()

    @contextmanager
    def hold(self, session_id: str | None) -> Iterator[None]:
        if session_id is None:
            yield
            return
        with self._lock:
            if session_id in self._busy:
                raise SessionBusy(session_id)
            self._busy.add(session_id)
        try:
            yield
        finally:
            with self._lock:
                self._busy.discard(session_id)
