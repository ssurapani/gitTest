"""App factory. Run with: uvicorn --factory agent_api.main:create_app"""
import logging
import time
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request

from agent_core import __version__
from agent_core.factory import Agent, build_agent
from agent_core.observability import configure_logging, request_context
from agent_core.settings import Settings
from agent_api.auth import Authenticator, build_authenticator
from agent_api.errors import install_error_handlers, problem
from agent_api.limits import RateLimiter, SessionLocks
from agent_api.routers import health
from agent_api.routers.v1 import router as v1_router
from agent_api.settings import ApiSettings

log = logging.getLogger("agent_api")


def create_app(
    *,
    agent: Agent | None = None,
    api_settings: ApiSettings | None = None,
    authenticator: Authenticator | None = None,
) -> FastAPI:
    api_settings = api_settings or ApiSettings()

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        if agent is None:
            settings = Settings()
            configure_logging(settings.log_level)
            app.state.agent = build_agent(settings)  # fails fast on bad or unsafe content
        else:
            app.state.agent = agent
        log.info("Agent loaded", extra={"content_version": app.state.agent.content.version,
                                        "model_id": app.state.agent.llm.model_id})
        yield

    docs = api_settings.docs_enabled
    app = FastAPI(
        title="AWS GovCloud IaC Agent API",
        version=__version__,
        openapi_url="/v1/openapi.json",
        docs_url="/v1/docs" if docs else None,
        redoc_url=None,
        lifespan=lifespan,
    )
    app.state.api_settings = api_settings
    app.state.authenticator = authenticator or build_authenticator(api_settings)
    app.state.rate_limiter = RateLimiter(api_settings.rate_limit_per_minute)
    app.state.session_locks = SessionLocks()

    @app.middleware("http")
    async def request_middleware(request: Request, call_next):
        with request_context(request.headers.get("x-request-id"),
                             request.headers.get("x-correlation-id")) as request_id:
            started = time.perf_counter()
            length = request.headers.get("content-length", "")
            if length.isdigit() and int(length) > api_settings.max_body_bytes:
                response = problem(413, "Content Too Large", "Request body is too large")
            else:
                try:
                    response = await call_next(request)
                except Exception:
                    log.exception("Unhandled error")
                    response = problem(500, "Internal Server Error", "Unexpected error")
            response.headers["X-Request-ID"] = request_id
            response.headers["Cache-Control"] = "no-store"
            response.headers["X-Content-Type-Options"] = "nosniff"
            caller = getattr(request.state, "caller", None)
            log.info(
                "%s %s %s", request.method, request.url.path, response.status_code,
                extra={"status": response.status_code,
                       "duration_ms": round((time.perf_counter() - started) * 1000),
                       "subject": caller.subject if caller else None,
                       "client_id": caller.client_id if caller else None},
            )
            return response

    install_error_handlers(app)
    app.include_router(health.router)
    app.include_router(v1_router)
    return app
