"""Caller authentication. Every /v1 route depends on require_caller."""
import hmac
import re
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, Protocol

import jwt
from fastapi import HTTPException, Request

from agent_api.errors import AuthError
from agent_api.settings import ApiSettings

_SAFE_USER = re.compile(r"^[\w.@:+-]{1,128}$")


@dataclass(frozen=True)
class Caller:
    subject: str
    client_id: str | None
    # End user named by a trusted client (for example the UI) for audit and session ownership.
    # It is asserted by the client, not verified by this service.
    on_behalf_of: str | None = None

    @property
    def owner(self) -> str:
        return f"{self.subject}/{self.on_behalf_of}" if self.on_behalf_of else self.subject


class Authenticator(Protocol):
    def authenticate(self, token: str) -> tuple[str, str | None]:
        """Return (subject, client_id) or raise AuthError."""
        ...


class StaticTokenAuthenticator:
    """Local development only (enforced by ApiSettings)."""

    def __init__(self, token: str):
        self._token = token.encode()

    def authenticate(self, token: str) -> tuple[str, str | None]:
        if not hmac.compare_digest(token.encode(), self._token):
            raise AuthError("Invalid credentials")
        return "local-developer", "local"


class OidcAuthenticator:
    def __init__(
        self,
        *,
        issuer: str,
        audience: str,
        algorithms: list[str],
        key_resolver: Callable[[str], Any],
    ):
        self._issuer = issuer
        self._audience = audience
        self._algorithms = algorithms
        self._resolve_key = key_resolver

    @classmethod
    def from_jwks_url(cls, *, issuer: str, audience: str, algorithms: list[str], jwks_url: str):
        client = jwt.PyJWKClient(jwks_url, cache_keys=True)
        return cls(issuer=issuer, audience=audience, algorithms=algorithms,
                   key_resolver=lambda token: client.get_signing_key_from_jwt(token).key)

    def authenticate(self, token: str) -> tuple[str, str | None]:
        try:
            claims = jwt.decode(
                token,
                self._resolve_key(token),
                algorithms=self._algorithms,
                audience=self._audience,
                issuer=self._issuer,
                options={"require": ["exp", "iat", "sub"]},
            )
        except jwt.PyJWTError as exc:
            raise AuthError("Invalid credentials") from exc
        return str(claims["sub"]), claims.get("azp") or claims.get("client_id")


def build_authenticator(settings: ApiSettings) -> Authenticator:
    if settings.auth_mode == "static_token":
        assert settings.api_static_token is not None
        return StaticTokenAuthenticator(settings.api_static_token.get_secret_value())
    return OidcAuthenticator.from_jwks_url(
        issuer=settings.oidc_issuer or "",
        audience=settings.oidc_audience or "",
        algorithms=settings.oidc_algorithms,
        jwks_url=settings.oidc_jwks_url or "",
    )


def require_caller(request: Request) -> Caller:
    """Sync dependency: FastAPI runs it in a worker thread, so JWKS fetches don't block the loop."""
    scheme, _, token = request.headers.get("authorization", "").partition(" ")
    if scheme.lower() != "bearer" or not token:
        raise AuthError("Missing bearer token")
    subject, client_id = request.app.state.authenticator.authenticate(token.strip())
    on_behalf_of = request.headers.get("x-on-behalf-of")
    if on_behalf_of is not None and not _SAFE_USER.match(on_behalf_of):
        # Reject rather than drop: dropping would merge this user's sessions with the client's.
        raise HTTPException(status_code=400, detail="Invalid X-On-Behalf-Of header")
    caller = Caller(subject=subject, client_id=client_id, on_behalf_of=on_behalf_of)
    request.state.caller = caller
    request.app.state.rate_limiter.check(caller.subject)
    return caller
