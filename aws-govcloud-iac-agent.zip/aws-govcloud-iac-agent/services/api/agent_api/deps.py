"""Shared request dependencies and helpers for routers."""
import asyncio
from functools import partial

from fastapi import Request

from agent_core import __version__
from agent_core.factory import Agent
from agent_core.models import SolutionRecord
from agent_core.observability import current_request_id
from agent_core.orchestration import PipelineResult, Session, SessionNotFound
from agent_api.auth import Caller
from agent_api.errors import TurnTimeout
from agent_api.schemas import AgentInfo, AgentResponse, ChatMessage


def get_agent(request: Request) -> Agent:
    return request.app.state.agent


def request_id() -> str:
    return current_request_id() or ""


def agent_info(agent: Agent) -> AgentInfo:
    return AgentInfo(name=agent.content.policy.name, version=__version__,
                     content_version=agent.content.version, model_id=agent.llm.model_id)


def invoke_owner(caller: Caller) -> str:
    """Owner for single-shot invoke sessions, which cannot be continued as conversations."""
    return f"invoke:{caller.owner}"


def owned_session(agent: Agent, session_id: str, caller: Caller, *, allow_invoke: bool = False) -> Session:
    session = agent.store.get(session_id)
    owners = {caller.owner, invoke_owner(caller)} if allow_invoke else {caller.owner}
    if session is None or session.owner not in owners:
        raise SessionNotFound(session_id)  # same response whether missing or not owned
    return session


def owned_solution(agent: Agent, solution_id: str, caller: Caller) -> SolutionRecord:
    solution = agent.store.get_solution(solution_id)
    if solution is None:
        raise SessionNotFound(solution_id)
    owned_session(agent, solution.session_id, caller, allow_invoke=True)
    return solution


async def run_turn(request: Request, text: str, session_id: str | None, owner: str) -> PipelineResult:
    """Run the synchronous pipeline in a worker thread with an overall timeout.

    On timeout the worker thread still finishes and records its result in the session.
    """
    agent = get_agent(request)
    with request.app.state.session_locks.hold(session_id):
        call = partial(agent.pipeline.run, text, session_id, owner=owner)
        try:
            return await asyncio.wait_for(asyncio.to_thread(call),
                                          request.app.state.api_settings.turn_timeout_s)
        except TimeoutError as exc:
            raise TurnTimeout() from exc


def to_response(agent: Agent, result: PipelineResult, *, include_session: bool = True) -> AgentResponse:
    return AgentResponse(
        request_id=request_id(),
        session_id=result.session_id if include_session else None,
        status=result.status,
        agent=agent_info(agent),
        messages=[ChatMessage(role="assistant", content=result.message)],
        questions=result.questions,
        solution=result.solution,
        blockers=result.blockers,
    )
