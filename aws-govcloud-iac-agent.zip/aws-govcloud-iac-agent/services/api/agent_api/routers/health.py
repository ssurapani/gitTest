from fastapi import APIRouter, Request

from agent_api.errors import problem

router = APIRouter(tags=["health"])


@router.get("/healthz")
def healthz() -> dict[str, str]:
    return {"status": "ok"}


@router.get("/readyz")
def readyz(request: Request):
    agent = getattr(request.app.state, "agent", None)
    if agent is None:
        return problem(503, "Service Unavailable", "Agent not loaded")
    return {"status": "ready", "content_version": agent.content.version,
            "model_id": agent.llm.model_id}
