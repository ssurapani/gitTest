from fastapi import APIRouter, Depends

from agent_api.auth import require_caller
from agent_api.routers.v1 import agent, sessions, solutions

router = APIRouter(prefix="/v1", dependencies=[Depends(require_caller)])
router.include_router(agent.router)
router.include_router(sessions.router)
router.include_router(solutions.router)
