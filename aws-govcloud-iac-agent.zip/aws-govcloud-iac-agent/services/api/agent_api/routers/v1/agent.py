from typing import Annotated

from fastapi import APIRouter, Depends, Request

from agent_core.factory import Agent
from agent_api.auth import Caller, require_caller
from agent_api.deps import get_agent, invoke_owner, request_id, run_turn, to_response
from agent_api.schemas import AgentResponse, Capabilities, MessageRequest

router = APIRouter(prefix="/agent", tags=["agent"])


@router.get("/capabilities", response_model=Capabilities)
def capabilities(agent: Annotated[Agent, Depends(get_agent)]) -> Capabilities:
    return Capabilities(request_id=request_id(), **agent.capabilities())


@router.post("/invoke", response_model=AgentResponse)
async def invoke(
    body: MessageRequest,
    request: Request,
    caller: Annotated[Caller, Depends(require_caller)],
    agent: Annotated[Agent, Depends(get_agent)],
) -> AgentResponse:
    """Single-shot call for agent-to-agent use. No session is returned to continue; when the
    status is needs_input, call again with the full request including the answers."""
    result = await run_turn(request, body.message, None, invoke_owner(caller))
    return to_response(agent, result, include_session=False)
