from typing import Annotated

from fastapi import APIRouter, Depends

from agent_core.factory import Agent
from agent_core.models import ResponseStatus
from agent_api.auth import Caller, require_caller
from agent_api.deps import agent_info, get_agent, owned_solution, request_id
from agent_api.schemas import AgentResponse, ArtifactsResponse

router = APIRouter(prefix="/solutions", tags=["solutions"])


@router.get("/{solution_id}", response_model=AgentResponse)
def get_solution(
    solution_id: str,
    caller: Annotated[Caller, Depends(require_caller)],
    agent: Annotated[Agent, Depends(get_agent)],
) -> AgentResponse:
    solution = owned_solution(agent, solution_id, caller)
    return AgentResponse(
        request_id=request_id(),
        session_id=solution.session_id,
        status=ResponseStatus(solution.status.value),
        agent=agent_info(agent),
        solution=solution,
        blockers=solution.blockers,
    )


@router.get("/{solution_id}/artifacts", response_model=ArtifactsResponse)
def get_artifacts(
    solution_id: str,
    caller: Annotated[Caller, Depends(require_caller)],
    agent: Annotated[Agent, Depends(get_agent)],
) -> ArtifactsResponse:
    solution = owned_solution(agent, solution_id, caller)
    return ArtifactsResponse(request_id=request_id(), solution_id=solution.id,
                             status=solution.status, artifacts=solution.artifacts)
