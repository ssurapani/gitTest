from typing import Annotated

from fastapi import APIRouter, Depends, Request, status

from agent_core.factory import Agent
from agent_api.auth import Caller, require_caller
from agent_api.deps import agent_info, get_agent, owned_session, request_id, run_turn, to_response
from agent_api.schemas import AgentResponse, ChatMessage, MessageRequest, SessionView

router = APIRouter(prefix="/sessions", tags=["sessions"])


@router.post("", response_model=AgentResponse, status_code=status.HTTP_201_CREATED)
async def create_session(
    body: MessageRequest,
    request: Request,
    caller: Annotated[Caller, Depends(require_caller)],
    agent: Annotated[Agent, Depends(get_agent)],
) -> AgentResponse:
    result = await run_turn(request, body.message, None, caller.owner)
    return to_response(agent, result)


@router.post("/{session_id}/messages", response_model=AgentResponse)
async def add_message(
    session_id: str,
    body: MessageRequest,
    request: Request,
    caller: Annotated[Caller, Depends(require_caller)],
    agent: Annotated[Agent, Depends(get_agent)],
) -> AgentResponse:
    owned_session(agent, session_id, caller)
    result = await run_turn(request, body.message, session_id, caller.owner)
    return to_response(agent, result)


@router.get("/{session_id}", response_model=SessionView)
def get_session(
    session_id: str,
    caller: Annotated[Caller, Depends(require_caller)],
    agent: Annotated[Agent, Depends(get_agent)],
) -> SessionView:
    session = owned_session(agent, session_id, caller)
    return SessionView(
        request_id=request_id(),
        session_id=session.id,
        status=session.status,
        agent=agent_info(agent),
        created_at=session.created_at,
        updated_at=session.updated_at,
        turns=[ChatMessage(role=t.role, content=t.text, at=t.at) for t in session.turns],
        requirements=session.requirements,
        solution_ids=session.solution_ids,
    )
