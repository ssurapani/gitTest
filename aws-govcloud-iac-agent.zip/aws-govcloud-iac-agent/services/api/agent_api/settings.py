"""API-only settings. Agent settings (content, LLM) live in agent_core.settings."""
from typing import Literal

from pydantic import Field, SecretStr, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class ApiSettings(BaseSettings):
    model_config = SettingsConfigDict(env_file=None, extra="ignore")

    app_env: Literal["local", "dev", "test", "prod"] = "local"
    auth_mode: Literal["static_token", "oidc"] = "static_token"
    # Local development only. Never set this in a deployed environment.
    api_static_token: SecretStr | None = None
    oidc_issuer: str | None = None
    oidc_audience: str | None = None
    oidc_jwks_url: str | None = None
    oidc_algorithms: list[str] = Field(default_factory=lambda: ["RS256"])

    rate_limit_per_minute: int = Field(default=30, gt=0)
    max_body_bytes: int = Field(default=65536, gt=0)
    turn_timeout_s: float = Field(default=300, gt=0)
    enable_docs: bool | None = None  # defaults to on, except in prod

    @model_validator(mode="after")
    def _check_auth(self) -> "ApiSettings":
        if self.auth_mode == "static_token":
            if self.app_env != "local":
                raise ValueError("AUTH_MODE=static_token is only allowed when APP_ENV=local")
            token = self.api_static_token.get_secret_value() if self.api_static_token else ""
            if len(token) < 16:
                raise ValueError("API_STATIC_TOKEN must be set (at least 16 characters)")
        elif not (self.oidc_issuer and self.oidc_audience and self.oidc_jwks_url):
            raise ValueError("AUTH_MODE=oidc requires OIDC_ISSUER, OIDC_AUDIENCE, and OIDC_JWKS_URL")
        return self

    @property
    def docs_enabled(self) -> bool:
        return self.enable_docs if self.enable_docs is not None else self.app_env != "prod"
