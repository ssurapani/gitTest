"""FastAPI service exposing the agent_core pipeline through the versioned /v1 contract."""
