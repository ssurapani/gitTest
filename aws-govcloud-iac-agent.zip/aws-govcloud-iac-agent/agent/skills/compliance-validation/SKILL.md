# Skill: IaC Compliance and Quality Validation

## Invoke when
Terraform or pipeline artifacts are generated or changed.

## Validation layers
1. Requirements completeness.
2. Landing Zone architecture policy.
3. Terraform formatting and syntax validation.
4. Provider/module interface checks.
5. Naming, tagging, and coding standards.
6. Checkov and established compliance workflow.
7. Plan review where authorized and supported.
8. Pipeline integrity and approval gates.

## Reporting
For each check, report `passed`, `failed`, `not_run`, or `blocked`, with source/tool evidence and remediation.

## Guardrails
- The existing Checkov/compliance workflow is authoritative.
- Do not claim validation ran when it did not.
- Do not disable, skip, or suppress mandatory checks without authorized governance.
- Do not infer compliance solely from code review.
- Treat plan results as environment-specific and time-sensitive.
