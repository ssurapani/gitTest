# Skill: IaC Architecture Composition

## Invoke when
Multiple services or existing patterns must work together.

## Workflow
1. Convert requirements into a service/resource dependency graph.
2. Map each component to a pattern and version.
3. Identify required inputs/outputs, IAM relationships, network paths, DNS, encryption, logging, and cross-account dependencies.
4. Separate resources to create from existing foundation resources to reference.
5. Validate account boundaries and deployment order.
6. Identify missing pattern capabilities and decide whether composition is safe or a gap exists.
7. Present an architecture proposal for confirmation when material decisions remain.

## Output
Architecture diagram or text graph, pattern/resource mapping, dependencies, account/environment mapping, and open decisions.

## Guardrails
Do not assume resources or routes exist. Do not create prohibited foundations. Do not hide incompatible pattern interfaces by inventing variables or outputs.
