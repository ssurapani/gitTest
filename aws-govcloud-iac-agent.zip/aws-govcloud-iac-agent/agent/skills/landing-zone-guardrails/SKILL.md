# Skill: AWS GovCloud Landing Zone Guardrails

## Invoke when
A design uses or might create network, identity, ingress, or shared foundation resources.

## Mandatory checks
- No new VPCs in application-owned Landing Zone accounts.
- No new subnets in application-owned Landing Zone accounts.
- No new Transit Gateways in application-owned Landing Zone accounts.
- No IAM users.
- No CloudFront distributions.
- No prohibited public ingress.
- Use delivered VPCs, subnets, and Transit Gateways.
- Treat non-routable IP space and NAT access as requestable, not guaranteed.

## Workflow
1. Retrieve the current authoritative policy and relevant network architecture.
2. Map every proposed resource to its target account and ownership boundary.
3. Identify existing foundation resources that must be referenced rather than created.
4. Inspect direct and indirect resource creation where possible.
5. If a request conflicts with policy, stop that design path and explain an approved alternative.
6. If policy or resource capability is unknown, block the affected assumption and request confirmation.

## Output
A resource/account matrix with `reuse_existing`, `create_allowed_candidate`, `prohibited`, or `unknown` status.

## Important
This skill supplements deterministic policy enforcement; it does not replace it.
