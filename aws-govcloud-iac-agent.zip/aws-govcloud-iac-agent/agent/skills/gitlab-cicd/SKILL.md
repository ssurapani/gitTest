# Skill: GitLab CI/CD Pipeline Engineering

## Invoke when
A Terraform pattern/example needs an approved deployment pipeline.

## Workflow
1. Find the matching approved pattern or example pipeline template.
2. Preserve required stages, includes, variables, artifacts, dependencies, manual gates, and policy checks.
3. Use the organization's approved Terraform wrapper (for example, `tf`) where required.
4. Map each environment to a confirmed target account and approved configuration.
5. Ensure plan, validation, compliance, review, and apply gates follow the source template.
6. Check that changes do not introduce arbitrary credentials, unapproved runners, or external downloads.
7. Report which checks are configured versus actually executed.

## Guardrails
- Do not disable mandatory stages or weaken approvals.
- Do not add automatic production deployment unless the approved template and authorization explicitly allow it.
- Do not invent CI/CD variables or undocumented internal endpoints.
- Treat pipeline changes as security-sensitive.
