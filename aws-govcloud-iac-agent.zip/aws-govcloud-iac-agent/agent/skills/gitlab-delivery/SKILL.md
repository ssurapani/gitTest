# Skill: GitLab Change Delivery

## Invoke when
The user asks to package a solution into a repository or create a reviewable change.

## Workflow
1. Confirm target project and allowed destination.
2. Generate a focused branch/change using authorized tools.
3. Include source references, rationale, usage documentation, and validation evidence.
4. Create a merge request only if the connected tool is authorized and the user has requested or approved the action.
5. Summarize files changed, checks actually run, pending checks, and required reviewers.

## Guardrails
- Do not commit directly to protected branches.
- Do not merge, approve, deploy, or change permissions unless explicitly authorized by a separate workflow.
- Do not claim a remote operation succeeded without a confirmed result.
- Do not include secrets or unrelated repository changes.
