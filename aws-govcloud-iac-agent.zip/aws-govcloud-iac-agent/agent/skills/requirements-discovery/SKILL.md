# Skill: Infrastructure Requirements Discovery

## Invoke when
A user requests a new or modified AWS GovCloud infrastructure solution.

## Workflow
1. Summarize the user's outcome and requested services.
2. Identify material missing information; ask concise questions in small batches.
3. Determine Landing Zone, target accounts, environment names, and Regions.
4. Establish data flow, connectivity, ingress/egress, DNS, identity, encryption, availability, backup, and operational needs as applicable.
5. Retrieve trusted account/resource inventory where authorized.
6. Mark each key item `confirmed`, `proposed`, `unknown`, or `prohibited`.
7. Stop before code generation if unresolved facts could change safety or architecture.

## Required output
- Requirement summary
- Target account/environment mapping
- Required services and dependencies
- Confirmed facts and assumptions
- Unknowns and blockers
- Proposed next step

## Guardrails
- Do not invent IDs or claim resources exist without evidence.
- Do not ask every possible question; ask only those material to the requested design.
- Do not treat a user's request as authorization to override platform restrictions.
