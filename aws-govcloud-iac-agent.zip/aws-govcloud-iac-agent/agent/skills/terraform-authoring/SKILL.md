# Skill: Terraform Pattern and Example Authoring

## Invoke when
Approved patterns need configuration, composition, or a new candidate pattern.

## Workflow
1. Inspect the approved repository layout, provider constraints, module interfaces, and standards.
2. Generate the smallest coherent change that satisfies confirmed requirements.
3. Include variables, outputs, descriptions, types, validation rules, and safe defaults as appropriate.
4. Keep environment-specific configuration separated and free of secrets.
5. Add README usage instructions, dependencies, examples, and tests where the repository expects them.
6. Run only authorized local/static checks and report actual results.
7. Review direct and transitive resource creation against guardrails.

## Guardrails
- Never invent provider arguments or module interfaces.
- Avoid unapproved providers, `local-exec`, `null_resource`, external downloads, and arbitrary scripts unless explicitly approved by standards.
- Do not hardcode secrets.
- Do not suppress security findings to force success.
- New patterns are candidates pending review and approval.
