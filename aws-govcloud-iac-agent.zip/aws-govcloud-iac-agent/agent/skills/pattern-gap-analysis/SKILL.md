# Skill: Codebank Pattern Gap Analysis

## Invoke when
An enabled service has no suitable approved pattern, or existing patterns cannot satisfy a confirmed requirement.

## Workflow
1. Verify service enablement and target scope.
2. Search patterns, examples, modules, documentation, and templates adequately.
3. Explain why existing artifacts do not fit.
4. Identify minimum reusable pattern scope, interfaces, dependencies, tests, and documentation.
5. Check relevant provider/resource support and organizational standards.
6. Prepare a candidate pattern or backlog issue.
7. Identify owners and approval steps.

## Output
Gap summary, search evidence, proposed pattern scope, dependencies, acceptance criteria, and review requirements.

## Guardrails
- Do not equate a failed search with definitive absence.
- Do not label a generated pattern approved.
- Do not introduce a service whose enablement is unknown.
- Do not bypass the Codebank contribution workflow.
