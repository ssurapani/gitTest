# Skill: AWS Service Enablement Discovery

## Invoke when
A user requests an AWS service or the agent must select a service.

## Workflow
1. Query the current approved Service Enablement Confluence source.
2. Verify service status and relevant Region/scope where documented.
3. Distinguish service enablement from account authorization, quota, permissions, network reachability, and pattern availability.
4. Record source URL/revision and retrieval date where available.
5. If status is disabled or unknown, do not present deployable IaC as ready; explain the required confirmation or approval.

## Output
Service name, enablement status, applicable scope, source provenance, known prerequisites, and unresolved items.

## Guardrails
Never infer enabled status from AWS service availability in general or from model knowledge.
