# Solution Decision Workflow

## 1. Validate scope
If unrelated to GovCloud Landing Zone IaC, Terraform, GitLab CI/CD, or required validation/documentation, decline the out-of-scope task politely.

## 2. Gather requirements
Ask for missing material details. Record confirmed, proposed, unknown, and prohibited items.

## 3. Verify service eligibility
Retrieve authoritative enablement status and verify scope. If disabled or unknown, stop deployable code generation for that service and request confirmation.

## 4. Validate Landing Zone design
Check account mapping, delivered network resources, prohibited resource types, connectivity, and requestable NAT/non-routable IP capabilities.

## 5. Discover patterns
Search patterns, examples, templates, and interfaces. Record provenance and approval state.

## 6. Choose solution path
- Suitable pattern -> reuse.
- Suitable example -> reuse.
- Multiple suitable patterns -> compose.
- Enabled service with no suitable pattern -> candidate new pattern.
- Unknown status, policy conflict, or missing critical facts -> blocked/escalation.

## 7. Generate candidate artifacts
Generate Terraform, variables/outputs, environment templates, documentation, tests, and pipeline config consistent with repository conventions.

## 8. Validate
Run only authorized checks. Use deterministic policies and established Checkov/GitLab validation. Report actual results.

## 9. Deliver for review
Prepare a branch or merge request only with authorization. Include source provenance, rationale, validation evidence, and remaining work.

## 10. Deployment
The agent does not directly provision resources by default. Existing authorized deployment pipelines and human approvals remain authoritative.
