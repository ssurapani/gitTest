# Codebank Pattern Gap Proposal

## Summary
<!-- AWS service and required outcome -->

## Service enablement evidence
- Status:
- Scope/Region:
- Source URL/revision:

## Search performed
- Patterns searched:
- Examples searched:
- Pipeline templates searched:
- Relevant source paths/revisions:

## Why existing artifacts are insufficient
<!-- Concrete capability gap; do not rely only on a failed search -->

## Proposed pattern scope
- Resources:
- Inputs/outputs:
- Dependencies:
- Account/network assumptions:
- Security requirements:

## Validation and tests
- [ ] Terraform validation
- [ ] Naming/tagging/coding standards
- [ ] Checkov and required compliance workflow
- [ ] Prohibited resource review
- [ ] Documentation and example usage
- [ ] Pipeline integration

## Ownership and approval
- Pattern owner:
- Required reviewers:
- Acceptance criteria:
