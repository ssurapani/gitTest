# Composition of Codebank IaC patterns for the agent application hosting stack.
#
# STATUS: candidate. No Codebank pattern below has been located or verified. Each module block
# stays commented out until pattern-references.yaml records, for that component:
#   - confirmed service enablement for the target account and Region,
#   - the Codebank project, path, and pinned approved revision (tag or commit),
#   - the pattern's documented inputs and outputs at that revision.
# Map inputs only from the pattern's documented interface; do not invent arguments.
#
# Source format depends on how Codebank publishes patterns (confirm which applies):
#   git:      "git::https://<gitlab-host>/<group>/<project>.git//<path>?ref=<approved-tag>"
#   registry: "<gitlab-host>/<namespace>/<module>/aws" with `version = "<approved-version>"`

# -----------------------------------------------------------------------------------------
# Component: ecr_repository: image repositories for the api and ui containers
# Open: whether repositories live in this account or a shared tooling account.
# -----------------------------------------------------------------------------------------
# module "ecr_repository" {
#   for_each = local.services
#   source   = "git::https://REPLACE_WITH_GITLAB_HOST/REPLACE_WITH_CODEBANK_PATTERN_PROJECT.git//REPLACE_WITH_PATTERN_PATH?ref=REPLACE_WITH_APPROVED_TAG"
#
#   # Inputs: from the pattern README at the pinned revision.
# }

# -----------------------------------------------------------------------------------------
# Component: ecs_cluster: ECS cluster (Fargate preferred) for both services
# -----------------------------------------------------------------------------------------
# module "ecs_cluster" {
#   source = "git::https://REPLACE_WITH_GITLAB_HOST/REPLACE_WITH_CODEBANK_PATTERN_PROJECT.git//REPLACE_WITH_PATTERN_PATH?ref=REPLACE_WITH_APPROVED_TAG"
#
#   # Inputs: from the pattern README at the pinned revision.
# }

# -----------------------------------------------------------------------------------------
# Component: internal_load_balancer: internal-only ALB in delivered private subnets
# Must not be internet-facing. Ingress limited to var.allowed_ingress_cidrs over HTTPS
# using var.certificate_arn.
# -----------------------------------------------------------------------------------------
# module "internal_load_balancer" {
#   source = "git::https://REPLACE_WITH_GITLAB_HOST/REPLACE_WITH_CODEBANK_PATTERN_PROJECT.git//REPLACE_WITH_PATTERN_PATH?ref=REPLACE_WITH_APPROVED_TAG"
#
#   # Expected to reference: data.aws_vpc.delivered.id, local.private_subnet_ids,
#   # var.allowed_ingress_cidrs, var.certificate_arn (via the pattern's documented inputs).
# }

# -----------------------------------------------------------------------------------------
# Component: ecs_service: one service per workload in local.services (api, ui)
# The api task role receives data.aws_iam_policy_document.api_bedrock_invoke.json.
# The ui task role receives no AWS data permissions.
# -----------------------------------------------------------------------------------------
# module "ecs_service" {
#   for_each = local.services
#   source   = "git::https://REPLACE_WITH_GITLAB_HOST/REPLACE_WITH_CODEBANK_PATTERN_PROJECT.git//REPLACE_WITH_PATTERN_PATH?ref=REPLACE_WITH_APPROVED_TAG"
#
#   # Expected to reference: module.ecs_cluster, module.internal_load_balancer,
#   # local.private_subnet_ids, each.value.image, each.value.container_port,
#   # each.value.health_path, var.log_retention_days (via the pattern's documented inputs).
# }

# -----------------------------------------------------------------------------------------
# Component: application_secrets: runtime secrets (GitLab read token, OIDC client secret)
# Values are never set in Terraform or tfvars; only the secret containers are managed here.
# -----------------------------------------------------------------------------------------
# module "application_secrets" {
#   source = "git::https://REPLACE_WITH_GITLAB_HOST/REPLACE_WITH_CODEBANK_PATTERN_PROJECT.git//REPLACE_WITH_PATTERN_PATH?ref=REPLACE_WITH_APPROVED_TAG"
#
#   # Inputs: from the pattern README at the pinned revision.
# }

# Not managed here: Bedrock Runtime VPC interface endpoint. Whether it exists, is centrally
# provided, or must be requested from the platform team is unknown (see pattern-references.yaml).
