# Least-privilege permissions for the API task role. The role itself is expected to come from
# the Codebank ECS pattern; this document is passed to it once that pattern's input is confirmed.
# The UI task needs no AWS data permissions.

data "aws_iam_policy_document" "api_bedrock_invoke" {
  statement {
    sid    = "InvokeApprovedBedrockModels"
    effect = "Allow"
    actions = [
      "bedrock:InvokeModel",
      "bedrock:InvokeModelWithResponseStream",
    ]
    resources = var.bedrock_model_arns
  }
}
