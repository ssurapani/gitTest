terraform {
  # Minimums reflect language features used in this stack (check blocks, postconditions).
  # CANDIDATE: align with the organization's approved Terraform and provider constraints.
  required_version = ">= 1.5.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 5.0"
    }
  }

  # Partial configuration; values come from environments/<env>/backend.hcl.
  # CANDIDATE: confirm the state backend convention used by the approved `tf` wrapper.
  backend "s3" {}
}
