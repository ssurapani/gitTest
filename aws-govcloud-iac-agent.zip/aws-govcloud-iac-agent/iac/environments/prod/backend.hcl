# prod state backend. CANDIDATE: confirm against the approved `tf` wrapper convention.
bucket  = "REPLACE_WITH_STATE_BUCKET"
key     = "REPLACE_WITH_STATE_KEY"
region  = "REPLACE_WITH_APPROVED_GOVCLOUD_REGION"
encrypt = true
