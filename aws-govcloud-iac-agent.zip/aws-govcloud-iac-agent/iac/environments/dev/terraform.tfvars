# dev environment: every value must be confirmed from authoritative sources.
# Do not put secrets in this file.

environment = "dev"
region      = "REPLACE_WITH_APPROVED_GOVCLOUD_REGION"
account_id  = "REPLACE_WITH_CONFIRMED_ACCOUNT_ID"
app_name    = "REPLACE_WITH_APPROVED_APP_NAME"

tags = {
  REPLACE_WITH_REQUIRED_TAG_KEY = "REPLACE_WITH_VALUE"
}

# Delivered Landing Zone network (from the trusted account/resource inventory).
vpc_id             = "REPLACE_WITH_DELIVERED_VPC_ID"
private_subnet_ids = ["REPLACE_WITH_DELIVERED_PRIVATE_SUBNET_ID_A", "REPLACE_WITH_DELIVERED_PRIVATE_SUBNET_ID_B"]

allowed_ingress_cidrs = ["REPLACE_WITH_INTERNAL_CIDR"]
certificate_arn       = "REPLACE_WITH_CERTIFICATE_ARN"

# Immutable image references produced by the application pipeline.
api_image = "REPLACE_WITH_API_IMAGE_URI_AND_TAG"
ui_image  = "REPLACE_WITH_UI_IMAGE_URI_AND_TAG"

bedrock_model_arns = ["REPLACE_WITH_APPROVED_BEDROCK_MODEL_ARN"]

log_retention_days = 0 # REPLACE_WITH_STANDARD_RETENTION_DAYS
