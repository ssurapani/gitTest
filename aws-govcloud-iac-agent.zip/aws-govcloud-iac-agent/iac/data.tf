# Lookups of existing Landing Zone resources. This stack references delivered networking
# and must never create VPCs, subnets, or Transit Gateways.

data "aws_partition" "current" {
  lifecycle {
    postcondition {
      condition     = self.partition == "aws-us-gov"
      error_message = "This stack must run in the AWS GovCloud partition (aws-us-gov)."
    }
  }
}

data "aws_vpc" "delivered" {
  id = var.vpc_id
}

data "aws_subnet" "private" {
  for_each = toset(var.private_subnet_ids)
  id       = each.value

  lifecycle {
    postcondition {
      condition     = self.vpc_id == var.vpc_id
      error_message = "Subnet ${each.value} is not in the delivered VPC ${var.vpc_id}."
    }

    postcondition {
      condition     = !self.map_public_ip_on_launch
      error_message = "Subnet ${each.value} assigns public IPs; use a delivered private subnet."
    }
  }
}
