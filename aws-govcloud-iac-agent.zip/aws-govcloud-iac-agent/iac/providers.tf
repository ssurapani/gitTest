provider "aws" {
  region = var.region

  # Refuse to run against any account other than the confirmed target for this environment.
  allowed_account_ids = [var.account_id]

  default_tags {
    tags = var.tags
  }
}
