# Root-module interface for the agent application hosting stack.
# These variables are this stack's own inputs. They are mapped onto Codebank pattern inputs
# in main.tf only after each pattern's documented interface is confirmed.

variable "environment" {
  description = "Deployment environment name."
  type        = string

  validation {
    condition     = contains(["dev", "test", "prod"], var.environment)
    error_message = "environment must be one of: dev, test, prod."
  }
}

variable "region" {
  description = "Approved AWS GovCloud Region for this environment."
  type        = string

  validation {
    condition     = startswith(var.region, "us-gov-")
    error_message = "region must be an AWS GovCloud Region (us-gov-*)."
  }
}

variable "account_id" {
  description = "Confirmed application-owned Landing Zone account ID for this environment."
  type        = string

  validation {
    condition     = can(regex("^[0-9]{12}$", var.account_id))
    error_message = "account_id must be a 12-digit AWS account ID."
  }
}

variable "app_name" {
  description = "Application name used to build resource names. Must follow the naming standard."
  type        = string
}

variable "tags" {
  description = "Required tags from the organization's tagging standard, applied to all resources."
  type        = map(string)

  validation {
    condition     = length(var.tags) > 0
    error_message = "tags must include the required organizational tags."
  }
}

# --- Delivered Landing Zone network (referenced, never created) ---------------------------

variable "vpc_id" {
  description = "ID of the VPC delivered by the Landing Zone for this account."
  type        = string
}

variable "private_subnet_ids" {
  description = "IDs of delivered private subnets for the load balancer and ECS tasks."
  type        = list(string)

  validation {
    condition     = length(var.private_subnet_ids) >= 2
    error_message = "Provide at least two delivered private subnets in different Availability Zones."
  }
}

variable "allowed_ingress_cidrs" {
  description = "Internal CIDR ranges allowed to reach the internal load balancer."
  type        = list(string)

  validation {
    condition     = alltrue([for c in var.allowed_ingress_cidrs : can(cidrhost(c, 0))])
    error_message = "allowed_ingress_cidrs must contain valid CIDR blocks."
  }

  validation {
    condition     = !anytrue([for c in var.allowed_ingress_cidrs : contains(["0.0.0.0/0", "::/0"], c)])
    error_message = "Public ingress is prohibited in application-owned Landing Zone accounts."
  }
}

variable "certificate_arn" {
  description = "ARN of the certificate for the internal HTTPS listener, issued through the approved process."
  type        = string
}

# --- Application workloads --------------------------------------------------------------

variable "api_image" {
  description = "Container image URI for the FastAPI backend (immutable tag or digest)."
  type        = string

  validation {
    condition     = !endswith(var.api_image, ":latest")
    error_message = "api_image must use an immutable tag or digest, not :latest."
  }
}

variable "ui_image" {
  description = "Container image URI for the Streamlit frontend (immutable tag or digest)."
  type        = string

  validation {
    condition     = !endswith(var.ui_image, ":latest")
    error_message = "ui_image must use an immutable tag or digest, not :latest."
  }
}

variable "api_container_port" {
  description = "Port the FastAPI container listens on."
  type        = number
  default     = 8000
}

variable "ui_container_port" {
  description = "Port the Streamlit container listens on."
  type        = number
  default     = 8501
}

variable "bedrock_model_arns" {
  description = "ARNs of the Bedrock models or inference profiles the API may invoke, as confirmed by Service Enablement."
  type        = list(string)

  validation {
    condition     = alltrue([for a in var.bedrock_model_arns : startswith(a, "arn:aws-us-gov:bedrock:")])
    error_message = "bedrock_model_arns must be GovCloud Bedrock ARNs (arn:aws-us-gov:bedrock:...)."
  }
}

variable "log_retention_days" {
  description = "CloudWatch Logs retention, per the organization's logging standard."
  type        = number
}
