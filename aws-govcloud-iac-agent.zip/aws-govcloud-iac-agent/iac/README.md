# Agent Application Hosting IaC

Status: **candidate**. Nothing in this folder is approved, validated against an account, or deployed.

This Terraform root module hosts the agent application (Streamlit UI and FastAPI API on ECS) by composing approved **Codebank IaC patterns**. It does not define resources directly where a Codebank pattern exists. It references the delivered Landing Zone network and never creates VPCs, subnets, Transit Gateways, IAM users, CloudFront distributions, or public ingress.

## Layout

```text
iac/
├── versions.tf                # Terraform/provider constraints, partial S3 backend
├── providers.tf               # AWS provider pinned to the confirmed account; default tags
├── variables.tf               # this stack's interface, with guardrail validations
├── data.tf                    # lookups of delivered VPC/subnets, GovCloud partition check
├── iam.tf                     # least-privilege Bedrock policy for the API task role
├── locals.tf                  # naming and the api/ui workload map
├── main.tf                    # Codebank pattern module calls (templates until resolved)
├── outputs.tf
├── pattern-references.yaml    # component -> Codebank project/path/revision, decisions
└── environments/
    ├── dev/  { terraform.tfvars, backend.hcl }
    ├── test/ { terraform.tfvars, backend.hcl }
    └── prod/ { terraform.tfvars, backend.hcl }
```

One root module serves every environment. Environments differ only through `environments/<env>/`. Confirm this layout against the approved Codebank example repository structure; if that structure differs, the approved one takes precedence.

## Enabling a Codebank pattern

For each component in `pattern-references.yaml`:

1. Confirm service enablement for the target account and Region (Service Enablement Confluence).
2. Locate the pattern in Codebank and record its project, path, and an approved tag or commit.
3. Read the pattern's documented inputs and outputs at that revision.
4. Uncomment the matching module block in `main.tf`, set `source` to the pinned revision, and map inputs from this stack's variables and locals. Only use inputs the pattern documents.
5. Set `decision` in `pattern-references.yaml` and record why reuse or composition fits. If no pattern fits, follow `agent/skills/pattern-gap-analysis/SKILL.md` instead of writing raw resources here.

## Guardrails built into this stack

| Guardrail | Where |
|---|---|
| Runs only in the GovCloud partition | `data.tf` postcondition |
| Runs only against the confirmed account | `providers.tf` `allowed_account_ids` |
| Subnets belong to the delivered VPC and do not assign public IPs | `data.tf` postconditions |
| No `0.0.0.0/0` or `::/0` ingress | `variables.tf` validation |
| No `:latest` image tags | `variables.tf` validation |
| Bedrock access limited to listed GovCloud model ARNs | `iam.tf`, `variables.tf` |
| No prohibited resource types declared in this folder | `scripts/validate_repository.py` |

These checks add to Checkov, plan-level policy checks, and pipeline gates; they don't replace them. The repository scan only inspects this folder's `.tf` files. It does not inspect resources created inside Codebank modules. That requires plan-level checks.

## Running

Use the organization's approved `tf` wrapper and the approved GitLab deployment template for `init`, `plan`, and `apply`. This README doesn't document their commands because they haven't been confirmed. The agent never runs `apply` or `destroy`.

Local static checks (no backend, no AWS credentials):

```text
terraform -chdir=iac fmt -check -recursive
terraform -chdir=iac init -backend=false
terraform -chdir=iac validate
```

## Open items

See `open_questions` in `pattern-references.yaml` and §11 of `../design.md`. In particular, every value in `environments/*/terraform.tfvars` is a placeholder until confirmed from the trusted account/resource inventory.
