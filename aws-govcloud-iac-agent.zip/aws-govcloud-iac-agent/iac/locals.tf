locals {
  # CANDIDATE: replace with the organization's naming standard once confirmed.
  name_prefix = "${var.app_name}-${var.environment}"

  # Workloads hosted by this stack; intended for for_each over Codebank pattern modules.
  services = {
    api = {
      image          = var.api_image
      container_port = var.api_container_port
      health_path    = "/healthz"
    }
    ui = {
      image          = var.ui_image
      container_port = var.ui_container_port
      health_path    = "/_stcore/health"
    }
  }

  private_subnet_ids = [for s in data.aws_subnet.private : s.id]
}
