output "name_prefix" {
  description = "Resource name prefix for this environment."
  value       = local.name_prefix
}

output "vpc_id" {
  description = "Delivered VPC referenced by this stack."
  value       = data.aws_vpc.delivered.id
}

output "private_subnet_ids" {
  description = "Delivered private subnets, verified to belong to the delivered VPC."
  value       = local.private_subnet_ids
}

output "api_bedrock_policy_json" {
  description = "Least-privilege Bedrock invoke policy for the API task role."
  value       = data.aws_iam_policy_document.api_bedrock_invoke.json
}
