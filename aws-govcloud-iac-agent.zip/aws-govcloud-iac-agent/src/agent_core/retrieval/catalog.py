"""Reader for the service/pattern catalog (agent/knowledge/catalog-schema.yaml).

The catalog is a synchronized copy of authoritative sources. An entry only counts as verified
when it records a real source URL and a verification date. *.example.yaml files are ignored.
"""
import logging
from collections.abc import Iterable
from datetime import UTC, date, datetime
from pathlib import Path

import yaml
from pydantic import BaseModel, ConfigDict, Field, ValidationError

from agent_core.content.loader import PLACEHOLDER, ContentError
from agent_core.models.evidence import Evidence
from agent_core.models.status import EnablementStatus

log = logging.getLogger(__name__)


class CatalogPattern(BaseModel):
    model_config = ConfigDict(extra="ignore")

    project: str
    path: str
    revision: str | None = None
    status: str = "unknown"
    owner: str | None = None


class Enablement(BaseModel):
    model_config = ConfigDict(extra="ignore")

    status: EnablementStatus = EnablementStatus.UNKNOWN
    scope: str | None = None
    source_url: str | None = None
    source_revision: str | None = None
    verified_at: date | None = None


class CatalogEntry(BaseModel):
    model_config = ConfigDict(extra="ignore")

    id: str
    name: str
    enablement: Enablement = Field(default_factory=Enablement)
    patterns: list[CatalogPattern] = Field(default_factory=list)
    restrictions: list[str] = Field(default_factory=list)
    regions: list[str] = Field(default_factory=list)
    owner: str | None = None
    reviewed_at: date | None = None

    def verified_enablement(self) -> EnablementStatus:
        url = self.enablement.source_url or ""
        if not url or PLACEHOLDER in url or self.enablement.verified_at is None:
            return EnablementStatus.UNKNOWN
        return self.enablement.status

    def approved_patterns(self) -> list[CatalogPattern]:
        return [
            p
            for p in self.patterns
            if p.status == "approved" and p.revision and PLACEHOLDER not in p.project + p.path
        ]


def _normalize(name: str) -> str:
    name = name.strip().lower()
    for prefix in ("amazon ", "aws "):
        if name.startswith(prefix):
            name = name[len(prefix) :]
    return name.replace("-", " ")


class ServiceCatalog:
    def __init__(self, entries: list[tuple[CatalogEntry, Path]]):
        self._entries = entries

    @classmethod
    def load(cls, paths: Iterable[Path]) -> "ServiceCatalog":
        entries: list[tuple[CatalogEntry, Path]] = []
        for root in paths:
            files = sorted(root.glob("*.yaml")) if root.is_dir() else [root]
            for path in files:
                if path.name.endswith(".example.yaml"):
                    log.info("Skipping example catalog file %s", path.name)
                    continue
                if not path.is_file():
                    raise ContentError(f"Catalog path not found: {path}")
                data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
                if "services" not in data:
                    continue  # e.g. catalog-schema.yaml
                try:
                    entries += [(CatalogEntry.model_validate(s), path) for s in data["services"]]
                except ValidationError as exc:
                    raise ContentError(f"Invalid catalog entry in {path.name}: {exc}") from exc
        return cls(entries)

    def __len__(self) -> int:
        return len(self._entries)

    def find(self, service: str) -> tuple[CatalogEntry | None, Path | None]:
        wanted = _normalize(service)
        for entry, path in self._entries:
            if wanted in (_normalize(entry.id), _normalize(entry.name)):
                return entry, path
        return None, None

    @staticmethod
    def evidence(entry: CatalogEntry, path: Path) -> Evidence:
        return Evidence(
            source="catalog",
            location=entry.enablement.source_url or path.name,
            revision=entry.enablement.source_revision,
            retrieved_at=datetime.now(UTC),
            authority="synchronized_copy",
            note=f"{entry.name}: {entry.verified_enablement()} (catalog file {path.name})",
        )
