from enum import StrEnum
from typing import Protocol

from pydantic import BaseModel, Field

from agent_core.models.evidence import Evidence


class LookupStatus(StrEnum):
    OK = "ok"
    NOT_FOUND = "not_found"  # the search ran and returned nothing; not proof of absence
    NOT_CONFIGURED = "not_configured"


class LookupResult(BaseModel):
    status: LookupStatus
    evidence: list[Evidence] = Field(default_factory=list)
    detail: str = ""


class Source(Protocol):
    name: str

    def lookup(self, query: str) -> LookupResult: ...
