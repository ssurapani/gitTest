"""Remote authoritative sources (Confluence, GitLab). Read-only connectors arrive in phase 3.

Until then every remote lookup reports not_configured, so the pipeline records the affected
facts as unknown instead of guessing.
"""
from agent_core.content.loader import SourceConfig
from agent_core.retrieval.base import LookupResult, LookupStatus

REMOTE_SOURCES = ("service_enablement", "codebank_patterns", "codebank_examples", "pipeline_templates")


class UnavailableSource:
    def __init__(self, name: str, reason: str):
        self.name = name
        self.reason = reason

    def lookup(self, query: str) -> LookupResult:
        return LookupResult(status=LookupStatus.NOT_CONFIGURED, detail=f"{self.name}: {self.reason}")


def build_remote_sources(config: SourceConfig) -> dict[str, UnavailableSource]:
    sources = {}
    for name in REMOTE_SOURCES:
        entry = config.sources.get(name)
        if entry is None:
            reason = "not defined in source-of-truth.yaml"
        elif entry.is_placeholder():
            reason = "placeholder configuration in agent/config/source-of-truth.yaml"
        else:
            reason = "connector not implemented yet (phase 3)"
        sources[name] = UnavailableSource(name, reason)
    return sources
