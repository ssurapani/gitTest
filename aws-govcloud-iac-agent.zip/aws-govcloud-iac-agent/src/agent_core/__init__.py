"""Reusable core for the AWS GovCloud IaC agent (no web framework dependencies)."""
from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("aws-govcloud-iac-agent")
except PackageNotFoundError:  # running from a source checkout without installation
    __version__ = "0.0.0+local"

__all__ = ["__version__"]
