"""Requirements model; mirrors agent/templates/requirements-record.yaml."""
from typing import Literal

from pydantic import BaseModel, Field


class Question(BaseModel):
    id: str
    text: str
    field: str | None = None


class AccountMapping(BaseModel):
    environment: str
    account_id: str | None = None
    # Only a trusted inventory can confirm an account; the pipeline resets this to unknown.
    verification_status: Literal["confirmed", "unknown"] = "unknown"


class DecisionLog(BaseModel):
    confirmed_facts: list[str] = Field(default_factory=list)
    proposed_decisions: list[str] = Field(default_factory=list)
    assumptions: list[str] = Field(default_factory=list)
    unknowns: list[str] = Field(default_factory=list)
    prohibited_requirements: list[str] = Field(default_factory=list)


class RequirementsRecord(BaseModel):
    summary: str = ""
    workload_purpose: str = ""
    services: list[str] = Field(default_factory=list)
    accounts: list[AccountMapping] = Field(default_factory=list)
    regions: list[str] = Field(default_factory=list)
    network: list[str] = Field(default_factory=list)
    security: list[str] = Field(default_factory=list)
    operations: list[str] = Field(default_factory=list)
    decision_log: DecisionLog = Field(default_factory=DecisionLog)
