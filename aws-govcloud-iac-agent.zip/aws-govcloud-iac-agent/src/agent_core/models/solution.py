"""Solution model; mirrors agent/templates/solution-record.yaml."""
from pathlib import PurePosixPath
from typing import Literal

from pydantic import BaseModel, Field, field_validator

from agent_core.models.evidence import Evidence
from agent_core.models.request import RequirementsRecord
from agent_core.models.status import CheckStatus, PathDecision, SolutionStatus


class PatternRef(BaseModel):
    service: str
    project: str
    path: str
    revision: str | None = None
    approval_status: str = "unknown"
    rationale: str = ""


class Artifact(BaseModel):
    path: str
    content: str

    @field_validator("path")
    @classmethod
    def _relative_path(cls, value: str) -> str:
        normalized = PurePosixPath(value.replace("\\", "/"))
        if not value or normalized.is_absolute() or ".." in normalized.parts or ":" in value:
            raise ValueError("artifact path must be a relative path inside the solution")
        return str(normalized)


class Finding(BaseModel):
    check: str
    code: str
    severity: Literal["error", "warning"]
    path: str
    line: int | None = None
    detail: str


class ValidationResults(BaseModel):
    requirements: CheckStatus = CheckStatus.NOT_RUN
    architecture_policy: CheckStatus = CheckStatus.NOT_RUN
    terraform_validate: CheckStatus = CheckStatus.NOT_RUN
    naming_tagging: CheckStatus = CheckStatus.NOT_RUN
    checkov: CheckStatus = CheckStatus.NOT_RUN
    pipeline_integrity: CheckStatus = CheckStatus.NOT_RUN
    findings: list[Finding] = Field(default_factory=list)
    evidence: list[str] = Field(default_factory=list)


class Blocker(BaseModel):
    code: str
    detail: str
    remediation: str | None = None


class SolutionRecord(BaseModel):
    id: str
    session_id: str
    status: SolutionStatus
    content_version: str
    model_id: str
    requirements: RequirementsRecord | None = None
    decision: PathDecision | None = None
    architecture_summary: str = ""
    service_enablement_evidence: list[Evidence] = Field(default_factory=list)
    selected_patterns: list[PatternRef] = Field(default_factory=list)
    artifacts: list[Artifact] = Field(default_factory=list)
    validation: ValidationResults = Field(default_factory=ValidationResults)
    approvals_required: list[str] = Field(default_factory=list)
    blockers: list[Blocker] = Field(default_factory=list)
    next_steps: list[str] = Field(default_factory=list)
