from datetime import datetime

from pydantic import BaseModel


class Evidence(BaseModel):
    """Provenance for a fact used in a solution."""

    source: str  # catalog | confluence | gitlab
    location: str
    revision: str | None = None
    retrieved_at: datetime
    authority: str  # authoritative | synchronized_copy | unverified
    note: str | None = None
