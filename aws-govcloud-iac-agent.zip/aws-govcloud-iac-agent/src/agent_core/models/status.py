"""Status vocabularies. SolutionStatus must match agent/config/agent.yaml output_status_values."""
from enum import StrEnum


class SolutionStatus(StrEnum):
    PROPOSED = "proposed"
    VALIDATION_PENDING = "validation_pending"
    VALIDATED = "validated"
    APPROVAL_PENDING = "approval_pending"
    APPROVED = "approved"
    DEPLOYED = "deployed"
    BLOCKED = "blocked"


class ResponseStatus(StrEnum):
    """Statuses this agent can return. It never returns validated, approved, or deployed."""

    NEEDS_INPUT = "needs_input"
    PROPOSED = "proposed"
    VALIDATION_PENDING = "validation_pending"
    BLOCKED = "blocked"
    OUT_OF_SCOPE = "out_of_scope"


class CheckStatus(StrEnum):
    PASSED = "passed"
    FAILED = "failed"
    NOT_RUN = "not_run"
    BLOCKED = "blocked"


class EnablementStatus(StrEnum):
    ENABLED = "enabled"
    DISABLED = "disabled"
    CONDITIONAL = "conditional"
    UNKNOWN = "unknown"


class PathDecision(StrEnum):
    REUSE = "reuse"
    REUSE_EXAMPLE = "reuse_example"
    COMPOSE = "compose"
    CANDIDATE_NEW = "candidate_new"
    BLOCKED = "blocked"
