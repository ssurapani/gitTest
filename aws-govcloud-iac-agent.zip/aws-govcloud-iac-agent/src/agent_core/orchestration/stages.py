"""Pipeline stages implementing agent/workflows/solution-decision-workflow.md.

Model calls happen only in the requirements and generate stages. Every gate (scope, service
eligibility, Landing Zone policy, pattern decision, validation) is deterministic.
"""
import json
import logging
from dataclasses import dataclass, field

from pydantic import BaseModel, Field, ValidationError

from agent_core.content.loader import AgentContent
from agent_core.content.registry import SkillRegistry
from agent_core.guardrails import detect_prohibited_intents, redact, scan_artifacts
from agent_core.llm.base import LLMClient, LLMError, Message
from agent_core.models.evidence import Evidence
from agent_core.models.request import Question, RequirementsRecord
from agent_core.models.solution import Artifact, Blocker, PatternRef, ValidationResults
from agent_core.models.status import CheckStatus, EnablementStatus, PathDecision, ResponseStatus
from agent_core.orchestration import prompts
from agent_core.orchestration.session import Session
from agent_core.retrieval.base import LookupStatus, Source
from agent_core.retrieval.catalog import CatalogEntry, ServiceCatalog

log = logging.getLogger(__name__)


class StageError(RuntimeError):
    def __init__(self, code: str, detail: str):
        super().__init__(detail)
        self.code = code


@dataclass
class StageContext:
    session: Session
    content: AgentContent
    skills: SkillRegistry
    llm: LLMClient
    catalog: ServiceCatalog
    remote: dict[str, Source]
    max_tokens: int
    temperature: float | None
    requirements: RequirementsRecord | None = None
    questions: list[Question] = field(default_factory=list)
    entries: dict[str, CatalogEntry] = field(default_factory=dict)
    enablement_evidence: list[Evidence] = field(default_factory=list)
    patterns: list[PatternRef] = field(default_factory=list)
    unmatched_services: list[str] = field(default_factory=list)
    decision: PathDecision | None = None
    architecture_summary: str = ""
    artifacts: list[Artifact] = field(default_factory=list)
    validation: ValidationResults = field(default_factory=ValidationResults)
    approvals: list[str] = field(default_factory=list)
    blockers: list[Blocker] = field(default_factory=list)
    next_steps: list[str] = field(default_factory=list)

    @property
    def latest_user_text(self) -> str:
        return next(t.text for t in reversed(self.session.turns) if t.role == "user")


@dataclass(frozen=True)
class StageOutcome:
    status: ResponseStatus
    message: str = ""


# --- Structured model outputs --------------------------------------------------------------


class RequirementsOutput(BaseModel):
    in_scope: bool
    scope_reason: str = ""
    requirements: RequirementsRecord = Field(default_factory=RequirementsRecord)
    questions: list[Question] = Field(default_factory=list)


class GenerationOutput(BaseModel):
    architecture_summary: str
    artifacts: list[Artifact]
    approvals_required: list[str] = Field(default_factory=list)
    next_steps: list[str] = Field(default_factory=list)


def _ask(ctx: StageContext, stage: str, task: str, schema: type[BaseModel],
         messages: list[Message]) -> BaseModel:
    """One model call with a single repair attempt for malformed output."""
    system = prompts.stage_system(ctx.content.instructions, ctx.skills.for_stage(stage), stage, task, schema)
    for attempt in range(2):
        try:
            response = ctx.llm.converse(system, messages, max_tokens=ctx.max_tokens,
                                        temperature=ctx.temperature)
        except LLMError as exc:
            raise StageError("LLM-UNAVAILABLE", str(exc)) from exc
        if response.stop_reason == "max_tokens":
            raise StageError("LLM-TRUNCATED", f"Model output for {stage} hit the token limit")
        try:
            return schema.model_validate(prompts.extract_json(response.text))
        except (ValueError, ValidationError) as exc:
            log.warning("Malformed model output", extra={"stage": stage, "attempt": attempt})
            messages = messages + [
                Message("assistant", response.text),
                Message("user", f"That response did not match the output schema ({type(exc).__name__}). "
                                "Reply with only the corrected JSON object."),
            ]
    raise StageError("LLM-OUTPUT", f"Model output for {stage} did not match the schema")


# --- Stages --------------------------------------------------------------------------------


class ScopeStage:
    """Deterministic pre-check of the latest request for prohibited intents."""

    name = "scope"

    def run(self, ctx: StageContext) -> StageOutcome | None:
        blockers = detect_prohibited_intents(ctx.latest_user_text)
        if blockers:
            ctx.blockers += blockers
            return StageOutcome(ResponseStatus.BLOCKED)
        return None


class RequirementsStage:
    name = "requirements"

    def run(self, ctx: StageContext) -> StageOutcome | None:
        messages = [
            Message(t.role, prompts.wrap("user_request", t.text) if t.role == "user" else t.text)
            for t in ctx.session.turns
        ]
        output = _ask(ctx, self.name, prompts.REQUIREMENTS_TASK, RequirementsOutput, messages)
        if not output.in_scope:
            return StageOutcome(
                ResponseStatus.OUT_OF_SCOPE,
                "This request is outside this agent's scope. It supports AWS GovCloud Landing Zone "
                "infrastructure design, Terraform, and GitLab CI/CD. Please use the appropriate "
                "workflow for other requests.",
            )
        requirements = output.requirements
        for account in requirements.accounts:  # no trusted inventory is integrated yet
            account.verification_status = "unknown"
        ctx.requirements = ctx.session.requirements = requirements

        questions = output.questions
        if not questions and not requirements.services:
            questions = [Question(id="services", text="Which AWS services does the workload need?",
                                  field="services")]
        if questions:
            ctx.questions = questions[:5]
            return StageOutcome(ResponseStatus.NEEDS_INPUT)
        ctx.validation.requirements = CheckStatus.PASSED
        return None


class ServiceEligibilityStage:
    name = "service_eligibility"

    def run(self, ctx: StageContext) -> StageOutcome | None:
        assert ctx.requirements is not None
        remote = ctx.remote["service_enablement"].lookup(", ".join(ctx.requirements.services))
        for service in ctx.requirements.services:
            entry, path = ctx.catalog.find(service)
            status = entry.verified_enablement() if entry else EnablementStatus.UNKNOWN
            if entry and path:
                ctx.entries[service] = entry
                ctx.enablement_evidence.append(ctx.catalog.evidence(entry, path))
            if status != EnablementStatus.ENABLED:
                ctx.blockers.append(Blocker(
                    code=f"SVC-{status.value.upper()}",
                    detail=f"Service enablement for {service} is {status.value}.",
                    remediation="Confirm enablement and scope in the Service Enablement source. "
                                f"({remote.detail})",
                ))
            elif entry and entry.regions and ctx.requirements.regions:
                outside = sorted(set(ctx.requirements.regions) - set(entry.regions))
                if outside:
                    ctx.blockers.append(Blocker(
                        code="SVC-REGION",
                        detail=f"{service} is not recorded as enabled in {', '.join(outside)}.",
                        remediation="Confirm Region scope with the Service Enablement owner.",
                    ))
        return None


class LandingZoneStage:
    name = "landing_zone"

    def run(self, ctx: StageContext) -> StageOutcome | None:
        assert ctx.requirements is not None
        for item in ctx.requirements.decision_log.prohibited_requirements:
            ctx.blockers.append(Blocker(
                code="LZ-REVIEW",
                detail=f"Conflicts with Landing Zone restrictions: {item}",
                remediation="Use infrastructure delivered by the Landing Zone, or raise a "
                            "platform-team request through the governance process.",
            ))
        return None


class PatternDiscoveryStage:
    name = "pattern_discovery"

    def run(self, ctx: StageContext) -> StageOutcome | None:
        assert ctx.requirements is not None
        for service in ctx.requirements.services:
            entry = ctx.entries.get(service)
            approved = entry.approved_patterns() if entry else []
            if not approved:
                ctx.unmatched_services.append(service)
                continue
            pattern = approved[0]
            ctx.patterns.append(PatternRef(
                service=service, project=pattern.project, path=pattern.path,
                revision=pattern.revision, approval_status=pattern.status,
                rationale="Approved pattern recorded in the service catalog; fit to the "
                          "requirements must be confirmed in review.",
            ))
        return None


class DecisionStage:
    name = "decision"

    def run(self, ctx: StageContext) -> StageOutcome | None:
        if ctx.unmatched_services:
            search = ctx.remote["codebank_patterns"].lookup(", ".join(ctx.unmatched_services))
            if search.status == LookupStatus.NOT_CONFIGURED:
                ctx.blockers.append(Blocker(
                    code="PATTERN-SEARCH-INCOMPLETE",
                    detail="No approved pattern recorded for "
                           f"{', '.join(ctx.unmatched_services)}, and Codebank search is unavailable "
                           f"({search.detail}). A catalog miss does not prove no pattern exists.",
                    remediation="Search Codebank patterns and examples, then record verified "
                                "patterns in the service catalog.",
                ))
            else:
                ctx.blockers.append(Blocker(
                    code="PATTERN-GAP",
                    detail=f"No suitable approved pattern found for {', '.join(ctx.unmatched_services)}.",
                    remediation="Follow the pattern-gap-analysis skill and the Codebank "
                                "contribution workflow (agent/templates/pattern-gap-issue.md).",
                ))
        if ctx.blockers:
            ctx.decision = PathDecision.BLOCKED
            return StageOutcome(ResponseStatus.BLOCKED)
        ctx.decision = PathDecision.REUSE if len(ctx.patterns) == 1 else PathDecision.COMPOSE
        return None


class GenerateStage:
    name = "generate"

    def run(self, ctx: StageContext) -> StageOutcome | None:
        assert ctx.requirements is not None
        context = {
            "requirements": ctx.requirements.model_dump(mode="json"),
            "decision": ctx.decision,
            "selected_patterns": [p.model_dump(mode="json") for p in ctx.patterns],
            "landing_zone_prohibited_creation": ctx.content.guardrails.get("prohibited_creation", []),
            "service_restrictions": {s: e.restrictions for s, e in ctx.entries.items()},
        }
        message = Message("user", prompts.wrap("solution_context", json.dumps(context, indent=1)))
        output = _ask(ctx, self.name, prompts.GENERATE_TASK, GenerationOutput, [message])
        if not output.artifacts:
            raise StageError("GEN-EMPTY", "The model returned no artifacts")
        ctx.architecture_summary = output.architecture_summary
        ctx.artifacts = output.artifacts
        ctx.approvals = output.approvals_required
        ctx.next_steps += output.next_steps
        return None


class ValidateStage:
    name = "validate"

    def run(self, ctx: StageContext) -> StageOutcome | None:
        findings = scan_artifacts(ctx.artifacts, prohibited_types=ctx.content.prohibited_resource_types,
                                  allowed_patterns=ctx.patterns)
        if any(f.code == "SEC-001" for f in findings):
            ctx.artifacts = [a.model_copy(update={"content": redact(a.content)}) for a in ctx.artifacts]
        errors = [f for f in findings if f.severity == "error"]
        ctx.validation.findings = findings
        ctx.validation.architecture_policy = CheckStatus.FAILED if errors else CheckStatus.PASSED
        ctx.validation.evidence.append(
            f"architecture_policy: agent_core deterministic pre-check over {len(ctx.artifacts)} "
            f"artifact(s); {len(errors)} error(s), {len(findings) - len(errors)} warning(s). "
            "Root-module text only; nested module resources are not inspected."
        )
        ctx.validation.evidence.append(
            "terraform_validate, naming_tagging, checkov, pipeline_integrity: not_run here; they "
            "run in the authoritative GitLab pipeline."
        )
        if errors:
            ctx.blockers += [Blocker(code=f.code, detail=f"{f.path}:{f.line or '-'} {f.detail}")
                             for f in errors]
            return StageOutcome(ResponseStatus.BLOCKED)
        return None


class PackageStage:
    """Delivery (branch/merge request) is not enabled in this phase."""

    name = "package"

    def run(self, ctx: StageContext) -> StageOutcome | None:
        ctx.approvals = sorted(set(ctx.approvals) | {"Codebank pattern owner review",
                                                    "Merge request review"})
        ctx.next_steps += [
            "Run terraform fmt and validate through the approved tf wrapper.",
            "Run Checkov and the approved GitLab pipeline; validation stays not_run until then.",
            "Confirm target accounts and delivered network references from the trusted inventory.",
        ]
        return StageOutcome(ResponseStatus.VALIDATION_PENDING)


DEFAULT_STAGES = (
    ScopeStage(),
    RequirementsStage(),
    ServiceEligibilityStage(),
    LandingZoneStage(),
    PatternDiscoveryStage(),
    DecisionStage(),
    GenerateStage(),
    ValidateStage(),
    PackageStage(),
)
