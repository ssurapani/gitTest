"""Conversation and solution state. The in-memory store is for single-task testing only."""
import threading
import uuid
from collections import OrderedDict
from datetime import UTC, datetime
from typing import Literal, Protocol

from pydantic import BaseModel, Field

from agent_core.models.request import RequirementsRecord
from agent_core.models.solution import SolutionRecord
from agent_core.models.status import ResponseStatus


def _now() -> datetime:
    return datetime.now(UTC)


class Turn(BaseModel):
    role: Literal["user", "assistant"]
    text: str
    at: datetime = Field(default_factory=_now)


class Session(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    owner: str | None = None  # caller identity that created the session
    created_at: datetime = Field(default_factory=_now)
    updated_at: datetime = Field(default_factory=_now)
    turns: list[Turn] = Field(default_factory=list)
    status: ResponseStatus | None = None
    requirements: RequirementsRecord | None = None
    solution_ids: list[str] = Field(default_factory=list)


class SessionStore(Protocol):
    def create(self, owner: str | None = None) -> Session: ...
    def get(self, session_id: str) -> Session | None: ...
    def save(self, session: Session) -> None: ...
    def save_solution(self, solution: SolutionRecord) -> None: ...
    def get_solution(self, solution_id: str) -> SolutionRecord | None: ...


class InMemorySessionStore:
    """Bounded, thread-safe, process-local store. Evicts the least recently saved items."""

    def __init__(self, max_items: int = 1000):
        self._max = max_items
        self._lock = threading.Lock()
        self._sessions: OrderedDict[str, Session] = OrderedDict()
        self._solutions: OrderedDict[str, SolutionRecord] = OrderedDict()

    def create(self, owner: str | None = None) -> Session:
        session = Session(owner=owner)
        self.save(session)
        return session.model_copy(deep=True)

    def get(self, session_id: str) -> Session | None:
        with self._lock:
            session = self._sessions.get(session_id)
            return session.model_copy(deep=True) if session else None

    def save(self, session: Session) -> None:
        session.updated_at = _now()
        with self._lock:
            self._put(self._sessions, session.id, session.model_copy(deep=True))

    def save_solution(self, solution: SolutionRecord) -> None:
        with self._lock:
            self._put(self._solutions, solution.id, solution.model_copy(deep=True))

    def get_solution(self, solution_id: str) -> SolutionRecord | None:
        with self._lock:
            solution = self._solutions.get(solution_id)
            return solution.model_copy(deep=True) if solution else None

    def _put(self, items: OrderedDict, key: str, value) -> None:
        items[key] = value
        items.move_to_end(key)
        while len(items) > self._max:
            items.popitem(last=False)
