"""Runs the stage pipeline for one user turn and records the result in the session store."""
import logging
import uuid
from collections.abc import Sequence
from dataclasses import dataclass, field

from agent_core.content.loader import AgentContent
from agent_core.content.registry import SkillRegistry
from agent_core.llm.base import LLMClient
from agent_core.models.request import Question
from agent_core.models.solution import Blocker, SolutionRecord
from agent_core.models.status import ResponseStatus, SolutionStatus
from agent_core.orchestration.session import SessionStore, Turn
from agent_core.orchestration.stages import (
    DEFAULT_STAGES,
    StageContext,
    StageError,
    StageOutcome,
)
from agent_core.retrieval.base import Source
from agent_core.retrieval.catalog import ServiceCatalog

log = logging.getLogger(__name__)


class SessionNotFound(LookupError):
    pass


class InvalidRequest(ValueError):
    pass


@dataclass
class PipelineResult:
    session_id: str
    status: ResponseStatus
    message: str
    questions: list[Question] = field(default_factory=list)
    blockers: list[Blocker] = field(default_factory=list)
    solution: SolutionRecord | None = None


class AgentPipeline:
    def __init__(
        self,
        *,
        content: AgentContent,
        llm: LLMClient,
        catalog: ServiceCatalog,
        remote: dict[str, Source],
        store: SessionStore,
        max_tokens: int,
        temperature: float | None = None,
        max_request_chars: int = 20000,
        stages: Sequence = DEFAULT_STAGES,
    ):
        self.content = content
        self.skills = SkillRegistry(content.skills)
        self.llm = llm
        self.catalog = catalog
        self.remote = remote
        self.store = store
        self.max_tokens = max_tokens
        self.temperature = temperature
        self.max_request_chars = max_request_chars
        self.stages = tuple(stages)

    def run(self, text: str, session_id: str | None = None, *, owner: str | None = None) -> PipelineResult:
        """Run one user turn. An existing session can only be continued by its owner."""
        text = text.strip()
        if not text:
            raise InvalidRequest("Request text is empty")
        if len(text) > self.max_request_chars:
            raise InvalidRequest(f"Request exceeds {self.max_request_chars} characters")
        session = self.store.get(session_id) if session_id else self.store.create(owner)
        if session is None or session.owner != owner:
            raise SessionNotFound(session_id)
        session.turns.append(Turn(role="user", text=text))

        ctx = StageContext(
            session=session, content=self.content, skills=self.skills, llm=self.llm,
            catalog=self.catalog, remote=self.remote, max_tokens=self.max_tokens,
            temperature=self.temperature,
        )
        outcome = StageOutcome(ResponseStatus.BLOCKED)
        for stage in self.stages:
            log.info("Stage started", extra={"stage": stage.name, "session_id": session.id})
            try:
                result = stage.run(ctx)
            except StageError as exc:
                ctx.blockers.append(Blocker(code=exc.code, detail=str(exc),
                                            remediation="Retry the request; if it persists, "
                                                        "contact the agent owners."))
                result = StageOutcome(ResponseStatus.BLOCKED)
            if result is not None:
                outcome = result
                break

        solution = self._solution(ctx, outcome.status)
        message = outcome.message or _compose_message(outcome.status, ctx)
        session.turns.append(Turn(role="assistant", text=message))
        session.status = outcome.status
        if solution:
            session.solution_ids.append(solution.id)
            self.store.save_solution(solution)
        self.store.save(session)
        log.info("Turn finished", extra={"status": outcome.status, "session_id": session.id,
                                         "content_version": self.content.version})
        return PipelineResult(session_id=session.id, status=outcome.status, message=message,
                              questions=ctx.questions, blockers=ctx.blockers, solution=solution)

    def _solution(self, ctx: StageContext, status: ResponseStatus) -> SolutionRecord | None:
        if status not in (ResponseStatus.BLOCKED, ResponseStatus.VALIDATION_PENDING):
            return None
        return SolutionRecord(
            id=str(uuid.uuid4()),
            session_id=ctx.session.id,
            status=SolutionStatus(status.value),
            content_version=self.content.version,
            model_id=self.llm.model_id,
            requirements=ctx.requirements,
            decision=ctx.decision,
            architecture_summary=ctx.architecture_summary,
            service_enablement_evidence=ctx.enablement_evidence,
            selected_patterns=ctx.patterns,
            artifacts=ctx.artifacts,
            validation=ctx.validation,
            approvals_required=ctx.approvals,
            blockers=ctx.blockers,
            next_steps=ctx.next_steps,
        )


def _compose_message(status: ResponseStatus, ctx: StageContext) -> str:
    if status == ResponseStatus.NEEDS_INPUT:
        lines = ["I need a few details before I can select patterns:"]
        lines += [f"- {q.text}" for q in ctx.questions]
        return "\n".join(lines)
    if status == ResponseStatus.BLOCKED:
        lines = ["I can't produce candidate IaC for this request yet:"]
        for blocker in ctx.blockers:
            lines.append(f"- [{blocker.code}] {blocker.detail}")
            if blocker.remediation:
                lines.append(f"  Next: {blocker.remediation}")
        return "\n".join(lines)
    return (
        f"Generated {len(ctx.artifacts)} candidate file(s) from {len(ctx.patterns)} Codebank "
        "pattern(s). They are not approved. Checkov, terraform validate, and the GitLab pipeline "
        "have not run (not_run); see the solution record for findings and next steps."
    )
