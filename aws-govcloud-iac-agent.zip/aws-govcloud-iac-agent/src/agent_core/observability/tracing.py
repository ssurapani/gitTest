"""Request and correlation IDs propagated through logs via context variables."""
import re
import uuid
from collections.abc import Iterator
from contextlib import contextmanager
from contextvars import ContextVar

_request_id: ContextVar[str | None] = ContextVar("request_id", default=None)
_correlation_id: ContextVar[str | None] = ContextVar("correlation_id", default=None)
_SAFE_ID = re.compile(r"^[A-Za-z0-9_.:-]{1,128}$")


def sanitize_id(value: str | None) -> str | None:
    """Accept caller-supplied IDs only if they are short and log-safe."""
    return value if value and _SAFE_ID.match(value) else None


@contextmanager
def request_context(request_id: str | None = None, correlation_id: str | None = None) -> Iterator[str]:
    request_id = sanitize_id(request_id) or str(uuid.uuid4())
    tokens = (_request_id.set(request_id), _correlation_id.set(sanitize_id(correlation_id)))
    try:
        yield request_id
    finally:
        _request_id.reset(tokens[0])
        _correlation_id.reset(tokens[1])


def current_request_id() -> str | None:
    return _request_id.get()


def current_correlation_id() -> str | None:
    return _correlation_id.get()
