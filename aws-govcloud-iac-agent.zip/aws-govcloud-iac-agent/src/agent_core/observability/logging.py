"""Structured JSON logs with secret redaction. Request and response bodies are never logged."""
import json
import logging
import sys
from datetime import UTC, datetime

from agent_core.guardrails.secrets import redact
from agent_core.observability.tracing import current_correlation_id, current_request_id

_EXTRA_FIELDS = ("stage", "status", "session_id", "content_version", "model_id", "attempt",
                 "duration_ms", "subject", "client_id")


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload = {
            "ts": datetime.fromtimestamp(record.created, UTC).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "msg": redact(record.getMessage()),
            "request_id": current_request_id(),
            "correlation_id": current_correlation_id(),
        }
        payload.update({k: getattr(record, k) for k in _EXTRA_FIELDS if hasattr(record, k)})
        if record.exc_info and record.exc_info[0]:
            payload["exc_type"] = record.exc_info[0].__name__
        return json.dumps(payload, default=str)


def configure_logging(level: str = "INFO") -> None:
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(JsonFormatter())
    root = logging.getLogger()
    root.handlers[:] = [handler]
    root.setLevel(level.upper())
