"""Minimal HCL structure helpers for static checks. Not a full parser.

Known limits: heredocs and quotes nested inside ${...} interpolation are not modeled.
"""
import re
from dataclasses import dataclass

_ASSIGNMENT = re.compile(r"^[ \t]*([A-Za-z_][\w-]*)[ \t]*=(?!=)[ \t]*(.*)$", re.M)


@dataclass(frozen=True)
class Block:
    header: str  # text before "{" on the same line, e.g. 'resource "aws_lb" "this"'
    start: int  # index of "{"
    end: int  # index of the matching "}"
    line: int


def strip_comments(text: str) -> str:
    """Blank out comments outside strings, preserving offsets and line numbers."""
    out: list[str] = []
    i, n, in_string = 0, len(text), False
    while i < n:
        char = text[i]
        if in_string:
            out.append(char)
            if char == "\\" and i + 1 < n:
                out.append(text[i + 1])
                i += 2
                continue
            if char in '"\n':
                in_string = False
            i += 1
            continue
        if char == '"':
            in_string = True
            out.append(char)
            i += 1
        elif char == "#" or text.startswith("//", i):
            end = text.find("\n", i)
            end = n if end == -1 else end
            out.append(" " * (end - i))
            i = end
        elif text.startswith("/*", i):
            end = text.find("*/", i + 2)
            end = n if end == -1 else end + 2
            out.append("".join(c if c == "\n" else " " for c in text[i:end]))
            i = end
        else:
            out.append(char)
            i += 1
    return "".join(out)


def parse_blocks(text: str) -> list[Block]:
    """Find brace-delimited blocks in comment-stripped text."""
    blocks: list[Block] = []
    stack: list[tuple[str, int, int]] = []
    i, in_string = 0, False
    while i < len(text):
        char = text[i]
        if in_string:
            if char == "\\":
                i += 2
                continue
            if char in '"\n':
                in_string = False
        elif char == '"':
            in_string = True
        elif char == "{":
            line_start = text.rfind("\n", 0, i) + 1
            stack.append((text[line_start:i].strip(), i, text.count("\n", 0, i) + 1))
        elif char == "}" and stack:
            header, start, line = stack.pop()
            blocks.append(Block(header, start, i, line))
        i += 1
    blocks += [Block(header, start, len(text), line) for header, start, line in stack]
    return blocks


def containing(blocks: list[Block], position: int) -> list[Block]:
    """Blocks containing position, innermost first."""
    return sorted((b for b in blocks if b.start < position <= b.end), key=lambda b: -b.start)


def top_level_arguments(text: str, blocks: list[Block], block: Block) -> dict[str, tuple[str, int]]:
    """Arguments assigned directly in block (not in nested blocks): name -> (value, line)."""
    arguments = {}
    for match in _ASSIGNMENT.finditer(text, block.start + 1, block.end):
        inner = containing(blocks, match.start())
        if inner and inner[0] == block:
            arguments[match.group(1)] = (match.group(2).strip(), text.count("\n", 0, match.start()) + 1)
    return arguments


def line_of(text: str, position: int) -> int:
    return text.count("\n", 0, position) + 1
