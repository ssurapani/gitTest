"""Static checks on generated Terraform. Root-module text only; modules need plan-level checks."""
import re
from collections.abc import Sequence

from agent_core.guardrails.hcl import (
    containing,
    line_of,
    parse_blocks,
    strip_comments,
    top_level_arguments,
)
from agent_core.models.solution import Finding, PatternRef

CHECK = "architecture_policy"
POLICY_CODES = {
    "aws_vpc": "LZ-001",
    "aws_subnet": "LZ-002",
    "aws_ec2_transit_gateway": "LZ-003",
    "aws_iam_user": "LZ-004",
    "aws_cloudfront_distribution": "LZ-005",
}
LOAD_BALANCER_TYPES = {"aws_lb", "aws_alb", "aws_elb"}
INGRESS_RESOURCE_TYPES = {"aws_vpc_security_group_ingress_rule"}
MODULE_META_ARGUMENTS = {"source", "version", "count", "for_each", "providers", "depends_on"}

_RESOURCE = re.compile(r'^resource\s+"([\w-]+)"\s+"[\w-]+"$')
_DATA = re.compile(r'^data\s+"([\w-]+)"\s+"[\w-]+"$')
_MODULE = re.compile(r'^module\s+"([\w-]+)"$')
_PROVISIONER = re.compile(r'^provisioner\s+"(local-exec|remote-exec)"$')
_INGRESS_BLOCK = re.compile(r'^(?:dynamic\s+")?ingress"?$')
_OPEN_CIDR = re.compile(r'"(0\.0\.0\.0/0|::/0)"')
_PUBLIC_IP = re.compile(r"^\s*(associate_public_ip_address|map_public_ip_on_launch)\s*=\s*true\b", re.M)
_CHECKOV_SKIP = re.compile(r"checkov:skip", re.I)


def _finding(path: str, code: str, line: int | None, detail: str, severity: str = "error") -> Finding:
    return Finding(check=CHECK, code=code, severity=severity, path=path, line=line, detail=detail)


def _unquote(value: str) -> str:
    return value.strip().strip('"')


def scan_terraform(
    path: str,
    text: str,
    *,
    prohibited_types: Sequence[str],
    allowed_patterns: Sequence[PatternRef] | None,
) -> list[Finding]:
    findings = [
        _finding(path, "CICD-001", line_of(text, m.start()), "Inline Checkov suppression")
        for m in _CHECKOV_SKIP.finditer(text)
    ]
    code = strip_comments(text)
    blocks = parse_blocks(code)

    for block in blocks:
        if match := _RESOURCE.match(block.header):
            resource_type = match.group(1)
            if resource_type in prohibited_types:
                findings.append(_finding(path, POLICY_CODES.get(resource_type, "LZ-PROHIBITED"),
                                         block.line, f"Prohibited resource type {resource_type}"))
            if resource_type == "null_resource":
                findings.append(_finding(path, "SCRIPT-001", block.line, "null_resource is not allowed"))
            if resource_type in LOAD_BALANCER_TYPES:
                internal = top_level_arguments(code, blocks, block).get("internal", ("false", 0))[0]
                if internal != "true":
                    findings.append(_finding(path, "LZ-006", block.line,
                                             f"{resource_type} must set internal = true"))
        elif (match := _DATA.match(block.header)) and match.group(1) == "external":
            findings.append(_finding(path, "SCRIPT-001", block.line, "external data source runs a program"))
        elif _PROVISIONER.match(block.header):
            findings.append(_finding(path, "SCRIPT-001", block.line, f"{block.header} is not allowed"))
        elif _MODULE.match(block.header):
            findings += _check_module(path, code, blocks, block, allowed_patterns)

    for match in _OPEN_CIDR.finditer(code):
        line = line_of(code, match.start())
        if _in_ingress(code, blocks, match.start()):
            findings.append(_finding(path, "LZ-006", line, f"Ingress open to {match.group(1)}"))
        else:
            findings.append(_finding(path, "LZ-006", line, f"Review use of {match.group(1)}", "warning"))
    for match in _PUBLIC_IP.finditer(code):
        findings.append(_finding(path, "LZ-006", line_of(code, match.start()), f"{match.group(1)} = true"))
    return findings


def scan_tfvars(path: str, text: str) -> list[Finding]:
    code = strip_comments(text)
    return [
        _finding(path, "LZ-006", line_of(code, m.start()), f"Review use of {m.group(1)}", "warning")
        for m in _OPEN_CIDR.finditer(code)
    ]


def _in_ingress(code: str, blocks, position: int) -> bool:
    for block in containing(blocks, position):
        if _INGRESS_BLOCK.match(block.header):
            return True
        if match := _RESOURCE.match(block.header):
            if match.group(1) in INGRESS_RESOURCE_TYPES:
                return True
            if match.group(1) == "aws_security_group_rule":
                rule_type = top_level_arguments(code, blocks, block).get("type", ("", 0))[0]
                return _unquote(rule_type) == "ingress"
    return False


def _check_module(path, code, blocks, block, allowed_patterns) -> list[Finding]:
    findings = []
    arguments = top_level_arguments(code, blocks, block)
    if "source" not in arguments:
        return [_finding(path, "MOD-SOURCE", block.line, f"{block.header} has no source")]
    source, line = _unquote(arguments["source"][0]), arguments["source"][1]

    if allowed_patterns is not None:
        match = next((p for p in allowed_patterns if p.project in source and p.path in source), None)
        if match is None:
            findings.append(_finding(path, "MOD-SOURCE", line,
                                     f"Module source is not a selected Codebank pattern: {source}"))
        elif match.revision and f"ref={match.revision}" not in source and "version" not in arguments:
            findings.append(_finding(path, "MOD-REVISION", line,
                                     f"Module must be pinned to approved revision {match.revision}"))
    if "?ref=" not in source and "version" not in arguments:
        findings.append(_finding(path, "MOD-UNPINNED", line, "Module source is not pinned"))

    inputs = sorted(set(arguments) - MODULE_META_ARGUMENTS)
    if inputs:
        findings.append(_finding(path, "MOD-INPUT-UNVERIFIED", block.line,
                                 "Module inputs not verified against the pattern interface: "
                                 + ", ".join(inputs), "warning"))
    return findings
