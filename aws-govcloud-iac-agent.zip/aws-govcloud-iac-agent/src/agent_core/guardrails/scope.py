"""Pre-model detection of requests that conflict with Landing Zone or execution restrictions.

Patterns are deliberately narrow (creation verbs, explicit bypass wording) to avoid blocking
requests that merely mention a restricted resource, such as deploying into an existing VPC.
"""
import re
from dataclasses import dataclass

from agent_core.models.solution import Blocker

_ARTICLE = r"(?:a\s+|an\s+|the\s+|my\s+|our\s+)?(?:new\s+|separate\s+|dedicated\s+|own\s+)?"
_CREATE = r"\b(?:create|provision|build|stand\s+up|spin\s+up|add|make)\s+" + _ARTICLE


@dataclass(frozen=True)
class _Intent:
    code: str
    pattern: re.Pattern[str]
    detail: str
    remediation: str
    unless: re.Pattern[str] | None = None


_INTENTS = (
    _Intent(
        "LZ-001",
        re.compile(rf"{_CREATE}vpcs?\b|\bnew\s+vpcs?\b", re.I),
        "New VPCs are not allowed in application-owned Landing Zone accounts.",
        "Deploy into the VPC delivered by the Landing Zone, referenced by ID from the trusted "
        "account inventory. Additional network capacity is a platform-team request.",
    ),
    _Intent(
        "LZ-002",
        re.compile(rf"{_CREATE}subnets?\b|\bnew\s+subnets?\b", re.I),
        "New subnets are not allowed in application-owned Landing Zone accounts.",
        "Use the delivered subnets. Non-routable IP space is requestable from the platform team; "
        "it is not assumed to exist.",
    ),
    _Intent(
        "LZ-003",
        re.compile(rf"{_CREATE}transit\s+gateways?\b|\bnew\s+transit\s+gateways?\b", re.I),
        "New Transit Gateways are not allowed in application-owned Landing Zone accounts.",
        "Use the Transit Gateway connectivity delivered by the Landing Zone.",
    ),
    _Intent(
        "LZ-004",
        re.compile(rf"{_CREATE}iam\s+users?\b|\bnew\s+iam\s+users?\b", re.I),
        "IAM users are not allowed.",
        "Use IAM roles (for example ECS task roles or federated access) through approved patterns.",
    ),
    _Intent(
        "LZ-005",
        re.compile(
            r"\b(?:add|use|create|enable|provision|behind|via|through|with)\b[^.\n]{0,30}"
            r"\bcloud\s?front\b|\bcloud\s?front\s+distributions?\b",
            re.I,
        ),
        "CloudFront distributions are not allowed.",
        "Serve the application through an internal load balancer on the delivered network. Any "
        "change to this restriction goes through platform governance.",
    ),
    _Intent(
        "LZ-006",
        re.compile(
            r"\b(?:public(?:ly)?|internet[- ]facing|from\s+the\s+internet)\b[^.\n]{0,40}"
            r"\b(?:ingress|access(?:ible)?|exposed?|endpoint|load\s+balancer|alb|reachable)\b"
            r"|\bexpos(?:e|ed|ing)\b[^.\n]{0,30}\b(?:public(?:ly)?|internet)\b"
            r"|0\.0\.0\.0/0|::/0",
            re.I,
        ),
        "Public ingress is not allowed in application-owned Landing Zone accounts.",
        "Use internal-only access over the delivered network path. Public exposure requires a "
        "platform-team review.",
        unless=re.compile(r"\b(?:no|not|without|never|avoid|prevent|block)\s+(?:any\s+)?"
                          r"(?:public|internet)", re.I),
    ),
    _Intent(
        "CICD-001",
        re.compile(
            r"\b(?:remove|disable|skip|bypass|turn\s+off|suppress|ignore)\b[^.\n]{0,30}"
            r"\b(?:checkov|security\s+scans?|compliance\s+checks?|approval\s+gates?|approvals?)\b",
            re.I,
        ),
        "Mandatory validation and approval gates cannot be removed or bypassed.",
        "Share the failing findings so they can be remediated in the code. Exceptions go through "
        "the authorized governance process.",
    ),
    _Intent(
        "AGENT-EXEC",
        re.compile(
            r"\b(?:run|execute|do)\b[^.\n]{0,20}\bterraform\s+(?:apply|destroy)\b"
            r"|-auto-approve\b|\bdeploy\b[^.\n]{0,20}\bdirectly\b",
            re.I,
        ),
        "This agent cannot run terraform apply/destroy or deploy resources (agent/config/agent.yaml).",
        "Deployment runs only through the approved GitLab pipeline and its approval gates.",
        unless=re.compile(r"\bpipeline\b", re.I),
    ),
)


def detect_prohibited_intents(text: str) -> list[Blocker]:
    blockers = []
    for sentence in re.split(r"(?<=[.!?;])\s+|\n", text):
        for intent in _INTENTS:
            if intent.pattern.search(sentence) and not (intent.unless and intent.unless.search(sentence)):
                if all(b.code != intent.code for b in blockers):
                    blockers.append(Blocker(code=intent.code, detail=intent.detail,
                                            remediation=intent.remediation))
    return blockers
