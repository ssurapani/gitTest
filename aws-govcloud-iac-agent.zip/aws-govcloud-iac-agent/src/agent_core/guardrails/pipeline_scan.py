"""Static checks on generated GitLab CI files for weakened compliance controls."""
import re
from pathlib import PurePosixPath

import yaml

from agent_core.models.solution import Finding

CHECK = "architecture_policy"
RESERVED_KEYS = {"stages", "variables", "include", "default", "workflow", "image", "services",
                 "before_script", "after_script", "cache"}
_COMPLIANCE = re.compile(r"checkov|sast|secret|scan|compliance|policy|security", re.I)
_SUPPRESSION = re.compile(r"--skip-check\b|--soft-fail\b|\bsoft_fail\s*:\s*true\b", re.I)
_PIPE_TO_SHELL = re.compile(r"\b(?:curl|wget)\b[^|\n]*\|\s*(?:ba)?sh\b")
_APPLY = re.compile(r"\b(?:terraform|tf)\s+apply\b")


class _GitLabLoader(yaml.SafeLoader):
    """Safe loader that tolerates GitLab tags such as !reference."""


_GitLabLoader.add_multi_constructor("!", lambda loader, suffix, node: None)


def is_pipeline_file(path: str) -> bool:
    parts = PurePosixPath(path).parts
    return path.endswith(".gitlab-ci.yml") or (
        path.endswith((".yml", ".yaml")) and any(p in ("ci", ".gitlab") for p in parts)
    )


def _finding(path: str, code: str, line: int | None, detail: str, severity: str = "error") -> Finding:
    return Finding(check=CHECK, code=code, severity=severity, path=path, line=line, detail=detail)


def scan_pipeline(path: str, text: str) -> list[Finding]:
    findings = []
    for number, line in enumerate(text.splitlines(), start=1):
        if _SUPPRESSION.search(line):
            findings.append(_finding(path, "CICD-001", number, "Compliance check suppressed or soft-failed"))
        if _PIPE_TO_SHELL.search(line):
            findings.append(_finding(path, "SCRIPT-002", number, "Downloaded script piped to a shell"))

    try:
        document = yaml.load(text, Loader=_GitLabLoader)  # noqa: S506 - SafeLoader subclass
    except yaml.YAMLError:
        return findings + [_finding(path, "CICD-PARSE", None, "Pipeline file is not valid YAML")]
    if not isinstance(document, dict):
        return findings

    for name, job in document.items():
        if name in RESERVED_KEYS or not isinstance(job, dict):
            continue
        if job.get("allow_failure") not in (None, False):
            if _COMPLIANCE.search(str(name)) or _COMPLIANCE.search(str(job.get("stage", ""))):
                findings.append(_finding(path, "CICD-001", None, f"Compliance job {name} may fail silently"))
            else:
                findings.append(_finding(path, "CICD-ALLOW-FAILURE", None,
                                         f"Job {name} sets allow_failure", "warning"))
        script = job.get("script") or []
        script_text = "\n".join(script) if isinstance(script, list) else str(script)
        if _APPLY.search(script_text) and job.get("when") != "manual" and "rules" not in job:
            findings.append(_finding(path, "CICD-APPLY-GATE", None,
                                     f"Job {name} applies without a manual gate", "warning"))
    return findings
