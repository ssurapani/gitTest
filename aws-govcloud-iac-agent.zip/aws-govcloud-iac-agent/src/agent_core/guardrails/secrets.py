"""Secret detection for generated artifacts and log redaction. Complements, not replaces, CI secret scanning."""
import re

from agent_core.models.solution import Finding

_PATTERNS = (
    ("AWS access key ID", re.compile(r"\b(?:AKIA|ASIA|A3T[A-Z0-9])[A-Z0-9]{16}\b")),
    ("AWS secret access key",
     re.compile(r"(?i)aws_secret_access_key\s*[=:]\s*[\"']?[A-Za-z0-9/+=]{40}")),
    ("Private key", re.compile(r"-----BEGIN (?:[A-Z ]+ )?PRIVATE KEY-----")),
    ("GitLab token", re.compile(r"\bglpat-[0-9A-Za-z_\-]{20,}")),
    ("Hardcoded credential",
     re.compile(r"(?i)\b(?:password|passwd|secret|token)\s*[=:]\s*\"(?!REPLACE_WITH_)[^\"\s$]{8,}\"")),
)


def scan_secrets(path: str, text: str) -> list[Finding]:
    findings = []
    for label, pattern in _PATTERNS:
        for match in pattern.finditer(text):
            findings.append(Finding(check="architecture_policy", code="SEC-001", severity="error",
                                    path=path, line=text.count("\n", 0, match.start()) + 1,
                                    detail=f"{label} in generated artifact"))
    return findings


def redact(text: str) -> str:
    for _, pattern in _PATTERNS:
        text = pattern.sub("[REDACTED]", text)
    return text
