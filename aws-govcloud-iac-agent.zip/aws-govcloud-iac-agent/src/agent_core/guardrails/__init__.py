"""Deterministic checks. They add to Checkov and pipeline gates; they never replace them."""
from collections.abc import Sequence

from agent_core.guardrails.pipeline_scan import is_pipeline_file, scan_pipeline
from agent_core.guardrails.scope import detect_prohibited_intents
from agent_core.guardrails.secrets import redact, scan_secrets
from agent_core.guardrails.terraform_scan import scan_terraform, scan_tfvars
from agent_core.models.solution import Artifact, Finding, PatternRef


def scan_artifacts(
    artifacts: Sequence[Artifact],
    *,
    prohibited_types: Sequence[str],
    allowed_patterns: Sequence[PatternRef] | None,
) -> list[Finding]:
    findings: list[Finding] = []
    for artifact in artifacts:
        findings += scan_secrets(artifact.path, artifact.content)
        if artifact.path.endswith(".tf"):
            findings += scan_terraform(
                artifact.path,
                artifact.content,
                prohibited_types=prohibited_types,
                allowed_patterns=allowed_patterns,
            )
        elif artifact.path.endswith((".tfvars", ".hcl")):
            findings += scan_tfvars(artifact.path, artifact.content)
        elif is_pipeline_file(artifact.path):
            findings += scan_pipeline(artifact.path, artifact.content)
    return findings


__all__ = ["detect_prohibited_intents", "redact", "scan_artifacts"]
