"""Loads the read-only agent content (AGENTS.md and the agent/ folder) and validates it."""
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, ConfigDict, Field, ValidationError

from agent_core.content.fingerprint import fingerprint
from agent_core.models.status import SolutionStatus

PLACEHOLDER = "REPLACE_WITH_"
REQUIRED_FILES = (
    "config/agent.yaml",
    "config/landing-zone-guardrails.yaml",
    "config/source-of-truth.yaml",
    "policies/policy-checklist.yaml",
    "policies/prohibited-resource-types.yaml",
    "workflows/solution-decision-workflow.md",
)
# This application has no authorized workflow for any of these actions.
UNSAFE_FLAGS = (
    "direct_aws_provisioning",
    "terraform_apply_allowed",
    "terraform_destroy_allowed",
    "pipeline_execution_allowed",
    "merge_allowed",
)
CONTENT_SUFFIXES = {".md", ".yaml", ".yml"}


class ContentError(RuntimeError):
    """Agent content is missing, malformed, or unsafe; the service must not start."""


class AgentPolicy(BaseModel):
    name: str
    purpose: str
    mode: str
    default_execution_mode: str
    direct_aws_provisioning: bool
    terraform_apply_allowed: bool
    terraform_destroy_allowed: bool
    pipeline_execution_allowed: bool
    merge_allowed: bool
    require_human_approval_for: list[str] = Field(default_factory=list)
    output_status_values: list[str]
    status_rules: list[str] = Field(default_factory=list)


class SourceEntry(BaseModel):
    model_config = ConfigDict(extra="allow")

    system: str
    authority: str

    def is_placeholder(self) -> bool:
        return PLACEHOLDER in self.model_dump_json()


class SourceConfig(BaseModel):
    version: int
    sources: dict[str, SourceEntry]
    retrieval_rules: dict[str, bool] = Field(default_factory=dict)


class PolicyCheck(BaseModel):
    id: str
    description: str
    enforcement: str


@dataclass(frozen=True)
class AgentContent:
    root: Path
    instructions: str
    skills: dict[str, str]
    workflow: str
    policy: AgentPolicy
    guardrails: dict[str, Any]
    sources: SourceConfig
    checks: list[PolicyCheck]
    prohibited_resource_types: tuple[str, ...]
    templates: dict[str, str]
    knowledge_dir: Path
    version: str


def _read_yaml(path: Path) -> Any:
    try:
        return yaml.safe_load(path.read_text(encoding="utf-8"))
    except yaml.YAMLError as exc:
        raise ContentError(f"Invalid YAML in {path.name}: {exc}") from exc


def load_content(content_dir: Path, instructions_path: Path) -> AgentContent:
    content_dir = content_dir.resolve()
    if not instructions_path.is_file():
        raise ContentError(f"Agent instructions not found: {instructions_path}")
    missing = [rel for rel in REQUIRED_FILES if not (content_dir / rel).is_file()]
    if missing:
        raise ContentError(f"Missing agent content files: {', '.join(missing)}")

    try:
        policy = AgentPolicy.model_validate(_read_yaml(content_dir / "config/agent.yaml")["agent"])
        sources = SourceConfig.model_validate(_read_yaml(content_dir / "config/source-of-truth.yaml"))
        checks = [
            PolicyCheck.model_validate(item)
            for item in _read_yaml(content_dir / "policies/policy-checklist.yaml")["checks"]
        ]
        prohibited = _read_yaml(content_dir / "policies/prohibited-resource-types.yaml")
        prohibited_types = tuple(prohibited["prohibited_terraform_resource_types"])
    except (KeyError, TypeError, ValidationError) as exc:
        raise ContentError(f"Agent content failed validation: {exc}") from exc

    enabled = [flag for flag in UNSAFE_FLAGS if getattr(policy, flag)]
    if enabled:
        raise ContentError(f"Unsafe execution flags enabled in agent.yaml: {', '.join(enabled)}")
    if set(policy.output_status_values) != {s.value for s in SolutionStatus}:
        raise ContentError("agent.yaml output_status_values do not match SolutionStatus")

    guardrails = _read_yaml(content_dir / "config/landing-zone-guardrails.yaml")
    if not isinstance(guardrails, dict) or not guardrails.get("prohibited_creation"):
        raise ContentError("landing-zone-guardrails.yaml must define prohibited_creation")

    skills = {
        path.parent.name: path.read_text(encoding="utf-8")
        for path in sorted((content_dir / "skills").glob("*/SKILL.md"))
    }
    templates = {
        path.name: path.read_text(encoding="utf-8")
        for path in sorted((content_dir / "templates").glob("*"))
        if path.is_file()
    }

    files = [("AGENTS.md", instructions_path.read_bytes())]
    files += [
        (path.relative_to(content_dir).as_posix(), path.read_bytes())
        for path in content_dir.rglob("*")
        if path.is_file() and path.suffix in CONTENT_SUFFIXES and path.name != "AGENTS.md"
    ]

    return AgentContent(
        root=content_dir,
        instructions=instructions_path.read_text(encoding="utf-8"),
        skills=skills,
        workflow=(content_dir / "workflows/solution-decision-workflow.md").read_text(encoding="utf-8"),
        policy=policy,
        guardrails=guardrails,
        sources=sources,
        checks=checks,
        prohibited_resource_types=prohibited_types,
        templates=templates,
        knowledge_dir=content_dir / "knowledge",
        version=fingerprint(files),
    )
