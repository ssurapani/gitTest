"""Maps orchestration stages to the skills whose instructions they load."""
from agent_core.content.loader import ContentError

STAGE_SKILLS: dict[str, tuple[str, ...]] = {
    "requirements": ("requirements-discovery", "landing-zone-guardrails", "service-enablement"),
    "landing_zone": ("landing-zone-guardrails",),
    "service_eligibility": ("service-enablement",),
    "pattern_discovery": ("codebank-discovery",),
    "decision": ("iac-composition", "pattern-gap-analysis"),
    "generate": ("terraform-authoring", "gitlab-cicd", "iac-composition", "landing-zone-guardrails"),
    "validate": ("compliance-validation",),
    "package": ("gitlab-delivery",),
}


class SkillRegistry:
    def __init__(self, skills: dict[str, str]):
        required = {name for names in STAGE_SKILLS.values() for name in names}
        missing = sorted(required - skills.keys())
        if missing:
            raise ContentError(f"Missing skills: {', '.join(missing)}")
        self._skills = skills

    def for_stage(self, stage: str) -> list[tuple[str, str]]:
        return [(name, self._skills[name]) for name in STAGE_SKILLS.get(stage, ())]
