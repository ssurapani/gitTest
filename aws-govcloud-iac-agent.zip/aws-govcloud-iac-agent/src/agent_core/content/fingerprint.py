import hashlib
from collections.abc import Iterable


def fingerprint(files: Iterable[tuple[str, bytes]]) -> str:
    """Stable content version over (relative path, bytes) pairs, independent of input order."""
    digest = hashlib.sha256()
    for relative_path, data in sorted(files):
        digest.update(relative_path.encode("utf-8"))
        digest.update(b"\0")
        digest.update(hashlib.sha256(data).digest())
    return "sha256:" + digest.hexdigest()
