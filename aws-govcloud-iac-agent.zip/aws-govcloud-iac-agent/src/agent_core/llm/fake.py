"""Deterministic fake model for tests and local UI work. Not for real design decisions.

The default responses use simple keyword matching so the full pipeline can run end to end
without Bedrock. They are a test harness, not agent behavior.
"""
import json
import re
from collections.abc import Callable, Sequence

from agent_core.llm.base import LLMResponse, Message
from agent_core.orchestration.prompts import stage_of, unwrap

Responder = Callable[[Sequence[str], Sequence[Message]], str]

_SERVICE_KEYWORDS = {
    r"\bs3\b": "Amazon S3",
    r"\bdynamodb\b": "Amazon DynamoDB",
    r"\blambda\b": "AWS Lambda",
    r"\brds\b": "Amazon RDS",
    r"\becs\b|\bfargate\b": "Amazon ECS",
    r"\bsqs\b": "Amazon SQS",
    r"\bsns\b": "Amazon SNS",
    r"\bkms\b": "AWS KMS",
}
_DEPLOYMENT_HINT = re.compile(r"\b(dev|test|prod|production|account|environment)\b", re.I)


def _fenced(value: dict) -> str:
    return "```json\n" + json.dumps(value, indent=1) + "\n```"


def default_requirements(system: Sequence[str], messages: Sequence[Message]) -> str:
    user_text = "\n".join(m.text for m in messages if m.role == "user")
    services = [name for pattern, name in _SERVICE_KEYWORDS.items() if re.search(pattern, user_text, re.I)]
    questions = []
    if not services:
        questions.append({"id": "services", "text": "Which AWS services does the workload need?",
                          "field": "services"})
    if not _DEPLOYMENT_HINT.search(user_text):
        questions.append({"id": "environments",
                          "text": "Which environments and target accounts should this cover?",
                          "field": "accounts"})
    return _fenced({
        "in_scope": True,
        "requirements": {
            "summary": "Fake model summary of the request (local testing only).",
            "services": services,
            "decision_log": {"unknowns": ["Target account IDs (fake model does not resolve them)"]},
        },
        "questions": questions,
    })


def default_generate(system: Sequence[str], messages: Sequence[Message]) -> str:
    context = json.loads(unwrap("solution_context", messages[-1].text) or "{}")
    lines = ["# CANDIDATE - not approved", ""]
    for index, pattern in enumerate(context.get("selected_patterns", [])):
        lines += [
            f'module "pattern_{index}" {{',
            f'  source = "git::https://REPLACE_WITH_GITLAB_HOST/{pattern["project"]}.git//'
            f'{pattern["path"]}?ref={pattern["revision"]}"',
            "",
            "  # Inputs: map from the pattern README at this revision.",
            "}",
            "",
        ]
    return _fenced({
        "architecture_summary": "Fake model composition of the selected patterns.",
        "artifacts": [{"path": "main.tf", "content": "\n".join(lines)}],
        "approvals_required": ["Codebank maintainer review"],
        "next_steps": ["Map module inputs from each pattern README."],
    })


class FakeLLMClient:
    model_id = "fake"

    def __init__(self, responses: dict[str, str | Responder] | None = None):
        self._responses: dict[str, str | Responder] = {
            "requirements": default_requirements,
            "generate": default_generate,
            **(responses or {}),
        }
        self.calls: list[tuple[str | None, list[str], list[Message]]] = []

    def converse(
        self,
        system: Sequence[str],
        messages: Sequence[Message],
        *,
        max_tokens: int,
        temperature: float | None = None,
    ) -> LLMResponse:
        stage = stage_of(list(system))
        self.calls.append((stage, list(system), list(messages)))
        response = self._responses.get(stage or "")
        if response is None:
            text = "{}"
        elif callable(response):
            text = response(system, messages)
        else:
            text = response
        return LLMResponse(text=text, stop_reason="end_turn", model_id=self.model_id)

    def stages_called(self) -> list[str | None]:
        return [stage for stage, _, _ in self.calls]
