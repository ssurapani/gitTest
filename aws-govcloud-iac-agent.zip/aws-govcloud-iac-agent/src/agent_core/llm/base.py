from collections.abc import Sequence
from dataclasses import dataclass
from typing import Literal, Protocol


@dataclass(frozen=True)
class Message:
    role: Literal["user", "assistant"]
    text: str


@dataclass(frozen=True)
class LLMResponse:
    text: str
    stop_reason: str
    model_id: str
    input_tokens: int | None = None
    output_tokens: int | None = None


class LLMError(RuntimeError):
    """The model call failed. Messages never include request or response content."""


class LLMClient(Protocol):
    model_id: str

    def converse(
        self,
        system: Sequence[str],
        messages: Sequence[Message],
        *,
        max_tokens: int,
        temperature: float | None = None,
    ) -> LLMResponse: ...
