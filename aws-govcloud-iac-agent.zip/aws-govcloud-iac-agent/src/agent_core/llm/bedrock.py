"""Amazon Bedrock Runtime adapter using the model-agnostic Converse API.

Credentials come from the standard AWS credential chain (ECS task role in AWS, the developer's
own profile locally). This module never reads or stores access keys.
"""
from collections.abc import Sequence
from typing import Any

import boto3
from botocore.config import Config
from botocore.exceptions import BotoCoreError, ClientError

from agent_core.llm.base import LLMError, LLMResponse, Message


class BedrockClient:
    def __init__(
        self,
        *,
        region: str,
        model_id: str,
        endpoint_url: str | None = None,
        timeout_s: int = 120,
        max_attempts: int = 3,
        client: Any = None,
    ):
        self.model_id = model_id
        self._client = client or boto3.client(
            "bedrock-runtime",
            region_name=region,
            endpoint_url=endpoint_url,  # e.g. a VPC interface endpoint, when available
            config=Config(
                connect_timeout=10,
                read_timeout=timeout_s,
                retries={"mode": "adaptive", "max_attempts": max_attempts},
            ),
        )

    def converse(
        self,
        system: Sequence[str],
        messages: Sequence[Message],
        *,
        max_tokens: int,
        temperature: float | None = None,
    ) -> LLMResponse:
        inference: dict[str, Any] = {"maxTokens": max_tokens}
        if temperature is not None:  # some models reject sampling parameters; omit by default
            inference["temperature"] = temperature
        request = {
            "modelId": self.model_id,
            "system": [{"text": block} for block in system if block],
            "messages": _to_converse_messages(messages),
            "inferenceConfig": inference,
        }
        try:
            response = self._client.converse(**request)
        except ClientError as exc:
            code = exc.response.get("Error", {}).get("Code", "ClientError")
            raise LLMError(f"Bedrock request failed: {code}") from exc
        except BotoCoreError as exc:
            raise LLMError(f"Bedrock request failed: {type(exc).__name__}") from exc

        blocks = response.get("output", {}).get("message", {}).get("content", [])
        usage = response.get("usage", {})
        return LLMResponse(
            text="".join(block["text"] for block in blocks if "text" in block),
            stop_reason=response.get("stopReason", "unknown"),
            model_id=self.model_id,
            input_tokens=usage.get("inputTokens"),
            output_tokens=usage.get("outputTokens"),
        )


def _to_converse_messages(messages: Sequence[Message]) -> list[dict[str, Any]]:
    """Converse requires alternating roles starting with user; merge consecutive same-role turns."""
    merged: list[dict[str, Any]] = []
    for message in messages:
        if merged and merged[-1]["role"] == message.role:
            merged[-1]["content"].append({"text": message.text})
        else:
            merged.append({"role": message.role, "content": [{"text": message.text}]})
    if not merged or merged[0]["role"] != "user":
        raise LLMError("Conversation must start with a user message")
    return merged
