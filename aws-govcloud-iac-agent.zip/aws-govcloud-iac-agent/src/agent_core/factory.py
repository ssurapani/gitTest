"""Builds a ready-to-use agent from settings. Services call build_agent() once at startup."""
from dataclasses import dataclass
from typing import Any

from agent_core import __version__
from agent_core.content.loader import AgentContent, load_content
from agent_core.llm.base import LLMClient
from agent_core.models.status import ResponseStatus
from agent_core.orchestration.pipeline import AgentPipeline
from agent_core.orchestration.session import InMemorySessionStore, SessionStore
from agent_core.retrieval.catalog import ServiceCatalog
from agent_core.retrieval.remote import build_remote_sources
from agent_core.settings import Settings

SCOPE = (
    "Designs AWS GovCloud Landing Zone infrastructure solutions from approved Codebank patterns "
    "and produces candidate Terraform and GitLab CI/CD artifacts for review. It does not "
    "provision resources, run pipelines, or merge changes."
)


@dataclass
class Agent:
    settings: Settings
    content: AgentContent
    llm: LLMClient
    pipeline: AgentPipeline
    store: SessionStore

    def capabilities(self) -> dict[str, Any]:
        return {
            "name": self.content.policy.name,
            "version": __version__,
            "content_version": self.content.version,
            "purpose": self.content.policy.purpose,
            "execution_mode": self.content.policy.default_execution_mode,
            "scope": SCOPE,
            "model_id": self.llm.model_id,
            "stages": [stage.name for stage in self.pipeline.stages],
            "statuses": [status.value for status in ResponseStatus],
            "catalog_entries": len(self.pipeline.catalog),
        }


def build_llm(settings: Settings) -> LLMClient:
    if settings.llm_provider == "bedrock":
        from agent_core.llm.bedrock import BedrockClient

        return BedrockClient(
            region=settings.bedrock_region or "",
            model_id=settings.bedrock_model_id or "",
            endpoint_url=settings.bedrock_endpoint_url,
            timeout_s=settings.llm_timeout_s,
            max_attempts=settings.llm_max_attempts,
        )
    from agent_core.llm.fake import FakeLLMClient

    return FakeLLMClient()


def build_agent(
    settings: Settings | None = None,
    *,
    llm: LLMClient | None = None,
    store: SessionStore | None = None,
) -> Agent:
    settings = settings or Settings()
    content = load_content(settings.agent_content_dir, settings.instructions_path())
    llm = llm or build_llm(settings)
    store = store or InMemorySessionStore(settings.max_sessions)
    pipeline = AgentPipeline(
        content=content,
        llm=llm,
        catalog=ServiceCatalog.load([content.knowledge_dir, *settings.catalog_paths]),
        remote=build_remote_sources(content.sources),
        store=store,
        max_tokens=settings.llm_max_tokens,
        temperature=settings.llm_temperature,
        max_request_chars=settings.max_request_chars,
    )
    return Agent(settings=settings, content=content, llm=llm, pipeline=pipeline, store=store)
