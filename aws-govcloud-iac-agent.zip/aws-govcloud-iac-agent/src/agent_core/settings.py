"""Environment-driven settings for the agent core. Never put secrets in these values."""
from pathlib import Path
from typing import Literal

from pydantic import Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=None, extra="ignore")

    app_env: Literal["local", "dev", "test", "prod"] = "local"
    log_level: str = "INFO"

    # Agent content root (the repository's agent/ folder, or /app/agent-content in the image).
    agent_content_dir: Path = Path("/app/agent-content")
    # Defaults to <content_dir>/AGENTS.md, falling back to <content_dir>/../AGENTS.md.
    agent_instructions_path: Path | None = None
    # Additional verified service-catalog files or directories (JSON list in the environment).
    catalog_paths: list[Path] = Field(default_factory=list)

    llm_provider: Literal["fake", "bedrock"] = "fake"
    bedrock_region: str | None = None
    # No default: the model or inference profile must be confirmed through Service Enablement.
    bedrock_model_id: str | None = None
    bedrock_endpoint_url: str | None = None
    llm_max_tokens: int = Field(default=16000, gt=0)
    llm_temperature: float | None = None
    llm_timeout_s: int = Field(default=120, gt=0)
    llm_max_attempts: int = Field(default=3, ge=1)

    max_request_chars: int = Field(default=20000, gt=0)
    max_sessions: int = Field(default=1000, gt=0)

    @model_validator(mode="after")
    def _check_llm(self) -> "Settings":
        if self.llm_provider == "bedrock":
            if not self.bedrock_model_id:
                raise ValueError("BEDROCK_MODEL_ID is required when LLM_PROVIDER=bedrock")
            if not (self.bedrock_region or "").startswith("us-gov-"):
                raise ValueError("BEDROCK_REGION must be an AWS GovCloud Region (us-gov-*)")
        if self.llm_provider == "fake" and self.app_env == "prod":
            raise ValueError("LLM_PROVIDER=fake is not allowed when APP_ENV=prod")
        return self

    def instructions_path(self) -> Path:
        if self.agent_instructions_path:
            return self.agent_instructions_path
        inside = self.agent_content_dir / "AGENTS.md"
        return inside if inside.is_file() else self.agent_content_dir.parent / "AGENTS.md"
