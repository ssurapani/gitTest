import boto3
import pytest
from botocore.stub import Stubber

from agent_core.llm.base import LLMError, Message
from agent_core.llm.bedrock import BedrockClient

MODEL = "test-model-id"


@pytest.fixture
def stubbed():
    client = boto3.client("bedrock-runtime", region_name="us-gov-west-1",
                          aws_access_key_id="testing", aws_secret_access_key="testing")
    with Stubber(client) as stubber:
        yield BedrockClient(region="us-gov-west-1", model_id=MODEL, client=client), stubber


def _response(text="ok", stop="end_turn"):
    return {
        "output": {"message": {"role": "assistant", "content": [{"text": text}]}},
        "stopReason": stop,
        "usage": {"inputTokens": 10, "outputTokens": 2, "totalTokens": 12},
        "metrics": {"latencyMs": 5},
    }


def test_converse_request_shape_and_parsing(stubbed):
    client, stubber = stubbed
    stubber.add_response("converse", _response("hello"), {
        "modelId": MODEL,
        "system": [{"text": "sys"}],
        "messages": [
            {"role": "user", "content": [{"text": "a"}, {"text": "b"}]},
            {"role": "assistant", "content": [{"text": "c"}]},
        ],
        "inferenceConfig": {"maxTokens": 100},
    })
    result = client.converse(["sys", ""], [Message("user", "a"), Message("user", "b"),
                                           Message("assistant", "c")], max_tokens=100)
    assert result.text == "hello"
    assert result.stop_reason == "end_turn"
    assert (result.input_tokens, result.output_tokens) == (10, 2)


def test_temperature_sent_only_when_set(stubbed):
    client, stubber = stubbed
    stubber.add_response("converse", _response(), {
        "modelId": MODEL, "system": [{"text": "s"}],
        "messages": [{"role": "user", "content": [{"text": "a"}]}],
        "inferenceConfig": {"maxTokens": 5, "temperature": 0.2},
    })
    client.converse(["s"], [Message("user", "a")], max_tokens=5, temperature=0.2)


def test_client_error_is_wrapped_without_details(stubbed):
    client, stubber = stubbed
    stubber.add_client_error("converse", service_error_code="AccessDeniedException",
                             service_message="sensitive detail")
    with pytest.raises(LLMError) as exc:
        client.converse(["s"], [Message("user", "a")], max_tokens=5)
    assert "AccessDeniedException" in str(exc.value)
    assert "sensitive" not in str(exc.value)


def test_conversation_must_start_with_user(stubbed):
    client, _ = stubbed
    with pytest.raises(LLMError):
        client.converse(["s"], [Message("assistant", "a")], max_tokens=5)
