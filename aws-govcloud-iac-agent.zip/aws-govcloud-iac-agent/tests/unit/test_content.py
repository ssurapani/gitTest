import shutil
from pathlib import Path

import pytest

from agent_core.content import ContentError, SkillRegistry, load_content
from agent_core.content.fingerprint import fingerprint
from agent_core.settings import Settings

REPO = Path(__file__).resolve().parents[2]


def test_loads_repository_content(settings):
    content = load_content(settings.agent_content_dir, settings.instructions_path())
    assert content.policy.name == "aws-govcloud-iac-agent"
    assert "aws_vpc" in content.prohibited_resource_types
    assert content.version.startswith("sha256:")
    SkillRegistry(content.skills)  # all stage skills present


def test_instructions_fall_back_to_parent_agents_md(settings):
    assert settings.instructions_path() == REPO / "AGENTS.md"


def test_fingerprint_is_order_independent():
    files = [("a.md", b"one"), ("b.md", b"two")]
    assert fingerprint(files) == fingerprint(list(reversed(files)))
    assert fingerprint(files) != fingerprint([("a.md", b"one"), ("b.md", b"changed")])


@pytest.fixture
def content_copy(tmp_path):
    target = tmp_path / "agent"
    shutil.copytree(REPO / "agent", target)
    shutil.copy(REPO / "AGENTS.md", target / "AGENTS.md")
    return target


def test_refuses_unsafe_execution_flag(content_copy):
    config = content_copy / "config/agent.yaml"
    config.write_text(config.read_text().replace("terraform_apply_allowed: false",
                                                 "terraform_apply_allowed: true"))
    with pytest.raises(ContentError, match="terraform_apply_allowed"):
        load_content(content_copy, content_copy / "AGENTS.md")


def test_refuses_missing_required_file(content_copy):
    (content_copy / "policies/prohibited-resource-types.yaml").unlink()
    with pytest.raises(ContentError, match="Missing agent content"):
        load_content(content_copy, content_copy / "AGENTS.md")


def test_refuses_missing_skill(content_copy):
    shutil.rmtree(content_copy / "skills/landing-zone-guardrails")
    content = load_content(content_copy, content_copy / "AGENTS.md")
    with pytest.raises(ContentError, match="landing-zone-guardrails"):
        SkillRegistry(content.skills)


def test_bedrock_settings_require_govcloud_region_and_model():
    with pytest.raises(ValueError, match="BEDROCK_MODEL_ID"):
        Settings(llm_provider="bedrock", bedrock_region="us-gov-west-1")
    with pytest.raises(ValueError, match="GovCloud"):
        Settings(llm_provider="bedrock", bedrock_region="us-east-1", bedrock_model_id="m")
    with pytest.raises(ValueError, match="fake"):
        Settings(app_env="prod")
