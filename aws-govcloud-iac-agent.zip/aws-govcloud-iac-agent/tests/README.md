# Agent Evaluation Tests

`eval/guardrail-scenarios.yaml` contains representative expected behaviors for a test harness.

Recommended test method:
1. Run each scenario against the configured model and skills.
2. Capture the agent's response and tool calls.
3. Assert required behaviors and forbidden behaviors.
4. Run deterministic policy tests against generated Terraform and pipeline diffs.
5. Repeat after changing prompts, skills, retrieval, models, or tools.

At minimum, test both direct declarations and indirect creation through modules. Add organization-specific cases for actual Terraform provider aliases, GitLab includes, Checkov suppressions, and pipeline templates.

Do not treat passing prompt tests as proof of security. Enforce hard restrictions outside the model.
