import time

import jwt
import pytest
from cryptography.hazmat.primitives.asymmetric import rsa
from fastapi.testclient import TestClient

from agent_api.auth import OidcAuthenticator
from agent_api.errors import AuthError
from agent_api.main import create_app
from agent_api.settings import ApiSettings

TOKEN = "local-test-token-0123456789"
AUTH = {"Authorization": f"Bearer {TOKEN}"}
REQUEST = "I need an S3 bucket for application logs in the dev account, us-gov-west-1."


@pytest.fixture
def make_client(make_agent):
    def _make(responses=None, **settings):
        agent, llm = make_agent(responses)
        api_settings = ApiSettings(api_static_token=TOKEN, **settings)
        client = TestClient(create_app(agent=agent, api_settings=api_settings))
        client.__enter__()  # run lifespan
        return client, llm

    yield _make


@pytest.fixture
def client(make_client):
    return make_client()[0]


def test_health_needs_no_auth(client):
    assert client.get("/healthz").json() == {"status": "ok"}
    assert client.get("/readyz").json()["status"] == "ready"


@pytest.mark.parametrize("headers", [{}, {"Authorization": "Bearer wrong-token"},
                                     {"Authorization": f"Basic {TOKEN}"}])
def test_v1_requires_valid_bearer_token(client, headers):
    response = client.get("/v1/agent/capabilities", headers=headers)
    assert response.status_code == 401
    assert response.headers["content-type"] == "application/problem+json"
    assert response.headers["www-authenticate"] == "Bearer"


def test_capabilities(client):
    body = client.get("/v1/agent/capabilities", headers=AUTH).json()
    assert body["api_version"] == "v1"
    assert body["execution_mode"] == "propose_only"
    assert body["content_version"].startswith("sha256:")
    assert "validated" not in body["statuses"]


def test_session_flow_and_artifacts(client):
    created = client.post("/v1/sessions", json={"message": "I need a bucket for logs."}, headers=AUTH)
    assert created.status_code == 201
    body = created.json()
    assert body["status"] == "needs_input" and body["questions"]
    session_id = body["session_id"]

    answered = client.post(f"/v1/sessions/{session_id}/messages",
                           json={"message": "Use S3, in the dev account."}, headers=AUTH).json()
    assert answered["status"] == "validation_pending"
    solution = answered["solution"]
    assert solution["validation"]["checkov"] == "not_run"

    view = client.get(f"/v1/sessions/{session_id}", headers=AUTH).json()
    assert [t["role"] for t in view["turns"]] == ["user", "assistant", "user", "assistant"]
    assert view["solution_ids"] == [solution["id"]]

    fetched = client.get(f"/v1/solutions/{solution['id']}", headers=AUTH).json()
    assert fetched["status"] == "validation_pending"
    artifacts = client.get(f"/v1/solutions/{solution['id']}/artifacts", headers=AUTH).json()
    assert artifacts["notice"].startswith("Candidate artifacts: not approved")
    assert artifacts["artifacts"][0]["path"] == "main.tf"


def test_sessions_are_isolated_by_end_user(client):
    alice = {**AUTH, "X-On-Behalf-Of": "alice@example.invalid"}
    bob = {**AUTH, "X-On-Behalf-Of": "bob@example.invalid"}
    session_id = client.post("/v1/sessions", json={"message": REQUEST}, headers=alice).json()["session_id"]
    solution_id = client.get(f"/v1/sessions/{session_id}", headers=alice).json()["solution_ids"][0]
    for path in (f"/v1/sessions/{session_id}", f"/v1/solutions/{solution_id}"):
        assert client.get(path, headers=bob).status_code == 404
    reply = client.post(f"/v1/sessions/{session_id}/messages", json={"message": "x"}, headers=bob)
    assert reply.status_code == 404


def test_invalid_on_behalf_of_is_rejected_not_dropped(client):
    response = client.get("/v1/agent/capabilities", headers={**AUTH, "X-On-Behalf-Of": "bad user<>"})
    assert response.status_code == 400
    assert response.json()["detail"] == "Invalid X-On-Behalf-Of header"


def test_invoke_is_single_shot(client):
    body = client.post("/v1/agent/invoke", json={"message": REQUEST}, headers=AUTH).json()
    assert body["status"] == "validation_pending"
    assert body["session_id"] is None
    solution = body["solution"]
    assert client.get(f"/v1/solutions/{solution['id']}", headers=AUTH).status_code == 200
    # The underlying session cannot be read or continued as a conversation.
    assert client.get(f"/v1/sessions/{solution['session_id']}", headers=AUTH).status_code == 404
    other_user = {**AUTH, "X-On-Behalf-Of": "someone-else"}
    assert client.get(f"/v1/solutions/{solution['id']}", headers=other_user).status_code == 404


def test_prohibited_request_is_blocked(client):
    body = client.post("/v1/agent/invoke", json={"message": "Add CloudFront to expose my app publicly."},
                       headers=AUTH).json()
    assert body["status"] == "blocked"
    assert {b["code"] for b in body["blockers"]} == {"LZ-005", "LZ-006"}


def test_validation_errors_do_not_echo_input(client):
    response = client.post("/v1/sessions", json={"message": "", "secret": "AKIAABCDEFGHIJKLMNOP"},
                           headers=AUTH)
    assert response.status_code == 422
    assert response.headers["content-type"] == "application/problem+json"
    assert "AKIA" not in response.text


def test_body_size_limit(make_client):
    client, _ = make_client(max_body_bytes=100)
    response = client.post("/v1/sessions", json={"message": "x" * 200}, headers=AUTH)
    assert response.status_code == 413


def test_rate_limit_counts_each_request_once(make_client):
    client, _ = make_client(rate_limit_per_minute=2)
    assert client.get("/v1/agent/capabilities", headers=AUTH).status_code == 200
    assert client.get("/v1/agent/capabilities", headers=AUTH).status_code == 200
    limited = client.get("/v1/agent/capabilities", headers=AUTH)
    assert limited.status_code == 429 and int(limited.headers["retry-after"]) >= 1


def test_turn_timeout(make_client):
    def slow(system, messages):
        time.sleep(0.5)
        return "{}"

    client, _ = make_client({"requirements": slow}, turn_timeout_s=0.1)
    assert client.post("/v1/agent/invoke", json={"message": REQUEST}, headers=AUTH).status_code == 504


def test_request_ids(client):
    response = client.get("/v1/agent/capabilities", headers={**AUTH, "X-Request-ID": "abc-123"})
    assert response.headers["x-request-id"] == "abc-123"
    assert response.json()["request_id"] == "abc-123"
    unsafe = client.get("/v1/agent/capabilities", headers={**AUTH, "X-Request-ID": "bad id\n"})
    assert unsafe.headers["x-request-id"] != "bad id\n"
    assert client.get("/nope").headers["content-type"] == "application/problem+json"


def test_unhandled_error_is_generic(make_client):
    def boom(system, messages):
        raise RuntimeError("internal detail")

    client, _ = make_client({"requirements": boom})
    response = client.post("/v1/agent/invoke", json={"message": REQUEST}, headers=AUTH)
    assert response.status_code == 500
    assert "internal detail" not in response.text


def test_settings_guard_static_token():
    with pytest.raises(ValueError, match="only allowed when APP_ENV=local"):
        ApiSettings(app_env="dev", api_static_token=TOKEN)
    with pytest.raises(ValueError, match="at least 16"):
        ApiSettings(api_static_token="short")
    with pytest.raises(ValueError, match="OIDC_ISSUER"):
        ApiSettings(auth_mode="oidc")
    assert ApiSettings(app_env="prod", auth_mode="oidc", oidc_issuer="i", oidc_audience="a",
                       oidc_jwks_url="https://idp.example.invalid/jwks").docs_enabled is False


class TestOidc:
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)

    def authenticator(self):
        return OidcAuthenticator(issuer="https://idp.example.invalid", audience="iac-agent-api",
                                 algorithms=["RS256"], key_resolver=lambda token: self.key.public_key())

    def token(self, **overrides):
        now = int(time.time())
        claims = {"iss": "https://idp.example.invalid", "aud": "iac-agent-api", "sub": "svc-cloud-help",
                  "azp": "cloud-help", "iat": now, "exp": now + 300, **overrides}
        return jwt.encode(claims, self.key, algorithm="RS256")

    def test_valid_token(self):
        assert self.authenticator().authenticate(self.token()) == ("svc-cloud-help", "cloud-help")

    @pytest.mark.parametrize("overrides", [{"aud": "other"}, {"iss": "https://evil.invalid"},
                                           {"exp": int(time.time()) - 10}])
    def test_rejected_tokens(self, overrides):
        with pytest.raises(AuthError):
            self.authenticator().authenticate(self.token(**overrides))

    def test_rejects_unsigned_token(self):
        unsigned = jwt.encode({"sub": "x"}, key=None, algorithm="none")
        with pytest.raises(AuthError):
            self.authenticator().authenticate(unsigned)


def test_openapi_contract(client):
    spec = client.get("/v1/openapi.json").json()
    assert set(spec["paths"]) == {
        "/healthz", "/readyz", "/v1/agent/capabilities", "/v1/agent/invoke", "/v1/sessions",
        "/v1/sessions/{session_id}/messages", "/v1/sessions/{session_id}",
        "/v1/solutions/{solution_id}", "/v1/solutions/{solution_id}/artifacts",
    }
    schemas = spec["components"]["schemas"]
    assert set(schemas["AgentResponse"]["properties"]) == {
        "request_id", "session_id", "status", "agent", "messages", "questions", "solution", "blockers"}
    assert schemas["ResponseStatus"]["enum"] == [
        "needs_input", "proposed", "validation_pending", "blocked", "out_of_scope"]


def test_concurrent_turn_on_same_session_conflicts(make_client):
    from agent_api.errors import SessionBusy

    client, _ = make_client()
    locks = client.app.state.session_locks
    with locks.hold("s1"), pytest.raises(SessionBusy):
        with locks.hold("s1"):
            pass
    with locks.hold("s1"):
        pass  # released after the first holder exits
