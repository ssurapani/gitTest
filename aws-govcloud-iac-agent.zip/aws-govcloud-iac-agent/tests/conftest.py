from pathlib import Path

import pytest

from agent_core.factory import build_agent
from agent_core.llm.fake import FakeLLMClient
from agent_core.settings import Settings

REPO = Path(__file__).resolve().parents[1]

# Test-only catalog. The URL and pattern are fictitious and must never be used as real data.
TEST_CATALOG = """
services:
  - id: amazon-s3
    name: Amazon S3
    enablement:
      status: enabled
      scope: test-fixture
      source_url: https://confluence.example.invalid/service-enablement/s3
      source_revision: "42"
      verified_at: 2026-10-01
    patterns:
      - project: test-group/codebank-patterns
        path: s3/bucket
        revision: v1.2.0
        status: approved
        owner: TEST_OWNER
    regions: [us-gov-west-1]
  - id: amazon-dynamodb
    name: Amazon DynamoDB
    enablement:
      status: disabled
      source_url: https://confluence.example.invalid/service-enablement/dynamodb
      verified_at: 2026-10-01
"""


@pytest.fixture
def settings() -> Settings:
    return Settings(agent_content_dir=REPO / "agent")


@pytest.fixture
def catalog_file(tmp_path: Path) -> Path:
    path = tmp_path / "catalog.yaml"
    path.write_text(TEST_CATALOG, encoding="utf-8")
    return path


@pytest.fixture
def make_agent(settings: Settings, catalog_file: Path):
    def _make(responses=None, with_catalog=True):
        llm = FakeLLMClient(responses)
        agent_settings = settings.model_copy(
            update={"catalog_paths": [catalog_file] if with_catalog else []}
        )
        return build_agent(agent_settings, llm=llm), llm

    return _make
