"""UI tests. Pages run in Streamlit's AppTest against the real API app (fake LLM) in process."""
from pathlib import Path

import httpx
import pytest
from fastapi.testclient import TestClient
from streamlit.testing.v1 import AppTest

import agent_ui.common as common
from agent_api.main import create_app
from agent_api.settings import ApiSettings
from agent_ui.api_client import ApiClient, ApiError, ClientCredentialsTokenProvider, StaticTokenProvider
from agent_ui.settings import UiSettings

UI = Path(__file__).resolve().parents[2] / "services" / "ui" / "agent_ui"
TOKEN = "local-test-token-0123456789"
REQUEST = "I need an S3 bucket for application logs in the dev account, us-gov-west-1."


@pytest.fixture
def api_client(make_agent, monkeypatch):
    agent, _ = make_agent()
    app = create_app(agent=agent, api_settings=ApiSettings(api_static_token=TOKEN))
    with TestClient(app, base_url="http://api.test") as http:
        client = ApiClient("http://api.test", StaticTokenProvider(TOKEN), http=http)
        monkeypatch.setattr(common, "get_client", lambda: client)
        monkeypatch.setattr(common, "get_settings", lambda: UiSettings(api_static_token=TOKEN))
        yield client


def page(name: str) -> AppTest:
    return AppTest.from_file(str(UI / name), default_timeout=10)


def texts(at: AppTest) -> str:
    return "\n".join(t.value for t in at.text)


def test_home_conversation_to_solution(api_client):
    at = page("Home.py").run()
    assert not at.exception
    at.chat_input[0].set_value("I need a bucket for logs.").run()
    assert any("Needs input" in m.value for m in at.markdown)
    assert "Which AWS services" in texts(at)

    at.text_input[0].input("Use S3")
    at.text_input[1].input("the dev account")
    next(b for b in at.button if b.label == "Send answers").click().run()
    assert not at.exception
    assert any("Validation pending" in m.value for m in at.markdown)
    assert at.session_state["solution_id"]
    assert [m.name for m in at.chat_message] == ["user", "assistant", "user", "assistant"]


def test_blocked_request_shows_blockers(api_client):
    at = page("Home.py").run()
    at.chat_input[0].set_value("Create a new VPC in my application account.").run()
    assert any("Blocked" in m.value for m in at.markdown)
    assert "[LZ-001]" in texts(at)


def test_untrusted_text_is_not_rendered_as_markdown(api_client):
    at = page("Home.py").run()
    at.chat_input[0].set_value("S3 in dev ![x](https://evil.invalid/a.png)").run()
    assert "evil.invalid" in texts(at)
    assert not any("evil.invalid" in m.value for m in at.markdown)


def test_api_errors_are_shown(api_client):
    at = page("Home.py")
    at.session_state["session_id"] = "does-not-exist"
    at.run()
    at.chat_input[0].set_value("hello").run()
    assert at.error and "404 Not Found" in texts(at)


def test_solution_page(api_client):
    solution = api_client.create_session(REQUEST, user="local-user")["solution"]
    at = page("pages/1_Solution.py")
    at.session_state["solution_id"] = solution["id"]
    at.run()
    assert not at.exception
    assert "not approved" in at.warning[0].value
    assert any("?ref=v1.2.0" in c.value for c in at.code)
    validation = next(d for d in at.dataframe if "check" in d.value.columns).value
    statuses = dict(zip(validation["check"], validation["status"]))
    assert statuses["checkov"] == "not_run"
    assert statuses["architecture_policy"] == "passed"


def test_solution_page_hides_other_users_solutions(api_client):
    solution = api_client.create_session(REQUEST, user="someone-else")["solution"]
    at = page("pages/1_Solution.py")
    at.session_state["solution_id"] = solution["id"]
    at.run()
    assert "404 Not Found" in texts(at)


def test_solution_page_without_solution(api_client):
    at = page("pages/1_Solution.py").run()
    assert "No solution yet" in at.info[0].value


def test_about_page(api_client):
    at = page("pages/2_About.py").run()
    assert not at.exception
    assert at.json[0].value and '"execution_mode": "propose_only"' in at.json[0].value


def test_artifacts_zip_skips_unsafe_paths():
    import io
    import zipfile

    data = common.artifacts_zip([{"path": "main.tf", "content": "x"},
                                 {"path": "../evil.tf", "content": "y"}])
    names = zipfile.ZipFile(io.BytesIO(data)).namelist()
    assert names == ["CANDIDATE-NOT-APPROVED.txt", "main.tf"]


def test_client_sends_identity_headers_and_maps_problems():
    seen = {}

    def handler(request: httpx.Request) -> httpx.Response:
        seen.update(request.headers)
        return httpx.Response(404, json={"title": "Not Found", "detail": "missing", "instance": "r-1"})

    http = httpx.Client(base_url="http://api.test", transport=httpx.MockTransport(handler))
    client = ApiClient("http://api.test", StaticTokenProvider(TOKEN), http=http)
    with pytest.raises(ApiError) as error:
        client.get_session("s1", user="alice")
    assert (error.value.status, error.value.detail, error.value.request_id) == (404, "missing", "r-1")
    assert seen["authorization"] == f"Bearer {TOKEN}"
    assert seen["x-on-behalf-of"] == "alice"


def test_client_reports_unreachable_api():
    def handler(request):
        raise httpx.ConnectError("refused")

    http = httpx.Client(base_url="http://api.test", transport=httpx.MockTransport(handler))
    with pytest.raises(ApiError) as error:
        ApiClient("http://api.test", StaticTokenProvider(TOKEN), http=http).capabilities()
    assert error.value.status == 0 and error.value.title == "API unreachable"


def test_client_credentials_token_is_cached_until_near_expiry():
    calls = []
    now = [0.0]

    def handler(request):
        calls.append(request.content.decode())
        return httpx.Response(200, json={"access_token": f"t{len(calls)}", "expires_in": 120})

    provider = ClientCredentialsTokenProvider(
        token_url="https://idp.example.invalid/token", client_id="ui", client_secret="s3cr3t-value",
        http=httpx.Client(transport=httpx.MockTransport(handler)), clock=lambda: now[0])
    assert provider.token() == "t1"
    now[0] = 59
    assert provider.token() == "t1"
    now[0] = 61
    assert provider.token() == "t2"
    assert "grant_type=client_credentials" in calls[0]


def test_ui_settings_guards():
    with pytest.raises(ValueError, match="only allowed when APP_ENV=local"):
        UiSettings(app_env="dev", api_static_token=TOKEN)
    with pytest.raises(ValueError, match="UI_USER_HEADER"):
        UiSettings(app_env="dev", ui_auth_mode="client_credentials", ui_oidc_token_url="https://t",
                   ui_oidc_client_id="c", ui_oidc_client_secret="s")
    with pytest.raises(ValueError, match="http"):
        UiSettings(api_static_token=TOKEN, api_base_url="file:///etc/passwd")
