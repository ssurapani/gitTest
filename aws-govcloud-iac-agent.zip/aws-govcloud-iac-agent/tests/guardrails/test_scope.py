import pytest

from agent_core.guardrails.scope import detect_prohibited_intents


@pytest.mark.parametrize("text, expected", [
    ("Create a new VPC in my application Landing Zone account.", ["LZ-001"]),
    ("Add CloudFront to expose my application publicly.", ["LZ-005", "LZ-006"]),
    ("Remove Checkov because it fails.", ["CICD-001"]),
    ("Run terraform apply directly without approval.", ["AGENT-EXEC"]),
    ("I need an IAM user for the batch job.", []),  # mention only; the model records it
    ("Provision an IAM user for the batch job.", ["LZ-004"]),
    ("Allow ingress from 0.0.0.0/0 on port 443.", ["LZ-006"]),
])
def test_prohibited_intents(text, expected):
    assert [b.code for b in detect_prohibited_intents(text)] == expected


@pytest.mark.parametrize("text", [
    "Deploy an ECS service into the existing VPC and delivered subnets.",
    "Add a security group to the VPC for the internal load balancer.",
    "The pipeline should run terraform apply after manual approval.",
    "Use an internal ALB; no public access.",
])
def test_allowed_requests_not_flagged(text):
    assert detect_prohibited_intents(text) == []
