from agent_core.guardrails.terraform_scan import scan_terraform
from agent_core.models.solution import PatternRef

PROHIBITED = ("aws_vpc", "aws_subnet", "aws_ec2_transit_gateway", "aws_iam_user",
              "aws_cloudfront_distribution")
PATTERN = PatternRef(service="Amazon S3", project="grp/codebank-patterns", path="s3/bucket",
                     revision="v1.2.0")


def codes(text, allowed=None, severity="error"):
    findings = scan_terraform("main.tf", text, prohibited_types=PROHIBITED, allowed_patterns=allowed)
    return sorted(f.code for f in findings if f.severity == severity)


def test_prohibited_resources_flagged():
    text = 'resource "aws_vpc" "a" {}\nresource "aws_iam_user" "u" {\n  name = "x"\n}\n'
    assert codes(text) == ["LZ-001", "LZ-004"]


def test_commented_resources_ignored_but_urls_kept():
    text = '# resource "aws_vpc" "a" {}\n/* resource "aws_subnet" "b" {} */\n' \
           'module "m" {\n  source = "git::https://h/grp/codebank-patterns.git//s3/bucket?ref=v1.2.0"\n}\n'
    assert codes(text, [PATTERN]) == []


def test_open_ingress_is_error_open_egress_is_warning():
    text = '''resource "aws_security_group" "sg" {
  ingress {
    cidr_blocks = ["0.0.0.0/0"]
  }
  egress {
    cidr_blocks = ["0.0.0.0/0"]
  }
}
resource "aws_vpc_security_group_ingress_rule" "r" {
  cidr_ipv6 = "::/0"
}
'''
    assert codes(text) == ["LZ-006", "LZ-006"]
    assert codes(text, severity="warning") == ["LZ-006"]


def test_load_balancer_must_be_internal():
    assert codes('resource "aws_lb" "a" {\n  name = "x"\n}\n') == ["LZ-006"]
    assert codes('resource "aws_lb" "a" {\n  internal = true\n}\n') == []


def test_scripts_and_suppressions_flagged():
    text = '''resource "null_resource" "n" {
  provisioner "local-exec" {
    command = "echo hi"
  }
}
data "external" "e" {}
resource "aws_s3_bucket" "b" {
  #checkov:skip=CKV_AWS_18:reason
}
'''
    assert codes(text) == ["CICD-001", "SCRIPT-001", "SCRIPT-001", "SCRIPT-001"]


def test_module_source_must_be_selected_pinned_pattern():
    other = 'module "m" {\n  source = "./modules/vpc"\n}\n'
    assert codes(other, [PATTERN]) == ["MOD-SOURCE", "MOD-UNPINNED"]
    wrong_ref = 'module "m" {\n  source = "git::https://h/grp/codebank-patterns.git//s3/bucket?ref=main"\n}\n'
    assert codes(wrong_ref, [PATTERN]) == ["MOD-REVISION"]


def test_unverified_module_inputs_are_warnings():
    text = '''module "m" {
  source = "git::https://h/grp/codebank-patterns.git//s3/bucket?ref=v1.2.0"
  bucket_name = "x"
  tags = {
    nested = "not top level"
  }
}
'''
    findings = scan_terraform("main.tf", text, prohibited_types=PROHIBITED, allowed_patterns=[PATTERN])
    assert [(f.code, f.severity) for f in findings] == [("MOD-INPUT-UNVERIFIED", "warning")]
    assert "bucket_name, tags" in findings[0].detail
