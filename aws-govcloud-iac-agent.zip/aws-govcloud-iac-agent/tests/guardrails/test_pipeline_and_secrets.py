from agent_core.guardrails.pipeline_scan import is_pipeline_file, scan_pipeline
from agent_core.guardrails.secrets import redact, scan_secrets


def codes(findings, severity="error"):
    return sorted(f.code for f in findings if f.severity == severity)


def test_pipeline_suppression_and_download_flagged():
    text = """
include:
  - project: REPLACE_WITH_PIPELINE_TEMPLATE_PROJECT
    file: terraform.yml
checkov:
  stage: compliance
  script:
    - checkov -d . --soft-fail
  allow_failure: true
setup:
  script:
    - curl -sL https://example.invalid/install.sh | bash
deploy:
  extends: !reference [.deploy, script]
  script:
    - tf apply
"""
    findings = scan_pipeline(".gitlab-ci.yml", text)
    assert codes(findings) == ["CICD-001", "CICD-001", "SCRIPT-002"]
    assert codes(findings, "warning") == ["CICD-APPLY-GATE"]


def test_invalid_yaml_reported():
    assert codes(scan_pipeline(".gitlab-ci.yml", "a: [b")) == ["CICD-PARSE"]


def test_pipeline_file_detection():
    assert is_pipeline_file(".gitlab-ci.yml")
    assert is_pipeline_file("ci/deploy.yml")
    assert not is_pipeline_file("config/app.yaml")


def test_secrets_detected_and_redacted():
    text = 'access = "AKIAABCDEFGHIJKLMNOP"\npassword = "hunter2hunter2"\ntoken = "REPLACE_WITH_TOKEN"\n'
    assert [f.line for f in scan_secrets("main.tf", text)] == [1, 2]
    redacted = redact(text)
    assert "AKIA" not in redacted and "hunter2" not in redacted
    assert "REPLACE_WITH_TOKEN" in redacted
