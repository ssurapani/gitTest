# AWS GovCloud IaC & GitLab CI/CD Agent Guardrails

A starter repository for a constrained AI agent that helps authorized application teams design, generate, validate, and prepare Terraform IaC and GitLab CI/CD artifacts for AWS GovCloud Landing Zone workloads.

This repository contains:
- Global agent instructions
- Specialized skill instructions
- Knowledge-source contracts and catalog examples
- Machine-readable Landing Zone guardrails
- A sample architecture decision workflow
- Validation checklists and adversarial test cases

> **Important:** This is a starter framework, not a production security boundary. Review and adapt it to your organization's actual Confluence, GitLab, Checkov, Terraform wrapper, account inventory, and approval workflows. Prompt instructions alone do not enforce security. Enforce critical rules in CI, IAM, repository protections, and policy checks.

## Repository layout

```text
aws-govcloud-iac-agent/
├── README.md
├── AGENTS.md                     # global agent instructions (kept at root for tooling)
├── design.md                     # application design: UI, API, agent core, CI/CD
├── pyproject.toml
├── agent/                        # agent runtime content, packaged read-only into the API
│   ├── config/
│   │   ├── agent.yaml
│   │   ├── landing-zone-guardrails.yaml
│   │   └── source-of-truth.yaml
│   ├── skills/
│   │   ├── requirements-discovery/SKILL.md
│   │   ├── landing-zone-guardrails/SKILL.md
│   │   ├── service-enablement/SKILL.md
│   │   ├── codebank-discovery/SKILL.md
│   │   ├── iac-composition/SKILL.md
│   │   ├── terraform-authoring/SKILL.md
│   │   ├── gitlab-cicd/SKILL.md
│   │   ├── compliance-validation/SKILL.md
│   │   ├── gitlab-delivery/SKILL.md
│   │   └── pattern-gap-analysis/SKILL.md
│   ├── knowledge/
│   │   ├── catalog-schema.yaml
│   │   └── service-pattern-catalog.example.yaml
│   ├── workflows/
│   │   └── solution-decision-workflow.md
│   ├── policies/
│   │   ├── policy-checklist.yaml
│   │   └── prohibited-resource-types.yaml
│   └── templates/
│       ├── requirements-record.yaml
│       ├── solution-record.yaml
│       └── pattern-gap-issue.md
├── iac/                          # Terraform hosting the app, composed from Codebank patterns
│   ├── *.tf
│   ├── pattern-references.yaml
│   └── environments/{dev,test,prod}/
├── docs/
│   ├── architecture.md
│   ├── operating-model.md
│   ├── threat-model.md
│   └── onboarding.md
├── tests/
│   ├── README.md
│   └── eval/guardrail-scenarios.yaml
└── scripts/
    └── validate_repository.py
```

Application code (`src/agent_core/`, `services/api/`, `services/ui/`) is planned in `design.md` and not yet created.

## Quick start

1. Review `AGENTS.md` and replace any generic terminology with your organization's approved names.
2. Update `agent/config/source-of-truth.yaml` with authoritative Confluence spaces and GitLab projects.
3. Populate the service/pattern catalog from approved sources; do not maintain duplicate facts manually if synchronization is possible.
4. Confirm the prohibited resource list and enforcement approach with Cloud Foundation and Compliance owners.
5. Adapt the skills to your actual `tf` wrapper, pipeline templates, Checkov integration, and GitLab merge-request workflow.
6. Run the repository sanity checks:

   ```bash
   python scripts/validate_repository.py
   ```

7. Test the agent against `tests/eval/guardrail-scenarios.yaml` before enabling write-capable tools.

## Suggested rollout

- Phase 1: Read-only source retrieval and requirements/architecture proposals.
- Phase 2: Generate IaC in a sandbox or non-production project and run validation.
- Phase 3: Create branches and merge requests with scoped GitLab permissions.
- Phase 4: Integrate trusted account/resource inventory and measured feedback.

## Important policy notes

- “Enabled” does not necessarily mean approved for every account, Region, workload, or use case.
- Never invent account IDs, subnet IDs, VPC IDs, DNS zones, service status, or validation results.
- A missing search result is not proof that a pattern does not exist.
- The agent must not provision AWS resources directly unless a separate, explicitly authorized workflow permits it.
- New patterns remain candidates until the required review and approval process is complete.
